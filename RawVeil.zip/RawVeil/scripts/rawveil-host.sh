#!/bin/bash
#
# RawVeil host supervisor.
#
# It owns the temporary host-side state: the dummy capture interface and the
# nftables netdev table.  The nft table is intentionally *not* persistent.
# Whenever this script exits (normal shutdown, signal, RawVeil crash) the
# table and dummy interface are removed, restoring normal networking.
#
set -u
[ -n "${RAWVEIL_DEBUG:-}" ] && set -x

PROGRAM=${0##*/}
CONFIG=${RAWVEIL_CONFIG:-/etc/rawveil/rawveil.conf}
BIN=${RAWVEIL_BIN:-/usr/local/bin/rawveil}
STATE_DIR=${RAWVEIL_STATE_DIR:-/run/rawveil-host}
PID_FILE=${RAWVEIL_PID_FILE:-$STATE_DIR/rawveil.pid}
STATS_FILE=${RAWVEIL_STATS_FILE:-$STATE_DIR/rawveil.stats}
DUMMY=${RAWVEIL_DUMMY:-rvhost0}
NFT_TABLE=${RAWVEIL_NFT_TABLE:-rawveil_host}
LOG_LEVEL=${RAWVEIL_LOG_LEVEL:-info}
IFACE=${RAWVEIL_IFACE:-}
CREATED_DUMMY=0

log() { printf '%s: %s\n' "$PROGRAM" "$*" >&2; }
die() { log "ERROR: $*"; exit 1; }

need_root() {
    [ "$(id -u)" -eq 0 ] || die "run as root"
}

default_iface() {
    ip -o -4 route show to default 2>/dev/null |
        awk '{ for (i = 1; i <= NF; i++) if ($i == "dev") { print $(i + 1); exit } }'
}

cleanup() {
    # Idempotent; must never abort shutdown because a rule/interface vanished.
    # If an operator calls "cleanup" while RawVeil is still running, stop it
    # first: deleting the capture dummy under a live capture gives the
    # misleading "recvmmsg: Network is down" error.
    if [ -f "$PID_FILE" ]; then
        pid=$(cat "$PID_FILE" 2>/dev/null || true)
        if [ -n "${pid:-}" ] && kill -0 "$pid" 2>/dev/null; then
            kill -TERM "$pid" 2>/dev/null || true
            for _ in $(seq 1 30); do
                kill -0 "$pid" 2>/dev/null || break
                sleep 0.1
            done
            kill -KILL "$pid" 2>/dev/null || true
        fi
    fi
    nft delete table netdev "$NFT_TABLE" >/dev/null 2>&1 || true
    if [ "$CREATED_DUMMY" -eq 1 ] ||
       [ -f "$STATE_DIR/dummy-created" ]; then
        ip link del "$DUMMY" >/dev/null 2>&1 || true
        CREATED_DUMMY=0
    fi
    rm -f "$PID_FILE" "$STATS_FILE" "$STATE_DIR/dummy-created" 2>/dev/null || true
}

setup_network() {
    command -v nft >/dev/null 2>&1 || die "nft is required"
    command -v ip >/dev/null 2>&1 || die "ip is required"
    [ -x "$BIN" ] || die "rawveil binary not found: $BIN"
    [ -r "$CONFIG" ] || die "config not found: $CONFIG"

    if [ -z "$IFACE" ]; then
        IFACE=$(default_iface)
    fi
    [ -n "$IFACE" ] || die "cannot detect default uplink; set RAWVEIL_IFACE"
    ip link show "$IFACE" >/dev/null 2>&1 || die "unknown uplink: $IFACE"

    # Remove leftovers from an earlier crash before creating new state.
    nft delete table netdev "$NFT_TABLE" >/dev/null 2>&1 || true
    if ip link show "$DUMMY" >/dev/null 2>&1; then
        ip link del "$DUMMY" >/dev/null 2>&1 || true
    fi

    ip link add "$DUMMY" type dummy || die "cannot create $DUMMY"
    CREATED_DUMMY=1
    touch "$STATE_DIR/dummy-created"
    ip link set "$DUMMY" up mtu 65535 || die "cannot configure $DUMMY"

    nft add table netdev "$NFT_TABLE" || die "cannot create nft table"
    nft 'add chain netdev '"$NFT_TABLE"' out { type filter hook egress device "'"$IFACE"'" priority 0; }' ||
        die "cannot create nft chain"

    # Own frames must not be redirected back into the capture dummy.
    nft add rule netdev "$NFT_TABLE" out \
        ether type ip ip id 0x5256 counter accept ||
        die "cannot add IPv4 marker rule"
    nft add rule netdev "$NFT_TABLE" out \
        ether type ip6 ip6 flowlabel 0x5256 counter accept ||
        die "cannot add IPv6 marker rule"

    # Do not steal pure ACKs/SYN/FIN.  They must go directly to the uplink.
    nft add rule netdev "$NFT_TABLE" out \
        'ether type ip tcp dport 443 meta length <= 100 counter accept' ||
        die "cannot add short-IPv4-TCP rule"
    nft add rule netdev "$NFT_TABLE" out \
        'ether type ip6 tcp dport 443 meta length <= 100 counter accept' ||
        die "cannot add short-IPv6-TCP rule"

    nft add rule netdev "$NFT_TABLE" out \
        ether type ip tcp dport 443 counter fwd to "$DUMMY" ||
        die "cannot add IPv4 TCP/443 capture rule"
    nft add rule netdev "$NFT_TABLE" out \
        ether type ip6 tcp dport 443 counter fwd to "$DUMMY" ||
        die "cannot add IPv6 TCP/443 capture rule"

    for port in 2053 2083 2087 2096 8443; do
        nft add rule netdev "$NFT_TABLE" out \
            ether type ip tcp dport "$port" counter fwd to "$DUMMY" ||
            die "cannot add IPv4 TCP/$port capture rule"
        nft add rule netdev "$NFT_TABLE" out \
            ether type ip6 tcp dport "$port" counter fwd to "$DUMMY" ||
            die "cannot add IPv6 TCP/$port capture rule"
    done

    nft add rule netdev "$NFT_TABLE" out \
        ether type ip udp dport 443 counter fwd to "$DUMMY" ||
        die "cannot add IPv4 UDP/443 capture rule"
    nft add rule netdev "$NFT_TABLE" out \
        ether type ip6 udp dport 443 counter fwd to "$DUMMY" ||
        die "cannot add IPv6 UDP/443 capture rule"

    nft add rule netdev "$NFT_TABLE" out \
        ether type ip udp dport 50000-50099 counter fwd to "$DUMMY" ||
        die "cannot add IPv4 Discord UDP capture rule"
    nft add rule netdev "$NFT_TABLE" out \
        ether type ip6 udp dport 50000-50099 counter fwd to "$DUMMY" ||
        die "cannot add IPv6 Discord UDP capture rule"

    log "capture=$DUMMY uplink=$IFACE table=netdev/$NFT_TABLE"
}

run() {
    need_root
    mkdir -p "$STATE_DIR"

    # Set the trap before touching the network: a failed nft command must not
    # leave a half-configured capture table behind.
    trap 'rc=$?; cleanup; exit $rc' EXIT
    trap 'exit 130' INT
    trap 'exit 143' TERM

    setup_network

    "$BIN" on --foreground \
        --config "$CONFIG" \
        --interface "$DUMMY" \
        --send-interface "$IFACE" \
        --pid-file "$PID_FILE" \
        --stats-file "$STATS_FILE" \
        --log-level "$LOG_LEVEL" \
        --profile discord_tls.strategy=multisplit \
        --profile discord_tls.split_sni=true \
        --profile discord_tls.split_reverse=true \
        --profile discord_tls.desync_data_packets=64 \
        --profile discord_tls.segments=2 &
    child=$!

    # If the supervisor is killed while RawVeil survives, this watcher removes
    # the nft table as soon as RawVeil exits.
    (
        while kill -0 "$child" 2>/dev/null; do sleep 1; done
        nft delete table netdev "$NFT_TABLE" >/dev/null 2>&1 || true
        ip link del "$DUMMY" >/dev/null 2>&1 || true
    ) &
    watcher=$!

    wait "$child"
    rc=$?
    kill "$watcher" >/dev/null 2>&1 || true
    wait "$watcher" >/dev/null 2>&1 || true
    exit "$rc"
}

stop() {
    need_root
    if [ -f "$PID_FILE" ]; then
        pid=$(cat "$PID_FILE" 2>/dev/null || true)
        if [ -n "${pid:-}" ] && kill -0 "$pid" 2>/dev/null; then
            kill -TERM "$pid" 2>/dev/null || true
            for _ in $(seq 1 50); do
                kill -0 "$pid" 2>/dev/null || break
                sleep 0.1
            done
            kill -KILL "$pid" 2>/dev/null || true
        fi
    fi
    cleanup
    log "stopped; nft table and dummy interface removed"
}

status() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null; then
        log "rawveil is running (pid $(cat "$PID_FILE"))"
    else
        log "rawveil is not running"
    fi
    if nft list table netdev "$NFT_TABLE" >/dev/null 2>&1; then
        log "nft table netdev/$NFT_TABLE exists"
    fi
    if ip link show "$DUMMY" >/dev/null 2>&1; then
        log "dummy $DUMMY exists"
    fi
}

usage() {
    cat >&2 <<EOF
Usage: $0 {run|start|stop|status|cleanup}

  run/start   set up capture and run RawVeil in the foreground
  stop        stop RawVeil and remove nft/dummy state
  status      show process/table/interface state
  cleanup     remove nft/dummy state without touching RawVeil

Environment:
  RAWVEIL_IFACE       uplink interface (default: auto-detect)
  RAWVEIL_CONFIG      config path (default: /etc/rawveil/rawveil.conf)
  RAWVEIL_DUMMY       capture dummy (default: rvhost0)
  RAWVEIL_NFT_TABLE   nft table (default: rawveil_host)
  RAWVEIL_LOG_LEVEL   log level (default: info)
EOF
}

case "${1:-run}" in
    run|start) run ;;
    stop) stop ;;
    status) status ;;
    cleanup) need_root; cleanup; log "cleanup done" ;;
    -h|--help|help) usage ;;
    *) usage; exit 2 ;;
esac

