#!/bin/bash
#
# RawVeil host supervisor.
#
# It owns the temporary host-side state: the dummy capture interface, the
# nftables netdev table, and the optional AmneziaWG interface.  None of these
# are persistent.  Whenever this script exits (normal shutdown, signal,
# RawVeil crash) the table, dummy and helper-started AWG are removed.
#
set -u
[ -n "${RAWVEIL_DEBUG:-}" ] && set -x

PROGRAM=${0##*/}
CONFIG=${RAWVEIL_CONFIG:-/etc/rawveil/rawveil.conf}
BIN=${RAWVEIL_BIN:-/usr/local/bin/rawveil}
STATE_DIR=${RAWVEIL_STATE_DIR:-/run/rawveil-host}
PID_FILE=${RAWVEIL_PID_FILE:-$STATE_DIR/rawveil.pid}
STATS_FILE=${RAWVEIL_STATS_FILE:-$STATE_DIR/rawveil.stats}
DUMMY=${RAWVEIL_DUMMY:-rvhost0}
NFT_TABLE=${RAWVEIL_NFT_TABLE:-rawveil_host}
QUIC_TABLE=${RAWVEIL_QUIC_TABLE:-rawveil_quic}
QUIC_MODE=${RAWVEIL_QUIC_MODE:-pass}
DNS_TABLE=${RAWVEIL_DNS_TABLE:-rawveil_dns}
DNS_MODE=${RAWVEIL_DNS_MODE:-off}
DNS_PORT=${RAWVEIL_DNS_PORT:-5353}
FWD_MODE=${RAWVEIL_FWD_MODE:-fwd}
AWG_CONFIG=${RAWVEIL_AWG_CONFIG-/etc/rawveil/awg/default_awg.conf}
AWG_MODE=${RAWVEIL_AWG_MODE:-auto}
AWG_IFACE=${RAWVEIL_AWG_IFACE:-}
AWG_STARTED=0
AWG_ACTIVE=0
AWG_RUNTIME=
AWG_STATE_FILE=$STATE_DIR/awg-started
LOG_LEVEL=${RAWVEIL_LOG_LEVEL:-info}
IFACE=${RAWVEIL_IFACE:-}
CREATED_DUMMY=0

log() { printf '%s: %s\n' "$PROGRAM" "$*" >&2; }
die() { log "ERROR: $*"; exit 1; }

need_root() {
    [ "$(id -u)" -eq 0 ] || die "run as root"
}

default_iface() {
    ip -o -4 route show to default 2>/dev/null |
        awk '{ for (i = 1; i <= NF; i++) if ($i == "dev") { print $(i + 1); exit } }'
}

config_warp_enabled() {
    local value
    value=$(awk '
        BEGIN { in_warp = 0 }
        /^\[/ {
            in_warp = ($0 ~ /^\[[[:space:]]*warp[[:space:]]*\][[:space:]]*$/)
            next
        }
        in_warp && /^[[:space:]]*enabled[[:space:]]*=/ {
            sub(/^[^=]*=[[:space:]]*/, "", $0)
            sub(/[[:space:]]*#.*/, "", $0)
            gsub(/[[:space:]]/, "", $0)
            value = $0
        }
        END { print value }
    ' "$CONFIG" 2>/dev/null)
    [ "$value" = "true" ] || [ "$value" = "yes" ] || [ "$value" = "1" ]
}

awg_derive_iface() {
    local base
    [ -n "$AWG_IFACE" ] && return 0
    [ -n "$AWG_CONFIG" ] || return 0
    base=${AWG_CONFIG##*/}
    AWG_IFACE=${base%.conf}
}

awg_route_leak() {
    local iface=$1
    [ -n "$iface" ] || return 1
    ip -4 route show table all 2>/dev/null |
        grep -q "default .*dev $iface" && return 0
    ip -6 route show table all 2>/dev/null |
        grep -q "default .*dev $iface" && return 0
    ip -4 route get 1.1.1.1 2>/dev/null |
        grep -q "dev $iface" && return 0
    return 1
}

awg_cleanup_rules() {
    local iface=$1 table
    [ -n "$iface" ] || return 0
    command -v awg >/dev/null 2>&1 || return 0
    table=$(awg show "$iface" fwmark 2>/dev/null | awk '{print $1}' | head -1)
    case "$table" in
        ''|off|*[!0-9]*) return 0 ;;
    esac
    while ip -4 rule show 2>/dev/null | grep -q "lookup $table"; do
        ip -4 rule del table "$table" >/dev/null 2>&1 || break
    done
    while ip -4 rule show 2>/dev/null |
          grep -q "lookup main suppress_prefixlength 0"; do
        ip -4 rule del table main suppress_prefixlength 0 \
            >/dev/null 2>&1 || break
    done
    while ip -6 rule show 2>/dev/null | grep -q "lookup $table"; do
        ip -6 rule del table "$table" >/dev/null 2>&1 || break
    done
    while ip -6 rule show 2>/dev/null |
          grep -q "lookup main suppress_prefixlength 0"; do
        ip -6 rule del table main suppress_prefixlength 0 \
            >/dev/null 2>&1 || break
    done
}

awg_force_cleanup() {
    local iface=$1
    local runtime=$2
    awg_endpoint_clear
    awg_cleanup_rules "$iface"
    if [ -n "$runtime" ] && command -v awg-quick >/dev/null 2>&1; then
        awg-quick down "$runtime" >/dev/null 2>&1 || true
    fi
    if [ -n "$iface" ] && ip link show "$iface" >/dev/null 2>&1; then
        while ip -4 route show default dev "$iface" 2>/dev/null | grep -q .; do
            ip -4 route del default dev "$iface" >/dev/null 2>&1 || break
        done
        while ip -6 route show default dev "$iface" 2>/dev/null | grep -q .; do
            ip -6 route del default dev "$iface" >/dev/null 2>&1 || break
        done
        ip link del "$iface" >/dev/null 2>&1 || true
        log "AWG emergency cleanup removed $iface"
    fi
}

awg_endpoint_clear() {
    local family ip
    [ -f "$STATE_DIR/awg-endpoints" ] || return 0
    while read -r family ip; do
        [ -n "${family:-}" ] && [ -n "${ip:-}" ] || continue
        if [ "$family" = 4 ]; then
            ip -4 route del "$ip/32" proto 246 >/dev/null 2>&1 || true
        else
            ip -6 route del "$ip/32" proto 246 >/dev/null 2>&1 || true
        fi
    done < "$STATE_DIR/awg-endpoints"
    rm -f "$STATE_DIR/awg-endpoints" 2>/dev/null || true
}

awg_endpoint_protect() {
    local endpoint host ip gw4 gw6
    [ -n "$AWG_CONFIG" ] || return 0
    endpoint=$(awk -F= '
        /^[[:space:]]*Endpoint[[:space:]]*=/ {
            value = $2
            sub(/^[[:space:]]+/, "", value)
            sub(/[[:space:]]+$/, "", value)
        }
        END { print value }
    ' "$AWG_CONFIG" 2>/dev/null)
    [ -n "$endpoint" ] || return 0
    endpoint=${endpoint%%,*}
    case "$endpoint" in
        \[*\]:*)
            host=${endpoint#\[}
            host=${host%%\]*}
            ;;
        *)
            host=${endpoint%:*}
            ;;
    esac
    [ -n "$host" ] || return 0

    gw4=$(ip -4 route show default 2>/dev/null |
          awk '/^default/ { for (i = 1; i <= NF; i++) if ($i == "via") { print $(i + 1); exit } }')
    gw6=$(ip -6 route show default 2>/dev/null |
          awk '/^default/ { for (i = 1; i <= NF; i++) if ($i == "via") { print $(i + 1); exit } }')

    getent ahosts "$host" 2>/dev/null | awk '{ print $1 }' | sort -u |
    while read -r ip; do
        [ -n "$ip" ] || continue
        if printf '%s' "$ip" | grep -q ':'; then
            [ -n "$gw6" ] || continue
            if ! ip -6 route show exact "$ip/32" 2>/dev/null | grep -q .; then
                if ip -6 route add "$ip/32" via "$gw6" dev "$IFACE" \
                       proto 246 >/dev/null 2>&1; then
                    printf '6 %s\n' "$ip" >> "$STATE_DIR/awg-endpoints"
                fi
            fi
        else
            [ -n "$gw4" ] || continue
            if ! ip -4 route show exact "$ip/32" 2>/dev/null | grep -q .; then
                if ip -4 route add "$ip/32" via "$gw4" dev "$IFACE" \
                       proto 246 >/dev/null 2>&1; then
                    printf '4 %s\n' "$ip" >> "$STATE_DIR/awg-endpoints"
                fi
            fi
        fi
    done
}

awg_prepare() {
    local src runtime
    [ -n "$AWG_CONFIG" ] || return 0
    if [ "$AWG_MODE" = "off" ]; then
        log "AWG disabled (RAWVEIL_AWG_MODE=off)"
        awg_down
        return 1
    fi
    if [ "$AWG_MODE" = "auto" ] && ! config_warp_enabled; then
        log "AWG disabled because [warp] enabled=false in $CONFIG"
        awg_down
        return 1
    fi
    awg_derive_iface
    [ -n "$AWG_IFACE" ] || return 0

    if ! command -v awg-quick >/dev/null 2>&1; then
        log "WARNING: awg-quick is not installed; AWG disabled"
        return 1
    fi
    [ -r "$AWG_CONFIG" ] || {
        log "WARNING: AWG config not readable: $AWG_CONFIG"
        return 1
    }

    mkdir -p "$STATE_DIR/awg"
    src=$AWG_CONFIG
    # Keep the runtime basename equal to the interface name so awg-quick and
    # RawVeil derive exactly the same interface, including an explicit override.
    runtime=$STATE_DIR/awg/${AWG_IFACE}.conf
    # awg-quick must not install a default route or rewrite resolver config.
    # RawVeil installs only per-destination routes via the AWG interface.
    awk '
        /^\[Interface\][[:space:]]*$/ {
            print;
            print "Table = off";
            in_interface = 1;
            next;
        }
        /^\[/ { in_interface = 0 }
        in_interface && /^[[:space:]]*Table[[:space:]]*=/ { next }
        in_interface && /^[[:space:]]*DNS[[:space:]]*=/ { next }
        { print }
    ' "$src" > "$runtime" || {
        log "WARNING: cannot prepare AWG config $src"
        return 1
    }
    chmod 600 "$runtime"
    if ! grep -Eiq '^[[:space:]]*Table[[:space:]]*=[[:space:]]*off[[:space:]]*$' \
            "$runtime"; then
        log "ERROR: cannot force Table = off in AWG runtime config"
        return 1
    fi
    AWG_RUNTIME=$runtime

    if ip link show "$AWG_IFACE" >/dev/null 2>&1; then
        if awg_route_leak "$AWG_IFACE"; then
            log "WARNING: existing AWG interface has a default-route leak; resetting it"
            awg_force_cleanup "$AWG_IFACE" "$runtime"
        else
            log "AWG interface $AWG_IFACE already exists; using it"
            awg_endpoint_protect
            AWG_STARTED=1
            AWG_ACTIVE=1
            printf '%s\n%s\n' "$AWG_IFACE" "$runtime" > "$AWG_STATE_FILE"
            chmod 600 "$AWG_STATE_FILE" 2>/dev/null || true
            return 0
        fi
    fi
    if ! awg-quick up "$runtime"; then
        awg_force_cleanup "$AWG_IFACE" "$runtime"
        log "WARNING: awg-quick up failed; AWG disabled"
        AWG_ACTIVE=0
        return 1
    fi

    # Fail-safe: this is split routing.  If awg-quick (or a malformed
    # user config) installed a default route, all traffic would disappear
    # into the tunnel.  Disable AWG instead of taking the host offline.
    if awg_route_leak "$AWG_IFACE"; then
        log "ERROR: AWG installed a default route; disabling AWG for safety"
        awg_force_cleanup "$AWG_IFACE" "$runtime"
        AWG_ACTIVE=0
        return 1
    fi

    awg_endpoint_protect
    AWG_STARTED=1
    AWG_ACTIVE=1
    printf '%s\n%s\n' "$AWG_IFACE" "$runtime" > "$AWG_STATE_FILE"
    chmod 600 "$AWG_STATE_FILE" 2>/dev/null || true
    log "AWG started on $AWG_IFACE from $src"
    return 0
}

awg_down() {
    local runtime=$AWG_RUNTIME
    local iface=$AWG_IFACE

    # State is persisted because "stop"/systemd ExecStop runs in a new process
    # and must be able to tear down an AWG interface started by "run".
    awg_endpoint_clear
    if [ -f "$AWG_STATE_FILE" ]; then
        iface=$(sed -n '1p' "$AWG_STATE_FILE" 2>/dev/null || true)
        runtime=$(sed -n '2p' "$AWG_STATE_FILE" 2>/dev/null || true)
    fi
    awg_cleanup_rules "$iface"
    if [ -f "$AWG_STATE_FILE" ]; then
        if [ -n "$runtime" ] && command -v awg-quick >/dev/null 2>&1; then
            awg-quick down "$runtime" >/dev/null 2>&1 || true
            log "AWG stopped (${iface:-unknown})"
        elif [ -n "$iface" ]; then
            # Last-resort cleanup if the tools disappeared after startup.
            ip link del "$iface" >/dev/null 2>&1 || true
            log "AWG interface removed (${iface})"
        fi
        rm -f "$AWG_STATE_FILE" 2>/dev/null || true
    elif [ "$AWG_STARTED" -eq 1 ] && [ -n "$runtime" ]; then
        awg-quick down "$runtime" >/dev/null 2>&1 || true
        log "AWG stopped ($iface)"
    fi
    AWG_STARTED=0
    AWG_ACTIVE=0
}

cleanup() {
    # Idempotent; must never abort shutdown because a rule/interface vanished.
    # If an operator calls "cleanup" while RawVeil is still running, stop it
    # first: deleting the capture dummy under a live capture gives the
    # misleading "recvmmsg: Network is down" error.
    if [ -f "$PID_FILE" ]; then
        pid=$(cat "$PID_FILE" 2>/dev/null || true)
        if [ -n "${pid:-}" ] && kill -0 "$pid" 2>/dev/null; then
            kill -TERM "$pid" 2>/dev/null || true
            for _ in $(seq 1 30); do
                kill -0 "$pid" 2>/dev/null || break
                sleep 0.1
            done
            kill -KILL "$pid" 2>/dev/null || true
        fi
    fi
    awg_down
    # Recovery path for an interface left by an older helper: if it is still
    # there and still owns a default route, remove the leak even when the
    # state file is missing.
    if [ "$AWG_STARTED" -eq 0 ] && [ -z "$AWG_IFACE" ]; then
        awg_derive_iface
    fi
    if [ "$AWG_STARTED" -eq 0 ] && [ -n "$AWG_IFACE" ] &&
       ip link show "$AWG_IFACE" >/dev/null 2>&1; then
        awg_cleanup_rules "$AWG_IFACE"
        if awg_route_leak "$AWG_IFACE"; then
            log "WARNING: removing leaked AWG default route for $AWG_IFACE"
            awg_force_cleanup "$AWG_IFACE" "${AWG_RUNTIME:-}"
        fi
    fi
    nft delete table netdev "$NFT_TABLE" >/dev/null 2>&1 || true
    nft delete table inet "$QUIC_TABLE" >/dev/null 2>&1 || true
    nft delete table inet "$DNS_TABLE" >/dev/null 2>&1 || true
    if [ "$CREATED_DUMMY" -eq 1 ] ||
       [ -f "$STATE_DIR/dummy-created" ]; then
        ip link del "$DUMMY" >/dev/null 2>&1 || true
        CREATED_DUMMY=0
    fi
    rm -f "$PID_FILE" "$STATS_FILE" "$STATE_DIR/dummy-created" 2>/dev/null || true
}

setup_network() {
    command -v nft >/dev/null 2>&1 || die "nft is required"
    command -v ip >/dev/null 2>&1 || die "ip is required"
    [ -x "$BIN" ] || die "rawveil binary not found: $BIN"
    [ -r "$CONFIG" ] || die "config not found: $CONFIG"

    if [ -z "$IFACE" ]; then
        IFACE=$(default_iface)
    fi
    [ -n "$IFACE" ] || die "cannot detect default uplink; set RAWVEIL_IFACE"
    ip link show "$IFACE" >/dev/null 2>&1 || die "unknown uplink: $IFACE"

    # Bring up the selected AmneziaWG profile before RawVeil installs routes.
    # Failure is non-fatal: RawVeil then runs without AWG routing.
    awg_prepare || true

    # Remove leftovers from an earlier crash before creating new state.
    nft delete table netdev "$NFT_TABLE" >/dev/null 2>&1 || true
    nft delete table inet "$QUIC_TABLE" >/dev/null 2>&1 || true
    nft delete table inet "$DNS_TABLE" >/dev/null 2>&1 || true
    if ip link show "$DUMMY" >/dev/null 2>&1; then
        ip link del "$DUMMY" >/dev/null 2>&1 || true
    fi

    ip link add "$DUMMY" type dummy || die "cannot create $DUMMY"
    CREATED_DUMMY=1
    touch "$STATE_DIR/dummy-created"
    ip link set "$DUMMY" up mtu 65535 || die "cannot configure $DUMMY"

    nft add table netdev "$NFT_TABLE" || die "cannot create nft table"
    nft 'add chain netdev '"$NFT_TABLE"' out { type filter hook egress device "'"$IFACE"'" priority 0; }' ||
        die "cannot create nft chain"

    case "$FWD_MODE" in
        fwd) FWD_ACTION="fwd to $DUMMY" ;;
        dupdrop) FWD_ACTION="dup to $DUMMY drop" ;;
        *) die "RAWVEIL_FWD_MODE must be fwd or dupdrop" ;;
    esac
    case "$QUIC_MODE" in
        pass|block|fragment|fake) ;;
        *) die "RAWVEIL_QUIC_MODE must be pass, block, fragment or fake" ;;
    esac
    case "$DNS_MODE" in
        off|system|dot|doh) ;;
        *) die "RAWVEIL_DNS_MODE must be off, system, dot or doh" ;;
    esac

    # Own frames must not be redirected back into the capture dummy.
    nft add rule netdev "$NFT_TABLE" out \
        ether type ip ip id 0x5256 counter accept ||
        die "cannot add IPv4 marker rule"
    nft add rule netdev "$NFT_TABLE" out \
        ether type ip6 ip6 flowlabel 0x5256 counter accept ||
        die "cannot add IPv6 marker rule"

    # Do not steal pure ACKs/SYN/FIN.  They must go directly to the uplink.
    nft add rule netdev "$NFT_TABLE" out \
        'ether type ip tcp dport 443 meta length <= 100 counter accept' ||
        die "cannot add short-IPv4-TCP rule"
    nft add rule netdev "$NFT_TABLE" out \
        'ether type ip6 tcp dport 443 meta length <= 100 counter accept' ||
        die "cannot add short-IPv6-TCP rule"

    nft add rule netdev "$NFT_TABLE" out \
        ether type ip tcp dport 443 counter $FWD_ACTION ||
        die "cannot add IPv4 TCP/443 capture rule"
    nft add rule netdev "$NFT_TABLE" out \
        ether type ip6 tcp dport 443 counter $FWD_ACTION ||
        die "cannot add IPv6 TCP/443 capture rule"

    for port in 2053 2083 2087 2096 8443; do
        nft add rule netdev "$NFT_TABLE" out \
            ether type ip tcp dport "$port" counter $FWD_ACTION ||
            die "cannot add IPv4 TCP/$port capture rule"
        nft add rule netdev "$NFT_TABLE" out \
            ether type ip6 tcp dport "$port" counter $FWD_ACTION ||
            die "cannot add IPv6 TCP/$port capture rule"
    done

    if [ "$QUIC_MODE" = "fragment" ] || [ "$QUIC_MODE" = "fake" ]; then
        nft add rule netdev "$NFT_TABLE" out \
            ether type ip udp dport 443 counter $FWD_ACTION ||
            die "cannot add IPv4 UDP/443 capture rule"
        nft add rule netdev "$NFT_TABLE" out \
            ether type ip6 udp dport 443 counter $FWD_ACTION ||
            die "cannot add IPv6 UDP/443 capture rule"
    fi

    nft add rule netdev "$NFT_TABLE" out \
        ether type ip udp dport 50000-50099 counter $FWD_ACTION ||
        die "cannot add IPv4 Discord UDP capture rule"
    nft add rule netdev "$NFT_TABLE" out \
        ether type ip6 udp dport 50000-50099 counter $FWD_ACTION ||
        die "cannot add IPv6 Discord UDP capture rule"

    # QUIC block: generate local ICMP port-unreachable so browsers fall back
    # to TCP immediately.  This is nftables, not NFQUEUE, and covers output
    # traffic before RawVeil's capture hook.
    if [ "$QUIC_MODE" = "block" ]; then
        nft add table inet "$QUIC_TABLE" || die "cannot create QUIC block table"
        nft 'add chain inet '"$QUIC_TABLE"' out { type filter hook output priority -10; policy accept; }' ||
            die "cannot create QUIC block chain"
        if ! nft add rule inet "$QUIC_TABLE" out \
            udp dport 443 counter reject with icmpx type port-unreachable;
        then
            # Older nftables versions lack icmpx; a plain drop still forces
            # the client to fall back after its QUIC timeout.
            nft add rule inet "$QUIC_TABLE" out \
                udp dport 443 counter drop ||
                die "cannot add QUIC reject/drop rule"
        fi
    fi

    # Redirect plain DNS (UDP/TCP 53) to the RawVeil proxy.  Loopback is
    # excluded so systemd-resolved's 127.0.0.53 stub keeps working; its
    # external upstream queries are caught by these rules.
    if [ "$DNS_MODE" = "dot" ] || [ "$DNS_MODE" = "doh" ]; then
        nft add table inet "$DNS_TABLE" || die "cannot create DNS table"
        nft 'add chain inet '"$DNS_TABLE"' out { type nat hook output priority -100; policy accept; }' ||
            die "cannot create DNS redirect chain"
        nft add rule inet "$DNS_TABLE" out \
            ip daddr != 127.0.0.0/8 udp dport 53 counter redirect to :"$DNS_PORT" ||
            die "cannot add IPv4 UDP DNS redirect"
        nft add rule inet "$DNS_TABLE" out \
            ip6 daddr != ::1 udp dport 53 counter redirect to :"$DNS_PORT" ||
            die "cannot add IPv6 UDP DNS redirect"
        nft add rule inet "$DNS_TABLE" out \
            ip daddr != 127.0.0.0/8 tcp dport 53 counter redirect to :"$DNS_PORT" ||
            die "cannot add IPv4 TCP DNS redirect"
        nft add rule inet "$DNS_TABLE" out \
            ip6 daddr != ::1 tcp dport 53 counter redirect to :"$DNS_PORT" ||
            die "cannot add IPv6 TCP DNS redirect"
    fi

    log "capture=$DUMMY uplink=$IFACE table=netdev/$NFT_TABLE quic=$QUIC_MODE dns=$DNS_MODE fwd=$FWD_MODE"
}

run() {
    need_root
    mkdir -p "$STATE_DIR"

    # Set the trap before touching the network: a failed nft command must not
    # leave a half-configured capture table behind.
    trap 'rc=$?; cleanup; exit $rc' EXIT
    trap 'exit 130' INT
    trap 'exit 143' TERM

    setup_network

    AWG_ARGS=()
    if [ "$AWG_ACTIVE" -eq 1 ]; then
        AWG_ARGS+=(--warp --awg-config "${AWG_RUNTIME:-$AWG_CONFIG}")
    else
        # Explicitly disable a config-file awg_config when AWG is unavailable.
        AWG_ARGS+=(--no-warp --awg-config "")
    fi

    QUIC_ARGS=()
    case "$QUIC_MODE" in
        fragment)
            QUIC_ARGS+=(--profile quic_fragment.enabled=true
                        --profile quic_fragment.filter_proto=udp
                        --profile quic_fragment.filter_ports=443
                        --profile quic_fragment.filter_l7=quic_initial
                        --profile quic_fragment.strategy=quic_fragment
                        --profile quic_fragment.frag_pos=24
                        --profile quic_fragment.frag_count=2
                        --profile quic_fragment.replace_original=true
                        --profile youtube_quic.enabled=false)
            ;;
        fake)
            QUIC_ARGS+=(--profile quic_fragment.enabled=false
                        --profile youtube_quic.enabled=true
                        --profile youtube_quic.filter_proto=udp
                        --profile youtube_quic.filter_ports=443
                        --profile youtube_quic.filter_l7=quic
                        --profile youtube_quic.strategy=fake_quic_initial
                        --profile youtube_quic.fake_count=1
                        --profile youtube_quic.fake_ttl=0
                        --profile youtube_quic.session_freeze_after=2
                        --profile youtube_quic.replace_original=true)
            ;;
        block|pass)
            QUIC_ARGS+=(--profile quic_fragment.enabled=false
                        --profile youtube_quic.enabled=false)
            ;;
    esac

    "$BIN" on --foreground \
        --config "$CONFIG" \
        --interface "$DUMMY" \
        --send-interface "$IFACE" \
        --capture-mode redirect \
        --doh-mode "$DNS_MODE" \
        --dns-listen "127.0.0.1:$DNS_PORT" \
        "${AWG_ARGS[@]}" \
        --pid-file "$PID_FILE" \
        --stats-file "$STATS_FILE" \
        --log-level "$LOG_LEVEL" \
        --profile discord_tls.enabled=true \
        --profile discord_tls.filter_proto=tcp \
        --profile discord_tls.filter_ports=443 \
        --profile discord_tls.filter_l7=tls \
        --profile discord_tls.strategy=multisplit \
        --profile discord_tls.split_sni=middle \
        --profile discord_tls.split_reverse=true \
        --profile discord_tls.desync_data_packets=64 \
        --profile discord_tls.segments=2 \
        "${QUIC_ARGS[@]}" &
    child=$!

    # Drop poisoned entries cached by systemd-resolved before the redirect.
    if { [ "$DNS_MODE" = "dot" ] || [ "$DNS_MODE" = "doh" ]; } &&
       command -v resolvectl >/dev/null 2>&1; then
        sleep 0.5
        resolvectl flush-caches >/dev/null 2>&1 || true
    fi

    # If the supervisor is killed while RawVeil survives, this watcher removes
    # the nft table as soon as RawVeil exits.
    (
        while kill -0 "$child" 2>/dev/null; do sleep 1; done
        awg_down
        nft delete table netdev "$NFT_TABLE" >/dev/null 2>&1 || true
        ip link del "$DUMMY" >/dev/null 2>&1 || true
    ) &
    watcher=$!

    wait "$child"
    rc=$?
    kill "$watcher" >/dev/null 2>&1 || true
    wait "$watcher" >/dev/null 2>&1 || true
    exit "$rc"
}

stop() {
    need_root
    if [ -f "$PID_FILE" ]; then
        pid=$(cat "$PID_FILE" 2>/dev/null || true)
        if [ -n "${pid:-}" ] && kill -0 "$pid" 2>/dev/null; then
            kill -TERM "$pid" 2>/dev/null || true
            for _ in $(seq 1 50); do
                kill -0 "$pid" 2>/dev/null || break
                sleep 0.1
            done
            kill -KILL "$pid" 2>/dev/null || true
        fi
    fi
    cleanup
    log "stopped; nft table and dummy interface removed"
}

status() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null; then
        log "rawveil is running (pid $(cat "$PID_FILE"))"
    else
        log "rawveil is not running"
    fi
    if nft list table netdev "$NFT_TABLE" >/dev/null 2>&1; then
        log "nft table netdev/$NFT_TABLE exists"
    fi
    if nft list table inet "$QUIC_TABLE" >/dev/null 2>&1; then
        log "nft table inet/$QUIC_TABLE exists (QUIC block)"
    fi
    if nft list table inet "$DNS_TABLE" >/dev/null 2>&1; then
        log "nft table inet/$DNS_TABLE exists (DNS redirect)"
    fi
    if ip link show "$DUMMY" >/dev/null 2>&1; then
        log "dummy $DUMMY exists"
    fi
    if [ -f "$AWG_STATE_FILE" ]; then
        awg_iface=$(sed -n '1p' "$AWG_STATE_FILE" 2>/dev/null || true)
        if [ -n "$awg_iface" ] && ip link show "$awg_iface" >/dev/null 2>&1; then
            log "AWG $awg_iface is up (managed by RawVeil)"
        else
            log "AWG state file exists but interface is down"
        fi
    elif [ -n "$AWG_CONFIG" ]; then
        awg_derive_iface
        if ip link show "$AWG_IFACE" >/dev/null 2>&1; then
            log "AWG $AWG_IFACE is up (config $AWG_CONFIG)"
        else
            log "AWG $AWG_IFACE is not up"
        fi
    fi
}

usage() {
    cat >&2 <<EOF
Usage: $0 {run|start|stop|status|cleanup}

  run/start   set up capture and run RawVeil in the foreground
  stop        stop RawVeil and remove nft/dummy/AWG state
  status      show process/table/interface/AWG state
  cleanup     remove nft/dummy/AWG state without touching RawVeil

Environment:
  RAWVEIL_IFACE       uplink interface (default: auto-detect)
  RAWVEIL_CONFIG      config path (default: /etc/rawveil/rawveil.conf)
  RAWVEIL_DUMMY       capture dummy (default: rvhost0)
  RAWVEIL_NFT_TABLE   nft table (default: rawveil_host)
  RAWVEIL_FWD_MODE    fwd (default) or dupdrop
  RAWVEIL_QUIC_MODE   pass (default), block, fragment, fake
  RAWVEIL_QUIC_TABLE  inet table used by QUIC block (default: rawveil_quic)
  RAWVEIL_DNS_MODE    off (default), system, dot, doh
  RAWVEIL_DNS_TABLE   inet table used by DNS redirect (default: rawveil_dns)
  RAWVEIL_DNS_PORT    local DNS proxy port (default: 5353)
  RAWVEIL_AWG_CONFIG  AmneziaWG .conf started/stopped with RawVeil
  RAWVEIL_AWG_MODE    auto (default), on, off; auto follows [warp] enabled
  RAWVEIL_AWG_IFACE   override AWG interface name
  RAWVEIL_LOG_LEVEL   log level (default: info)
EOF
}

case "${1:-run}" in
    run|start) run ;;
    stop) stop ;;
    status) status ;;
    cleanup) need_root; cleanup; log "cleanup done" ;;
    -h|--help|help) usage ;;
    *) usage; exit 2 ;;
esac

