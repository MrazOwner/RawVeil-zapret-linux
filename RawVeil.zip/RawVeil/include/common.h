/*
 * RawVeil - common definitions and small helpers.
 *
 * The project relies on POSIX/Linux APIs (getline, strdup, pthread_rwlock,
 * AF_PACKET, sendmmsg, ...), therefore _GNU_SOURCE is defined here and in
 * the Makefile.
 */
#ifndef RV_COMMON_H
#define RV_COMMON_H

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stddef.h>
#include <stdint.h>
#include <string.h>

#define RV_VERSION "0.1.0"
#define RV_PROGRAM_NAME "rawveil"

#define RV_DEFAULT_CONFIG "/etc/rawveil/rawveil.conf"
#define RV_DEFAULT_PID_FILE "/var/run/rawveil.pid"
#define RV_DEFAULT_STATS_FILE "/var/run/rawveil.stats"

#define RV_MAX_PATH 512
#define RV_MAX_STR 256
#define RV_MAX_NAME 64

/* Must stay in sync with sizeof(((struct ifreq *)0)->ifr_name). */
#define RV_IFNAMSIZ 16

#define RV_MAX_PROFILES 64
#define RV_MAX_PROFILE_OVERRIDES 64
#define RV_MAX_THREADS 64

/* Copy a string, always NUL-terminating. dstsz == 0 is a no-op. */
static inline void rv_strlcpy(char *dst, size_t dstsz, const char *src)
{
    size_t n;

    if (dst == NULL || dstsz == 0) {
        return;
    }
    if (src == NULL) {
        dst[0] = '\0';
        return;
    }
    n = strlen(src);
    if (n >= dstsz) {
        n = dstsz - 1;
    }
    memcpy(dst, src, n);
    dst[n] = '\0';
}

/* Trim ASCII whitespace in place and return the new start. */
static inline char *rv_trim(char *s)
{
    char *end;

    if (s == NULL) {
        return NULL;
    }
    while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') {
        s++;
    }
    end = s + strlen(s);
    while (end > s &&
           (end[-1] == ' ' || end[-1] == '\t' ||
            end[-1] == '\r' || end[-1] == '\n')) {
        end--;
    }
    *end = '\0';
    return s;
}

#endif /* RV_COMMON_H */
