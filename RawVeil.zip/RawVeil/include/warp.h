#ifndef RV_WARP_H
#define RV_WARP_H

#include <stddef.h>
#include <stdint.h>

#include "config.h"

typedef struct rv_warp rv_warp;

typedef struct rv_warp_entry {
    int family;
    uint8_t prefix;
    uint8_t addr[16];
} rv_warp_entry;

/*
 * Build the WARP destination set. Reads the IP/CIDR list and resolves domain
 * names through the system resolver (getaddrinfo), i.e. DoH mode=system.
 * Missing files are logged as warnings; they are not a fatal error.
 */
rv_warp *rv_warp_create(const rv_warp_config *cfg, char *err, size_t errlen);
int rv_warp_reload(rv_warp *warp, const rv_warp_config *cfg,
                   char *err, size_t errlen);
void rv_warp_destroy(rv_warp *warp);

/* Thread-safe: 1 if the address is in the WARP list, 0 otherwise. */
int rv_warp_should_mark(rv_warp *warp, int family, const void *addr);

size_t rv_warp_ip_count(rv_warp *warp);
size_t rv_warp_domain_count(rv_warp *warp);
int rv_warp_enabled(rv_warp *warp);

/*
 * Snapshot all exact IPs and CIDRs for nftables set generation.
 * The caller frees *out with free().
 */
int rv_warp_copy_entries(rv_warp *warp, rv_warp_entry **out, size_t *count);

#endif /* RV_WARP_H */
