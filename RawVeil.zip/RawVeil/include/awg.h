#ifndef RV_AWG_H
#define RV_AWG_H

#include <stddef.h>

#include "common.h"

typedef struct rv_awg_config {
    char path[RV_MAX_PATH];
    char interface[RV_IFNAMSIZ];
    char address[RV_MAX_STR * 2];
    char allowed_ips[RV_MAX_STR * 2];
    char table[64];
    int mtu;
    int fwmark;              /* -1 when not present */
    int has_ipv4;
    int has_ipv6;
    int default_route_v4;
    int default_route_v6;
} rv_awg_config;

/*
 * Parse an AmneziaWG/WireGuard .conf. PrivateKey is ignored; only transport
 * metadata needed for policy routing is kept. The AWG interface name is
 * derived from the config filename (awg0.conf -> awg0).
 *
 * Returns 0 on success, -1 on error.
 */
int rv_awg_load(const char *path, rv_awg_config *out,
                char *err, size_t errlen);

int rv_awg_interface_index(const rv_awg_config *cfg);

#endif /* RV_AWG_H */
