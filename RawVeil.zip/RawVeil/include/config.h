#ifndef RV_CONFIG_H
#define RV_CONFIG_H

#include <stddef.h>
#include <stdint.h>

#include "common.h"
#include "log.h"

typedef struct rv_kv {
    char *key;
    char *value;
} rv_kv;

typedef struct rv_profile {
    char name[RV_MAX_NAME];
    rv_kv *kv;
    size_t kv_count;
    size_t kv_cap;
} rv_profile;

#define RV_CAPTURE_DIRECT 0
#define RV_CAPTURE_REDIRECT 1

typedef struct rv_global_config {
    char interface[RV_IFNAMSIZ];
    /* Empty = send on the capture interface. A separate TX interface allows
     * the nftables "dup to dummy; drop" deployment described in README. */
    char send_interface[RV_IFNAMSIZ];
    /* direct: the original packet is still sent by the kernel.
     * redirect: nftables redirected/dropped the original; RawVeil must
     * re-emit every captured frame, including unhandled ones. */
    int capture_mode;
    /* Also inspect packets arriving from the server on the capture
     * interface. Responses are counted/logged but never modified. */
    int capture_incoming;
    int threads;
    int buffer_size;
    rv_log_level log_level;
    char pid_file[RV_MAX_PATH];
    char stats_file[RV_MAX_PATH];
} rv_global_config;

typedef struct rv_tracking_config {
    int tcp_timeout;
    int udp_timeout;
    int max_entries;
} rv_tracking_config;

typedef struct rv_doh_config {
    int enabled;
    char mode[32];
    char endpoint[RV_MAX_PATH];
    char format[32];
    int cache_ttl;
    int negative_ttl;
    int fallback_to_system;
    char bootstrap_ips[RV_MAX_STR];
    /* Built-in DNS proxy (DoT/DoH). */
    char listen[RV_MAX_STR];
    char servers[RV_MAX_STR];
    int strict;
    int block_plain;
    int block_other_dot;
} rv_doh_config;

typedef struct rv_warp_config {
    int enabled;
    char interface[RV_IFNAMSIZ];
    char domain_list[RV_MAX_PATH];
    char ip_list[RV_MAX_PATH];
    uint32_t mark;
    int bypass_strategies;
    /* AWG transport integration. When awg_config is set, RawVeil derives the
     * AWG interface name from the .conf filename and (if manage_routing is
     * enabled) installs nftables mark rules + an ip rule/route table. */
    char awg_config[RV_MAX_PATH];
    int manage_routing;
    int routing_mode;         /* RV_ROUTING_ROUTE or RV_ROUTING_NFT */
    int routing_table;
    int routing_priority;
} rv_warp_config;

#define RV_ROUTING_ROUTE 0
#define RV_ROUTING_NFT 1

typedef struct rv_security_config {
    char drop_privileges_to[RV_MAX_STR];
    char required_caps[RV_MAX_STR];
} rv_security_config;

typedef struct rv_config {
    rv_global_config global;
    rv_tracking_config tracking;
    rv_doh_config doh;
    rv_warp_config warp;
    rv_security_config security;
    rv_profile *profiles;
    size_t profile_count;
    size_t profile_cap;
} rv_config;

void rv_config_defaults(rv_config *cfg);
void rv_config_free(rv_config *cfg);

/*
 * Parse an INI-like configuration file.
 *
 * The caller is expected to call rv_config_defaults() first. Values found in
 * the file override defaults.
 *
 * Returns:
 *    0  file loaded successfully
 *    1  file does not exist (required == 0; defaults remain in effect)
 *   -1  parse/IO error
 */
int rv_config_load(rv_config *cfg, const char *path, int required);

/* Validate ranges and cross-field constraints. Returns 0 or -1. */
int rv_config_validate(rv_config *cfg);

/*
 * Apply a "profile_name.key=value" override (used by --profile).
 * Creates the profile if it does not exist yet.
 * Returns 0 on success, -1 on a malformed specification.
 */
int rv_config_apply_profile_override(rv_config *cfg, const char *spec);

/* Profile accessors (return NULL / default when not found). */
const char *rv_config_profile_get(const rv_config *cfg, const char *profile,
                                  const char *key);
int rv_config_profile_get_bool(const rv_config *cfg, const char *profile,
                               const char *key, int def);
int rv_config_profile_get_int(const rv_config *cfg, const char *profile,
                              const char *key, int def);

#endif /* RV_CONFIG_H */
