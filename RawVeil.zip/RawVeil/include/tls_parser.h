#ifndef RV_TLS_PARSER_H
#define RV_TLS_PARSER_H

#include <stddef.h>
#include <stdint.h>

#define RV_TLS_SNI_MAX 256

typedef struct rv_tls_info {
    int is_client_hello;
    int has_sni;
    char sni[RV_TLS_SNI_MAX];
    size_t record_len;
    /* Offset/length of the SNI host_name inside the TCP payload. */
    size_t sni_offset;
    size_t sni_len;
} rv_tls_info;

/*
 * Parse a complete TLS ClientHello record from TCP payload.
 *
 * Returns 1 when a ClientHello was parsed, 0 when the payload is not a
 * (complete) ClientHello, -1 for malformed handshake data.
 */
int rv_tls_parse_client_hello(const uint8_t *data, size_t len,
                              rv_tls_info *info);

#endif /* RV_TLS_PARSER_H */
