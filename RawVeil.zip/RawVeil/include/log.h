#ifndef RV_LOG_H
#define RV_LOG_H

#include <stddef.h>

typedef enum {
    RV_LOG_DEBUG = 0,
    RV_LOG_INFO,
    RV_LOG_WARN,
    RV_LOG_ERROR
} rv_log_level;

/* Returns 0 on success, -1 on an unknown level name. */
int rv_log_level_parse(const char *name, rv_log_level *out);
const char *rv_log_level_name(rv_log_level level);

/*
 * Initialise logging. When use_syslog is non-zero messages go to syslog,
 * otherwise to stderr. May be called more than once (e.g. before and after
 * daemonisation).
 */
int rv_log_init(rv_log_level level, int use_syslog, const char *ident);
void rv_log_shutdown(void);
void rv_log_set_level(rv_log_level level);
rv_log_level rv_log_get_level(void);

void rv_log(rv_log_level level, const char *fmt, ...)
    __attribute__((format(printf, 2, 3)));

#define LOG_DEBUG(...) rv_log(RV_LOG_DEBUG, __VA_ARGS__)
#define LOG_INFO(...)  rv_log(RV_LOG_INFO, __VA_ARGS__)
#define LOG_WARN(...)  rv_log(RV_LOG_WARN, __VA_ARGS__)
#define LOG_ERROR(...) rv_log(RV_LOG_ERROR, __VA_ARGS__)

#endif /* RV_LOG_H */
