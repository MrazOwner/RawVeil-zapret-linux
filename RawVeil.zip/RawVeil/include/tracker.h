#ifndef RV_TRACKER_H
#define RV_TRACKER_H

#include <stddef.h>
#include <stdint.h>
#include <time.h>

typedef struct rv_flow_key {
    int family;
    int proto;
    uint8_t src[16];
    uint8_t dst[16];
    uint16_t sport;
    uint16_t dport;
} rv_flow_key;

#define RV_FLOW_SNI_MAX 256

typedef struct rv_tracker_view {
    uint64_t packets_seen;
    uint64_t data_packets;
    uint64_t payload_bytes;
    int handled;
    int frozen;
    time_t first_seen;
    time_t last_seen;
    /* Cached L7 classification and SNI for the flow. */
    unsigned l7;
    char sni[RV_FLOW_SNI_MAX];
    /* Index into the compiled profile array, -1 when not selected yet. */
    int profile_index;
} rv_tracker_view;

typedef struct rv_tracker rv_tracker;

rv_tracker *rv_tracker_create(int max_entries, int tcp_timeout,
                              int udp_timeout);
void rv_tracker_destroy(rv_tracker *tracker);
void rv_tracker_clear(rv_tracker *tracker);

/*
 * Record an outgoing packet in its flow and return a snapshot.
 * Returns 1 for a newly created flow, 0 for an existing one, -1 when the
 * table is full and the packet could not be tracked.
 */
int rv_tracker_touch(rv_tracker *tracker, const rv_flow_key *key,
                     time_t now, rv_tracker_view *out);

/* Extended touch: payload_len is used for data-packet/byte counters. */
int rv_tracker_touch_ex(rv_tracker *tracker, const rv_flow_key *key,
                        time_t now, size_t payload_len,
                        rv_tracker_view *out);

/* Update strategy flags after a decision has been made. */
void rv_tracker_set_flags(rv_tracker *tracker, const rv_flow_key *key,
                          int handled, int frozen);

/* Cache L7 classification/SNI and lock the selected profile for the flow. */
void rv_tracker_set_meta(rv_tracker *tracker, const rv_flow_key *key,
                         unsigned l7, const char *sni, int profile_index);

void rv_tracker_expire(rv_tracker *tracker, time_t now);
size_t rv_tracker_count(rv_tracker *tracker);

#endif /* RV_TRACKER_H */
