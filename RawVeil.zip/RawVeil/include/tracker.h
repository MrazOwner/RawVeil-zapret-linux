#ifndef RV_TRACKER_H
#define RV_TRACKER_H

#include <stddef.h>
#include <stdint.h>
#include <time.h>

typedef struct rv_flow_key {
    int family;
    int proto;
    uint8_t src[16];
    uint8_t dst[16];
    uint16_t sport;
    uint16_t dport;
} rv_flow_key;

typedef struct rv_tracker_view {
    uint64_t packets_seen;
    int handled;
    int frozen;
    time_t first_seen;
    time_t last_seen;
} rv_tracker_view;

typedef struct rv_tracker rv_tracker;

rv_tracker *rv_tracker_create(int max_entries, int tcp_timeout,
                              int udp_timeout);
void rv_tracker_destroy(rv_tracker *tracker);
void rv_tracker_clear(rv_tracker *tracker);

/*
 * Record an outgoing packet in its flow and return a snapshot.
 * Returns 1 for a newly created flow, 0 for an existing one, -1 when the
 * table is full and the packet could not be tracked.
 */
int rv_tracker_touch(rv_tracker *tracker, const rv_flow_key *key,
                     time_t now, rv_tracker_view *out);

/* Update strategy flags after a decision has been made. */
void rv_tracker_set_flags(rv_tracker *tracker, const rv_flow_key *key,
                          int handled, int frozen);

void rv_tracker_expire(rv_tracker *tracker, time_t now);
size_t rv_tracker_count(rv_tracker *tracker);

#endif /* RV_TRACKER_H */
