#ifndef RV_DAEMON_H
#define RV_DAEMON_H

#include <stddef.h>
#include <sys/types.h>

#include "common.h"

typedef struct rv_pidfile {
    int fd;
    int active;
    char path[RV_MAX_PATH];
} rv_pidfile;

/*
 * Fork into the background, detach from the controlling terminal and
 * redirect stdio to /dev/null.
 *
 * On success the daemon child receives a write end of a readiness pipe in
 * *ready_fd and must write "OK\n" once initialisation is complete (or
 * "ERR: ...\n" on failure) and close it. The original process waits for that
 * message, so `rawveil on` correctly reports startup failures.
 *
 * Returns 0 in the daemon child, -1 on error.
 */
int rv_daemonize(int *ready_fd, char *err, size_t errlen);

/*
 * Drop root privileges to the given user. No-op when not running as root.
 * required_caps is a comma-separated list of capabilities that must remain
 * effective after setuid (CAP_NET_RAW is needed by AF_PACKET TX,
 * CAP_NET_ADMIN for future SO_MARK). Unknown capability names are rejected.
 */
int rv_drop_privileges(const char *user, const char *required_caps,
                       char *err, size_t errlen);

/*
 * Create and lock a pid file. The lock is held until rv_pidfile_remove().
 * Refuses to start when another process already holds the lock.
 */
int rv_pidfile_create(rv_pidfile *pf, const char *path,
                      char *err, size_t errlen);
void rv_pidfile_remove(rv_pidfile *pf);

/* Read a pid from a pid file. Returns 0 on success, -1 on error. */
int rv_pid_read(const char *path, pid_t *pid, char *err, size_t errlen);

/* kill(pid, 0): returns 1 when alive, 0 when not, -1 on unexpected errors. */
int rv_pid_is_alive(pid_t pid);

/*
 * Safety check used by off/status/reload: compare /proc/<pid>/comm with the
 * expected process name. Returns 1 on match, 0 on mismatch/unreadable.
 */
int rv_pid_matches_name(pid_t pid, const char *name);

/*
 * Create the stats file (if needed) and, when running as root, chown it to
 * the unprivileged daemon user so SIGUSR1 can refresh it after dropping
 * privileges. Non-fatal: returns -1 with err filled on failure.
 */
int rv_prepare_stats_file(const char *path, const char *run_as,
                          char *err, size_t errlen);

#endif /* RV_DAEMON_H */
