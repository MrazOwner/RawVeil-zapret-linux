#ifndef RV_BPF_FILTER_H
#define RV_BPF_FILTER_H

#include <stddef.h>

#include <linux/filter.h>

#define RV_BPF_MAX_INSNS 256

typedef struct rv_bpf_program {
    struct sock_filter insns[RV_BPF_MAX_INSNS];
    size_t count;
} rv_bpf_program;

/*
 * Build the egress filter used by capture.c:
 *
 *   IPv4/IPv6, TCP dst/src port 443 plus destination media ports
 *   2053, 2083, 2087, 2096, 8443,
 *   UDP port 443 or source/destination port in [50000, 50099],
 *   optionally behind one 802.1Q/QinQ VLAN tag.
 *
 * Non-first IP fragments are rejected because their L4 ports are not
 * available. Returns 0 on success, -1 if the program does not fit.
 */
int rv_bpf_build_egress_filter(rv_bpf_program *out);

#endif /* RV_BPF_FILTER_H */
