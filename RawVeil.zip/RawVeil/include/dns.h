#ifndef RV_DNS_H
#define RV_DNS_H

#include <stddef.h>
#include <stdint.h>

#include "config.h"

typedef struct rv_dns rv_dns;

typedef struct rv_dns_stats {
    uint64_t queries;
    uint64_t cache_hits;
    uint64_t upstream_ok;
    uint64_t upstream_fail;
    uint64_t servfail;
    uint64_t malformed;
} rv_dns_stats;

/*
 * Start the local DNS proxy described by [dns]/[doh].
 * Modes:
 *   off/system - no proxy is started
 *   dot        - local UDP/TCP proxy -> DNS-over-TLS
 *   doh        - local UDP/TCP proxy -> DNS-over-HTTPS (libcurl)
 *
 * The proxy binds listen (default 127.0.0.1:5353). The host helper redirects
 * outgoing port 53 to this socket with nftables.
 */
rv_dns *rv_dns_start(const rv_config *cfg, char *err, size_t errlen);
void rv_dns_stop(rv_dns *dns);
void rv_dns_get_stats(rv_dns *dns, rv_dns_stats *out);
int rv_dns_enabled(const rv_config *cfg);

#endif /* RV_DNS_H */
