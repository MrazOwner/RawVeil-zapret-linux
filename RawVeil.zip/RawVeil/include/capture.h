#ifndef RV_CAPTURE_H
#define RV_CAPTURE_H

#include <stddef.h>
#include <stdint.h>

#include "common.h"

struct rv_warp;
struct rv_engine;
typedef struct rv_capture rv_capture;

typedef struct rv_capture_stats {
    uint64_t frames_seen;       /* all frames returned by recvmmsg       */
    uint64_t outgoing;          /* PACKET_OUTGOING frames processed      */
    uint64_t incoming_ignored;  /* non-outgoing copies we skip           */
    uint64_t ipv4;
    uint64_t ipv6;
    uint64_t tcp;
    uint64_t udp;
    uint64_t other_l4;
    uint64_t warp_matches;
    uint64_t injected_ignored;
    uint64_t read_errors;
    uint64_t parse_errors;
    uint64_t truncated;
} rv_capture_stats;

/*
 * Open an AF_PACKET socket bound to ifname, install a classic-BPF filter
 * (TCP/443, UDP/443 and UDP/50000-50099, IPv4/IPv6, optional VLAN tags) and
 * prepare recvmmsg() buffers.
 *
 * The caller must have CAP_NET_RAW (usually root). The capture socket is
 * read-only; strategies send frames through the separate sender module.
 */
rv_capture *rv_capture_open(const char *ifname, int buffer_size,
                            char *err, size_t errlen);
void rv_capture_close(rv_capture *cap);

/*
 * Read and process up to one recvmmsg() batch. timeout_ms bounds the wait.
 * Returns the number of frames processed, 0 on timeout/EINTR, or -1 on a
 * fatal socket error.
 */
int rv_capture_read(rv_capture *cap, struct rv_warp *warp, uint32_t mark,
                    int warp_bypass, struct rv_engine *engine,
                    int timeout_ms);

void rv_capture_get_stats(const rv_capture *cap, rv_capture_stats *out);
const char *rv_capture_interface(const rv_capture *cap);

#endif /* RV_CAPTURE_H */
