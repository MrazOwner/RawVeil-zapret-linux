#ifndef RV_QUIC_H
#define RV_QUIC_H

#include <stddef.h>
#include <stdint.h>

#define RV_QUIC_VERSION_1 0x00000001u
#define RV_QUIC_VERSION_2 0x6b3343cfu
#define RV_QUIC_MAX_CID 20u

/*
 * Lightweight QUIC header parser.  It does not decrypt Initial packets and
 * therefore cannot recover the SNI; it only classifies the datagram and
 * extracts the fields needed by block/fragment/fake strategies.
 */
typedef struct rv_quic_info {
    int is_long;
    int is_short;
    int is_initial;
    int is_version_negotiation;
    uint32_t version;
    uint8_t dcid[RV_QUIC_MAX_CID];
    uint8_t scid[RV_QUIC_MAX_CID];
    size_t dcid_len;
    size_t scid_len;
    size_t header_len;
    size_t packet_len;      /* bytes belonging to the first QUIC packet */
    size_t payload_len;     /* packet_len - header_len */
    uint64_t token_len;
} rv_quic_info;

/*
 * Returns 1 for a plausible QUIC long/short header, 0 for "not QUIC",
 * -1 for a malformed/truncated QUIC-looking packet.
 */
int rv_quic_parse(const uint8_t *data, size_t len, rv_quic_info *info);

#endif /* RV_QUIC_H */
