#ifndef RV_STRATEGIES_H
#define RV_STRATEGIES_H

#include <stddef.h>
#include <stdint.h>
#include <time.h>

#include "config.h"
#include "packet.h"

typedef struct rv_engine rv_engine;

typedef struct rv_engine_stats {
    uint64_t matched_packets;
    uint64_t strategy_packets;
    uint64_t injected_frames;
    uint64_t resent_frames;
    uint64_t send_errors;
    uint64_t skipped_truncated;
    uint64_t passthrough_frames;
    uint64_t dropped_packets;
    uint64_t fragmented_packets;
} rv_engine_stats;

/*
 * Build the strategy engine: compiles enabled [profile.*] sections, opens an
 * AF_PACKET TX socket and a flow tracker. base_dir is used to resolve
 * relative fake_payload paths after daemonisation.
 */
rv_engine *rv_engine_create(const rv_config *cfg, const char *ifname,
                            const char *base_dir, char *err, size_t errlen);

/*
 * Test/offline mode: compiles profiles and tracks flows, but does not open an
 * AF_PACKET TX socket. Built frames are counted but not sent. Used by
 * tests/engine_test.c so strategy logic can be validated without CAP_NET_RAW.
 */
rv_engine *rv_engine_create_offline(const rv_config *cfg,
                                    const char *base_dir,
                                    char *err, size_t errlen);
int rv_engine_reload(rv_engine *engine, const rv_config *cfg,
                     char *err, size_t errlen);
void rv_engine_destroy(rv_engine *engine);

/* Process one captured outgoing packet. Returns 0 (packet left untouched) or
 * 1 (RawVeil emitted replacement/extra frames). */
int rv_engine_handle(rv_engine *engine, const rv_packet *pkt,
                     const uint8_t *frame, size_t frame_len);

void rv_engine_expire(rv_engine *engine, time_t now);
void rv_engine_get_stats(rv_engine *engine, rv_engine_stats *out);
size_t rv_engine_tracker_count(rv_engine *engine);

#endif /* RV_STRATEGIES_H */
