#ifndef RV_NETBUILD_H
#define RV_NETBUILD_H

#include <stddef.h>
#include <stdint.h>

#include "packet.h"

/*
 * Build a complete Ethernet frame by cloning the L2/L3/L4 headers of an
 * original captured frame and replacing payload/sequence/ACK/flags.
 *
 * The IP ID (IPv4) or flow label (IPv6) is set to RV_SENT_MARKER so the
 * capture path ignores our own transmissions. IPv4/TCP/UDP checksums are
 * recomputed from scratch (captured checksums may be CHECKSUM_PARTIAL).
 *
 * ttl_override: 0 keeps the original TTL/hop limit, otherwise overrides it.
 *
 * Returns 0 on success, -1 on invalid parameters/size overflow.
 */
int rv_build_tcp_frame(const uint8_t *orig, size_t orig_len,
                       const rv_packet *pkt,
                       uint32_t seq, uint32_t ack, uint8_t flags,
                       const uint8_t *payload, size_t payload_len,
                       uint8_t ttl_override,
                       uint8_t *out, size_t outsz, size_t *outlen);

int rv_build_udp_frame(const uint8_t *orig, size_t orig_len,
                       const rv_packet *pkt,
                       const uint8_t *payload, size_t payload_len,
                       uint8_t ttl_override,
                       uint8_t *out, size_t outsz, size_t *outlen);

/*
 * Append a TCP MD5-signature option (kind 19, length 18, dummy digest) and
 * recompute IP/TCP checksums.  Used by the fake-packet "fooling=md5sig"
 * mode: DPI parsers often fail on the option while the real server rejects
 * the out-of-window fake packet.
 */
int rv_tcp_add_md5_option(uint8_t *frame, size_t *frame_len,
                          size_t frame_size, const rv_packet *pkt);

/* Set the TCP receive window and recompute the TCP checksum. */
int rv_tcp_set_window(uint8_t *frame, size_t frame_len,
                      const rv_packet *pkt, uint16_t window);

/* Exposed for tests. */
uint16_t rv_ip_checksum(const uint8_t *data, size_t len);

#endif /* RV_NETBUILD_H */
