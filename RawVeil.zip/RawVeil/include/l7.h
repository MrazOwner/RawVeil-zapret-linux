#ifndef RV_L7_H
#define RV_L7_H

#include <stddef.h>
#include <stdint.h>

#include "tls_parser.h"

#define RV_L7_TLS          (1u << 0)
#define RV_L7_QUIC         (1u << 1)
#define RV_L7_STUN         (1u << 2)
#define RV_L7_RTP          (1u << 3)
#define RV_L7_QUIC_INITIAL (1u << 4)

/* Detect TLS ClientHello; fills tls info when provided. */
int rv_l7_tls_clienthello(const uint8_t *data, size_t len,
                          rv_tls_info *tls);

/*
 * Detect the beginning of a TLS ClientHello even when the record is split
 * across TCP segments (full SNI parsing is not possible in that case).
 */
int rv_l7_tls_clienthello_start(const uint8_t *data, size_t len);

/* Bitmask of RV_L7_* kinds detected in a UDP payload. */
unsigned rv_l7_detect_udp(const uint8_t *data, size_t len);

int rv_l7_is_quic_initial(const uint8_t *data, size_t len);
int rv_l7_is_stun(const uint8_t *data, size_t len);
int rv_l7_is_rtp(const uint8_t *data, size_t len);

#endif /* RV_L7_H */
