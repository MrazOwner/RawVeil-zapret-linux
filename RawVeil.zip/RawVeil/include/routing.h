#ifndef RV_ROUTING_H
#define RV_ROUTING_H

#include <stddef.h>
#include <stdint.h>

#include "awg.h"
#include "config.h"
#include "warp.h"

typedef struct rv_routing {
    int active;
    int mode;
    char interface[RV_IFNAMSIZ];
    uint32_t mark;
    int table;
    int priority;
    int has_ipv4;
    int has_ipv6;
} rv_routing;

/*
 * Install nftables mark rules for the WARP destination set and a dedicated
 * ip rule/route table pointing at the AWG interface. The AWG interface itself
 * must already be up.
 *
 * Returns 0 on success, -1 on error. On failure any partial state is cleaned.
 */
int rv_routing_setup(rv_routing *routing, const rv_warp_config *cfg,
                     const rv_awg_config *awg, rv_warp *warp,
                     char *err, size_t errlen);

/* Refresh only the nftables destination sets after a WARP list reload. */
int rv_routing_refresh(rv_routing *routing, rv_warp *warp,
                       char *err, size_t errlen);

/* Remove nft table, ip rules and routes. Safe to call multiple times. */
void rv_routing_cleanup(rv_routing *routing);

#endif /* RV_ROUTING_H */
