#ifndef RV_SENDER_H
#define RV_SENDER_H

#include <stddef.h>
#include <stdint.h>

typedef struct rv_tx_frame {
    const uint8_t *data;
    size_t len;
} rv_tx_frame;

typedef struct rv_sender rv_sender;

rv_sender *rv_sender_create(const char *ifname, char *err, size_t errlen);
void rv_sender_destroy(rv_sender *sender);

/*
 * Send complete Ethernet frames through an AF_PACKET TX socket using
 * sendmmsg(). Destination MAC is taken from frame[0..5].
 * Returns the number of frames sent, or -1 on a fatal socket error.
 */
int rv_sender_send_batch(rv_sender *sender, const rv_tx_frame *frames,
                         size_t count);

/* Interface MTU (L3), used to segment large TCP payloads before TX. */
unsigned int rv_sender_mtu(const rv_sender *sender);

#endif /* RV_SENDER_H */
