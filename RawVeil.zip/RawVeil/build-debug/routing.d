build-debug/routing.o: src/routing.c include/routing.h include/awg.h \
 include/common.h include/config.h include/log.h include/warp.h \
 include/log.h
include/routing.h:
include/awg.h:
include/common.h:
include/config.h:
include/log.h:
include/warp.h:
include/log.h:
