build-debug/strategies.o: src/strategies.c include/strategies.h \
 include/config.h include/common.h include/log.h include/packet.h \
 include/l7.h include/tls_parser.h include/log.h include/netbuild.h \
 include/sender.h include/tracker.h include/tls_parser.h
include/strategies.h:
include/config.h:
include/common.h:
include/log.h:
include/packet.h:
include/l7.h:
include/tls_parser.h:
include/log.h:
include/netbuild.h:
include/sender.h:
include/tracker.h:
include/tls_parser.h:
