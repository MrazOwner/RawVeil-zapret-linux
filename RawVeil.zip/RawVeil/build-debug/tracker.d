build-debug/tracker.o: src/tracker.c include/tracker.h
include/tracker.h:
