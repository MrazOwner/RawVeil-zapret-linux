build-debug/sender.o: src/sender.c include/sender.h include/common.h \
 include/log.h
include/sender.h:
include/common.h:
include/log.h:
