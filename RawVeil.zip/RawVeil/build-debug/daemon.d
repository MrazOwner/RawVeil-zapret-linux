build-debug/daemon.o: src/daemon.c include/daemon.h include/common.h \
 include/log.h
include/daemon.h:
include/common.h:
include/log.h:
