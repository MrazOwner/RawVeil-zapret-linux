build-debug/main.o: src/main.c include/awg.h include/common.h \
 include/capture.h include/common.h include/config.h include/log.h \
 include/daemon.h include/log.h include/routing.h include/awg.h \
 include/config.h include/warp.h include/strategies.h include/packet.h \
 include/warp.h
include/awg.h:
include/common.h:
include/capture.h:
include/common.h:
include/config.h:
include/log.h:
include/daemon.h:
include/log.h:
include/routing.h:
include/awg.h:
include/config.h:
include/warp.h:
include/strategies.h:
include/packet.h:
include/warp.h:
