build-debug/tls_parser.o: src/tls_parser.c include/tls_parser.h
include/tls_parser.h:
