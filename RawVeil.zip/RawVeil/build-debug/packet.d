build-debug/packet.o: src/packet.c include/packet.h
include/packet.h:
