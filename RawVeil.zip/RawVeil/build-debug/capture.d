build-debug/capture.o: src/capture.c include/capture.h include/common.h \
 include/bpf_filter.h include/log.h include/packet.h include/strategies.h \
 include/config.h include/log.h include/packet.h include/warp.h
include/capture.h:
include/common.h:
include/bpf_filter.h:
include/log.h:
include/packet.h:
include/strategies.h:
include/config.h:
include/log.h:
include/packet.h:
include/warp.h:
