build-debug/warp.o: src/warp.c include/warp.h include/config.h \
 include/common.h include/log.h include/log.h
include/warp.h:
include/config.h:
include/common.h:
include/log.h:
include/log.h:
