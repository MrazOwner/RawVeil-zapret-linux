build-debug/netbuild.o: src/netbuild.c include/netbuild.h \
 include/packet.h
include/netbuild.h:
include/packet.h:
