build-debug/awg.o: src/awg.c include/awg.h include/common.h include/log.h
include/awg.h:
include/common.h:
include/log.h:
