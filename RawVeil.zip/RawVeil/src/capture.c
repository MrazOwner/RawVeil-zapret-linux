#include "capture.h"

#include "bpf_filter.h"
#include "log.h"
#include "packet.h"
#include "strategies.h"
#include "warp.h"

#include <arpa/inet.h>
#include <errno.h>
#include <linux/filter.h>
#include <linux/if_ether.h>
#include <linux/if_packet.h>
#include <net/if.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#define RV_CAPTURE_BATCH 32
#define RV_CAPTURE_RCVBUF (4 * 1024 * 1024)

struct rv_capture {
    int fd;
    char ifname[RV_IFNAMSIZ];
    unsigned int ifindex;
    int buf_size;
    int alloc_size;
    int batch_count;
    struct mmsghdr *msgs;
    struct iovec *iovs;
    struct sockaddr_ll *addrs;
    unsigned char *buffers;
    int capture_incoming;
    rv_capture_stats stats;
};

static int attach_filter(int fd, char *err, size_t errlen)
{
    rv_bpf_program prog;
    struct sock_fprog fprog;

    if (rv_bpf_build_egress_filter(&prog) < 0) {
        (void)snprintf(err, errlen, "cannot build BPF filter");
        return -1;
    }
    memset(&fprog, 0, sizeof(fprog));
    fprog.len = (unsigned short)prog.count;
    fprog.filter = prog.insns;
    if (setsockopt(fd, SOL_SOCKET, SO_ATTACH_FILTER,
                   &fprog, sizeof(fprog)) < 0) {
        (void)snprintf(err, errlen, "SO_ATTACH_FILTER: %s",
                       strerror(errno));
        return -1;
    }
    LOG_DEBUG("capture: attached classic BPF filter (%zu instructions)",
              prog.count);
    return 0;
}

rv_capture *rv_capture_open(const char *ifname, int buffer_size,
                            char *err, size_t errlen)
{
    rv_capture *cap;
    struct sockaddr_ll sll;
    int rcvbuf = RV_CAPTURE_RCVBUF;
    int i;

    if (err != NULL && errlen > 0) {
        err[0] = '\0';
    }
    if (ifname == NULL || *ifname == '\0' ||
        strlen(ifname) >= RV_IFNAMSIZ) {
        (void)snprintf(err, errlen, "invalid interface name");
        return NULL;
    }
    if (buffer_size < 1500 || buffer_size > 65535) {
        (void)snprintf(err, errlen, "invalid capture buffer size");
        return NULL;
    }

    cap = calloc(1, sizeof(*cap));
    if (cap == NULL) {
        (void)snprintf(err, errlen, "out of memory");
        return NULL;
    }
    cap->fd = -1;
    cap->buf_size = buffer_size;
    cap->alloc_size = buffer_size + 64; /* room for Ethernet/VLAN headers */
    rv_strlcpy(cap->ifname, sizeof(cap->ifname), ifname);

    cap->ifindex = if_nametoindex(ifname);
    if (cap->ifindex == 0) {
        (void)snprintf(err, errlen, "unknown interface '%s': %s",
                       ifname, strerror(errno));
        rv_capture_close(cap);
        return NULL;
    }

    cap->fd = socket(AF_PACKET, SOCK_RAW | SOCK_CLOEXEC,
                     htons(ETH_P_ALL));
    if (cap->fd < 0) {
        (void)snprintf(err, errlen,
                       "socket(AF_PACKET) failed: %s "
                       "(CAP_NET_RAW or root is required)", strerror(errno));
        rv_capture_close(cap);
        return NULL;
    }

    memset(&sll, 0, sizeof(sll));
    sll.sll_family = AF_PACKET;
    sll.sll_protocol = htons(ETH_P_ALL);
    sll.sll_ifindex = (int)cap->ifindex;
    if (bind(cap->fd, (struct sockaddr *)&sll, sizeof(sll)) < 0) {
        (void)snprintf(err, errlen, "bind(AF_PACKET, %s): %s",
                       ifname, strerror(errno));
        rv_capture_close(cap);
        return NULL;
    }

    if (setsockopt(cap->fd, SOL_SOCKET, SO_RCVBUF,
                   &rcvbuf, sizeof(rcvbuf)) < 0) {
        LOG_DEBUG("capture: SO_RCVBUF: %s", strerror(errno));
    }
    if (attach_filter(cap->fd, err, errlen) < 0) {
        rv_capture_close(cap);
        return NULL;
    }

    cap->batch_count = RV_CAPTURE_BATCH;
    cap->msgs = calloc((size_t)cap->batch_count, sizeof(*cap->msgs));
    cap->iovs = calloc((size_t)cap->batch_count, sizeof(*cap->iovs));
    cap->addrs = calloc((size_t)cap->batch_count, sizeof(*cap->addrs));
    cap->buffers = malloc((size_t)cap->batch_count *
                          (size_t)cap->alloc_size);
    if (cap->msgs == NULL || cap->iovs == NULL || cap->addrs == NULL ||
        cap->buffers == NULL) {
        (void)snprintf(err, errlen, "out of memory");
        rv_capture_close(cap);
        return NULL;
    }

    for (i = 0; i < cap->batch_count; i++) {
        cap->iovs[i].iov_base = cap->buffers +
                                (size_t)i * cap->alloc_size;
        cap->iovs[i].iov_len = (size_t)cap->alloc_size;
        cap->msgs[i].msg_hdr.msg_name = &cap->addrs[i];
        cap->msgs[i].msg_hdr.msg_namelen = sizeof(cap->addrs[i]);
        cap->msgs[i].msg_hdr.msg_iov = &cap->iovs[i];
        cap->msgs[i].msg_hdr.msg_iovlen = 1;
        cap->msgs[i].msg_hdr.msg_control = NULL;
        cap->msgs[i].msg_hdr.msg_controllen = 0;
        cap->msgs[i].msg_hdr.msg_flags = 0;
    }

    LOG_INFO("capture: listening on %s (ifindex=%u, batch=%d, "
             "buffer_size=%d)", cap->ifname, cap->ifindex,
             cap->batch_count, cap->buf_size);
    return cap;
}

void rv_capture_close(rv_capture *cap)
{
    if (cap == NULL) {
        return;
    }
    if (cap->fd >= 0) {
        close(cap->fd);
        cap->fd = -1;
    }
    free(cap->msgs);
    free(cap->iovs);
    free(cap->addrs);
    free(cap->buffers);
    free(cap);
}

void rv_capture_set_incoming(rv_capture *cap, int enabled)
{
    if (cap != NULL) {
        cap->capture_incoming = enabled != 0;
    }
}

static const char *proto_name(int proto)
{
    if (proto == IPPROTO_TCP) {
        return "tcp";
    }
    if (proto == IPPROTO_UDP) {
        return "udp";
    }
    return "other";
}

static void process_frame(rv_capture *cap, rv_warp *warp, uint32_t mark,
                          int warp_bypass, struct rv_engine *engine,
                          const struct sockaddr_ll *sll,
                          const uint8_t *buf, size_t len)
{
    rv_packet pkt;
    char src[INET6_ADDRSTRLEN];
    char dst[INET6_ADDRSTRLEN];
    const char *srcp;
    const char *dstp;
    int rc;
    int warp_match;

    cap->stats.frames_seen++;
    if (sll->sll_pkttype != PACKET_OUTGOING) {
        if (!cap->capture_incoming) {
            cap->stats.incoming_ignored++;
            return;
        }
        cap->stats.incoming++;
        rc = rv_packet_parse(&pkt, buf, len);
        if (rc < 0) {
            cap->stats.parse_errors++;
            return;
        }
        if (rc == 0 || !pkt.has_ports) {
            return;
        }
        if (pkt.family == AF_INET) {
            cap->stats.ipv4++;
            srcp = inet_ntop(AF_INET, pkt.src, src, sizeof(src));
            dstp = inet_ntop(AF_INET, pkt.dst, dst, sizeof(dst));
        } else {
            cap->stats.ipv6++;
            srcp = inet_ntop(AF_INET6, pkt.src, src, sizeof(src));
            dstp = inet_ntop(AF_INET6, pkt.dst, dst, sizeof(dst));
        }
        if (srcp == NULL) {
            srcp = "?";
        }
        if (dstp == NULL) {
            dstp = "?";
        }
        if (pkt.proto == IPPROTO_TCP) {
            const uint8_t *payload = buf + pkt.payload_off;

            cap->stats.tcp++;
            if (pkt.payload_len >= 5 &&
                payload[1] == 0x03 &&
                payload[0] >= 0x14 && payload[0] <= 0x17) {
                cap->stats.incoming_tls++;
                if (payload[0] == 0x16) {
                    cap->stats.incoming_handshakes++;
                }
            }
            LOG_DEBUG("server tcp %s:%u -> %s:%u payload=%zu",
                      srcp, (unsigned)pkt.sport, dstp,
                      (unsigned)pkt.dport, pkt.payload_len);
        } else if (pkt.proto == IPPROTO_UDP) {
            cap->stats.udp++;
            if (pkt.payload_len > 0 &&
                (buf[pkt.payload_off] & 0x80u) != 0) {
                cap->stats.incoming_quic++;
            }
            LOG_DEBUG("server udp %s:%u -> %s:%u payload=%zu",
                      srcp, (unsigned)pkt.sport, dstp,
                      (unsigned)pkt.dport, pkt.payload_len);
        } else {
            cap->stats.other_l4++;
        }
        return;
    }
    /* The separate server-response socket is read-only. */
    if (cap->capture_incoming) {
        return;
    }
    cap->stats.outgoing++;

    rc = rv_packet_parse(&pkt, buf, len);
    if (rc < 0) {
        cap->stats.parse_errors++;
        LOG_DEBUG("%s: malformed or truncated frame (%zu bytes)",
                  cap->ifname, len);
        return;
    }
    if (rc == 0) {
        LOG_DEBUG("%s: non-IP frame (%zu bytes)", cap->ifname, len);
        return;
    }
    if (pkt.sent_by_us) {
        cap->stats.injected_ignored++;
        return;
    }

    if (pkt.family == AF_INET) {
        cap->stats.ipv4++;
        srcp = inet_ntop(AF_INET, pkt.src, src, sizeof(src));
        dstp = inet_ntop(AF_INET, pkt.dst, dst, sizeof(dst));
    } else {
        cap->stats.ipv6++;
        srcp = inet_ntop(AF_INET6, pkt.src, src, sizeof(src));
        dstp = inet_ntop(AF_INET6, pkt.dst, dst, sizeof(dst));
    }
    if (srcp == NULL) {
        srcp = "?";
    }
    if (dstp == NULL) {
        dstp = "?";
    }

    if (pkt.proto == IPPROTO_TCP) {
        cap->stats.tcp++;
    } else if (pkt.proto == IPPROTO_UDP) {
        cap->stats.udp++;
    } else {
        cap->stats.other_l4++;
    }

    if (pkt.has_ports) {
        LOG_DEBUG("pkt %s %s:%u -> %s:%u proto=%s len=%zu",
                  cap->ifname, srcp, (unsigned)pkt.sport,
                  dstp, (unsigned)pkt.dport, proto_name(pkt.proto), len);
    } else {
        LOG_DEBUG("pkt %s %s -> %s proto=%s len=%zu (no L4 ports)",
                  cap->ifname, srcp, dstp, proto_name(pkt.proto), len);
    }

    warp_match = rv_warp_should_mark(warp, pkt.family, pkt.dst);
    if (warp_match) {
        cap->stats.warp_matches++;
        if (pkt.has_ports) {
            LOG_INFO("warp match: %s:%u -> %s:%u proto=%s; bypassing "
                     "strategies (configured mark=0x%x)",
                     srcp, (unsigned)pkt.sport, dstp,
                     (unsigned)pkt.dport, proto_name(pkt.proto), mark);
        } else {
            LOG_INFO("warp match: %s -> %s proto=%s; bypassing strategies "
                     "(configured mark=0x%x)",
                     srcp, dstp, proto_name(pkt.proto), mark);
        }
        if (warp_bypass) {
            return;
        }
    }

    if (engine != NULL) {
        (void)rv_engine_handle(engine, &pkt, buf, len);
    }
}

int rv_capture_read(rv_capture *cap, rv_warp *warp, uint32_t mark,
                    int warp_bypass, struct rv_engine *engine,
                    int timeout_ms)
{
    struct timespec timeout;
    int n;
    int i;

    if (cap == NULL || cap->fd < 0) {
        return -1;
    }
    if (timeout_ms < 0) {
        timeout_ms = 0;
    }
    timeout.tv_sec = timeout_ms / 1000;
    timeout.tv_nsec = (long)(timeout_ms % 1000) * 1000000L;

    for (i = 0; i < cap->batch_count; i++) {
        cap->msgs[i].msg_hdr.msg_namelen = sizeof(cap->addrs[i]);
        cap->msgs[i].msg_hdr.msg_flags = 0;
        cap->msgs[i].msg_len = 0;
    }

    n = recvmmsg(cap->fd, cap->msgs, (unsigned int)cap->batch_count,
                 0, &timeout);
    if (n < 0) {
        if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK) {
            return 0;
        }
        cap->stats.read_errors++;
        LOG_ERROR("capture: recvmmsg(%s): %s", cap->ifname,
                  strerror(errno));
        return -1;
    }

    for (i = 0; i < n; i++) {
        struct mmsghdr *msg = &cap->msgs[i];
        const struct sockaddr_ll *sll;

        if (msg->msg_hdr.msg_flags & MSG_TRUNC) {
            cap->stats.truncated++;
            LOG_WARN("%s: frame truncated to %d bytes",
                     cap->ifname, cap->buf_size);
            continue;
        }
        sll = (const struct sockaddr_ll *)msg->msg_hdr.msg_name;
        if (sll == NULL) {
            cap->stats.parse_errors++;
            continue;
        }
        process_frame(cap, warp, mark, warp_bypass, engine, sll,
                      cap->buffers + (size_t)i * (size_t)cap->alloc_size,
                      (size_t)msg->msg_len);
    }
    return n;
}

void rv_capture_get_stats(const rv_capture *cap, rv_capture_stats *out)
{
    if (out == NULL) {
        return;
    }
    if (cap == NULL) {
        memset(out, 0, sizeof(*out));
        return;
    }
    *out = cap->stats;
}

const char *rv_capture_interface(const rv_capture *cap)
{
    if (cap == NULL) {
        return "?";
    }
    return cap->ifname;
}
