#include "netbuild.h"

#include <netinet/in.h>
#include <string.h>

static void write_be16(uint8_t *p, uint16_t value)
{
    p[0] = (uint8_t)(value >> 8);
    p[1] = (uint8_t)(value & 0xffu);
}

static void write_be32(uint8_t *p, uint32_t value)
{
    p[0] = (uint8_t)(value >> 24);
    p[1] = (uint8_t)(value >> 16);
    p[2] = (uint8_t)(value >> 8);
    p[3] = (uint8_t)(value & 0xffu);
}

static uint32_t sum_bytes(const uint8_t *data, size_t len, uint32_t sum)
{
    size_t i;

    for (i = 0; i + 1 < len; i += 2) {
        sum += ((uint32_t)data[i] << 8) | data[i + 1];
    }
    if ((len & 1u) != 0) {
        sum += (uint32_t)data[len - 1] << 8;
    }
    return sum;
}

static uint16_t fold_checksum(uint32_t sum)
{
    while ((sum >> 16) != 0) {
        sum = (sum & 0xffffu) + (sum >> 16);
    }
    return (uint16_t)(~sum & 0xffffu);
}

uint16_t rv_ip_checksum(const uint8_t *data, size_t len)
{
    return fold_checksum(sum_bytes(data, len, 0));
}

static uint32_t pseudo_sum(const rv_packet *pkt, size_t l4_len)
{
    uint32_t sum = 0;
    size_t alen = pkt->family == AF_INET ? 4u : 16u;

    sum = sum_bytes(pkt->src, alen, sum);
    sum = sum_bytes(pkt->dst, alen, sum);
    if (pkt->family == AF_INET) {
        sum += pkt->proto;
        sum += (uint32_t)(l4_len & 0xffffu);
    } else {
        sum += (uint32_t)((l4_len >> 16) & 0xffffu);
        sum += (uint32_t)(l4_len & 0xffffu);
        sum += (uint32_t)(unsigned)pkt->proto;
    }
    return sum;
}

static int pad_frame(uint8_t *out, size_t outsz, size_t *outlen)
{
    if (*outlen < 60) {
        if (60 > outsz) {
            return -1;
        }
        memset(out + *outlen, 0, 60 - *outlen);
        *outlen = 60;
    }
    return 0;
}

static int check_inputs(const uint8_t *orig, size_t orig_len,
                        const rv_packet *pkt, size_t payload_len,
                        uint8_t *out, size_t outsz, size_t *outlen)
{
    size_t frame_len;

    if (orig == NULL || pkt == NULL || out == NULL || outlen == NULL) {
        return -1;
    }
    if (pkt->l2_len + pkt->l3_hdr_len + pkt->l4_hdr_len > orig_len) {
        return -1;
    }
    if (pkt->l4_off + pkt->l4_hdr_len > orig_len) {
        return -1;
    }
    if (pkt->l3_hdr_len + pkt->l4_hdr_len + payload_len > 65535u) {
        return -1;
    }
    frame_len = pkt->l2_len + pkt->l3_hdr_len + pkt->l4_hdr_len + payload_len;
    if (frame_len > outsz) {
        return -1;
    }
    *outlen = frame_len;
    return 0;
}

int rv_build_tcp_frame(const uint8_t *orig, size_t orig_len,
                       const rv_packet *pkt,
                       uint32_t seq, uint32_t ack, uint8_t flags,
                       const uint8_t *payload, size_t payload_len,
                       uint8_t ttl_override,
                       uint8_t *out, size_t outsz, size_t *outlen)
{
    size_t l4_off;
    size_t l4_len;
    size_t l3_len;
    uint32_t sum;
    uint16_t csum;
    uint16_t total_len;

    if (check_inputs(orig, orig_len, pkt, payload_len,
                     out, outsz, outlen) < 0) {
        return -1;
    }
    if (pkt->proto != IPPROTO_TCP ||
        (payload_len > 0 && payload == NULL)) {
        return -1;
    }

    l4_off = pkt->l2_len + pkt->l3_hdr_len;
    l4_len = pkt->l4_hdr_len + payload_len;
    l3_len = pkt->l3_hdr_len + l4_len;
    total_len = (uint16_t)l3_len;

    memcpy(out, orig, pkt->l2_len + pkt->l3_hdr_len + pkt->l4_hdr_len);
    if (payload_len > 0) {
        memcpy(out + l4_off + pkt->l4_hdr_len, payload, payload_len);
    }

    if (pkt->family == AF_INET) {
        uint8_t *ip = out + pkt->l2_len;

        write_be16(ip + 2, total_len);
        write_be16(ip + 4, RV_SENT_MARKER);
        if (ttl_override != 0) {
            ip[8] = ttl_override;
        }
        ip[10] = 0;
        ip[11] = 0;
        csum = rv_ip_checksum(ip, pkt->l3_hdr_len);
        write_be16(ip + 10, csum);
    } else {
        uint8_t *ip = out + pkt->l2_len;
        uint32_t first;

        write_be16(ip + 4, (uint16_t)l4_len);
        if (ttl_override != 0) {
            ip[7] = ttl_override;
        }
        first = ((uint32_t)ip[0] << 24) | ((uint32_t)ip[1] << 16) |
                ((uint32_t)ip[2] << 8) | (uint32_t)ip[3];
        first = (first & 0xFFF00000u) | RV_SENT_MARKER;
        ip[0] = (uint8_t)(first >> 24);
        ip[1] = (uint8_t)(first >> 16);
        ip[2] = (uint8_t)(first >> 8);
        ip[3] = (uint8_t)(first & 0xffu);
    }

    write_be32(out + l4_off + 4, seq);
    write_be32(out + l4_off + 8, ack);
    out[l4_off + 13] = flags;
    out[l4_off + 16] = 0;
    out[l4_off + 17] = 0;

    sum = pseudo_sum(pkt, l4_len);
    sum = sum_bytes(out + l4_off, l4_len, sum);
    csum = fold_checksum(sum);
    write_be16(out + l4_off + 16, csum);
    return pad_frame(out, outsz, outlen);
}

int rv_tcp_add_md5_option(uint8_t *frame, size_t *frame_len,
                          size_t frame_size, const rv_packet *pkt)
{
    static const uint8_t digest[16] = {
        0x52, 0x56, 0x4d, 0x44, 0x35, 0x2d, 0x66, 0x61,
        0x6b, 0x65, 0x2d, 0x73, 0x69, 0x67, 0x00, 0x01
    };
    size_t l4_off;
    size_t old_hdr;
    size_t new_hdr;
    size_t payload_len;
    size_t new_len;
    size_t l4_len;
    uint32_t sum;
    uint16_t csum;
    uint8_t *ip;

    if (frame == NULL || frame_len == NULL || pkt == NULL ||
        pkt->proto != IPPROTO_TCP) {
        return -1;
    }
    old_hdr = pkt->l4_hdr_len;
    if (old_hdr < 20 || (old_hdr & 3u) != 0 || *frame_len < old_hdr) {
        return -1;
    }
    new_hdr = old_hdr + 20;
    l4_off = pkt->l2_len + pkt->l3_hdr_len;
    if (l4_off + old_hdr > *frame_len ||
        *frame_len + 20 > frame_size ||
        new_hdr > 60) {
        return -1;
    }
    if (pkt->family == AF_INET) {
        uint8_t *ip = frame + pkt->l2_len;
        uint16_t total = (uint16_t)(((uint16_t)ip[2] << 8) | ip[3]);

        if (total < pkt->l3_hdr_len + old_hdr) {
            return -1;
        }
        payload_len = (size_t)total - pkt->l3_hdr_len - old_hdr;
    } else {
        uint8_t *ip = frame + pkt->l2_len;
        uint16_t plen = (uint16_t)(((uint16_t)ip[4] << 8) | ip[5]);

        if (plen < old_hdr) {
            return -1;
        }
        payload_len = (size_t)plen - old_hdr;
    }
    memmove(frame + l4_off + new_hdr,
            frame + l4_off + old_hdr, payload_len);
    memset(frame + l4_off + old_hdr, 0, 20);
    frame[l4_off + old_hdr] = 19;      /* TCP MD5 signature */
    frame[l4_off + old_hdr + 1] = 18;  /* kind + length + 16-byte digest */
    memcpy(frame + l4_off + old_hdr + 2, digest, sizeof(digest));
    frame[l4_off + 12] = (uint8_t)(((new_hdr / 4u) << 4) |
                                   (frame[l4_off + 12] & 0x0fu));
    new_len = *frame_len + 20;
    *frame_len = new_len;

    ip = frame + pkt->l2_len;
    if (pkt->family == AF_INET) {
        uint16_t total = (uint16_t)(((uint16_t)ip[2] << 8) | ip[3]);

        write_be16(ip + 2, (uint16_t)(total + 20));
        ip[10] = 0;
        ip[11] = 0;
        write_be16(ip + 10, rv_ip_checksum(ip, pkt->l3_hdr_len));
    } else {
        uint16_t plen = (uint16_t)(((uint16_t)ip[4] << 8) | ip[5]);

        write_be16(ip + 4, (uint16_t)(plen + 20));
    }

    l4_len = new_hdr + payload_len;
    frame[l4_off + 16] = 0;
    frame[l4_off + 17] = 0;
    sum = pseudo_sum(pkt, l4_len);
    sum = sum_bytes(frame + l4_off, l4_len, sum);
    csum = fold_checksum(sum);
    write_be16(frame + l4_off + 16, csum);
    return 0;
}

int rv_tcp_set_window(uint8_t *frame, size_t frame_len,
                      const rv_packet *pkt, uint16_t window)
{
    size_t l4_off;
    size_t l4_len;
    uint32_t sum;
    uint16_t csum;

    if (frame == NULL || pkt == NULL || pkt->proto != IPPROTO_TCP) {
        return -1;
    }
    l4_off = pkt->l2_len + pkt->l3_hdr_len;
    if (l4_off + pkt->l4_hdr_len > frame_len) {
        return -1;
    }
    if (pkt->family == AF_INET) {
        uint8_t *ip = frame + pkt->l2_len;
        uint16_t total = (uint16_t)(((uint16_t)ip[2] << 8) | ip[3]);

        if (total < pkt->l3_hdr_len) {
            return -1;
        }
        /* Do not include Ethernet padding in the TCP checksum. */
        l4_len = (size_t)total - pkt->l3_hdr_len;
    } else {
        uint8_t *ip = frame + pkt->l2_len;
        uint16_t plen = (uint16_t)(((uint16_t)ip[4] << 8) | ip[5]);

        l4_len = plen;
    }
    write_be16(frame + l4_off + 14, window);
    frame[l4_off + 16] = 0;
    frame[l4_off + 17] = 0;
    sum = pseudo_sum(pkt, l4_len);
    sum = sum_bytes(frame + l4_off, l4_len, sum);
    csum = fold_checksum(sum);
    write_be16(frame + l4_off + 16, csum);
    return 0;
}

static void set_fragment_bits(uint8_t *p, int more, size_t offset)
{
    uint16_t value = (uint16_t)((offset / 8u) & 0x1fffu);

    if (more) {
        value |= 0x2000u;
    }
    write_be16(p, value);
}

int rv_build_ip_fragment(const uint8_t *full, size_t full_len,
                         const rv_packet *pkt,
                         size_t frag_l4_offset, size_t frag_l4_len,
                         int more_fragments, uint32_t fragment_id,
                         uint8_t *out, size_t outsz, size_t *outlen)
{
    size_t l4_off;
    size_t copy_off;
    size_t l2_l3;
    size_t out_len;

    if (full == NULL || pkt == NULL || out == NULL || outlen == NULL ||
        pkt->l3_hdr_len == 0 || frag_l4_len == 0) {
        return -1;
    }
    l4_off = pkt->l2_len + pkt->l3_hdr_len;
    if (frag_l4_offset > full_len || l4_off > full_len ||
        frag_l4_len > full_len - l4_off - frag_l4_offset) {
        return -1;
    }
    copy_off = l4_off + frag_l4_offset;
    l2_l3 = pkt->l2_len + pkt->l3_hdr_len;

    if (pkt->family == AF_INET) {
        uint8_t *ip;
        uint16_t total = (uint16_t)(pkt->l3_hdr_len + frag_l4_len);

        if (pkt->l3_hdr_len < 20 || total < pkt->l3_hdr_len ||
            frag_l4_offset % 8u != 0) {
            return -1;
        }
        out_len = l2_l3 + frag_l4_len;
        if (out_len > outsz) {
            return -1;
        }
        memcpy(out, full, l2_l3);
        memcpy(out + l2_l3, full + copy_off, frag_l4_len);
        ip = out + pkt->l2_len;
        write_be16(ip + 2, total);
        write_be16(ip + 4, (uint16_t)fragment_id);
        set_fragment_bits(ip + 6, more_fragments, frag_l4_offset);
        ip[10] = 0;
        ip[11] = 0;
        write_be16(ip + 10, rv_ip_checksum(ip, pkt->l3_hdr_len));
    } else if (pkt->family == AF_INET6) {
        uint8_t *ip;
        uint8_t *fh;
        uint16_t plen = (uint16_t)(8u + frag_l4_len);
        uint16_t frag_field;

        if (pkt->l3_hdr_len != 40 || frag_l4_offset % 8u != 0) {
            return -1;
        }
        out_len = l2_l3 + 8u + frag_l4_len;
        if (out_len > outsz) {
            return -1;
        }
        memcpy(out, full, l2_l3);
        ip = out + pkt->l2_len;
        fh = out + l2_l3;
        fh[0] = ip[6]; /* next header of the fragmentable part */
        fh[1] = 0;
        frag_field = (uint16_t)((frag_l4_offset / 8u) & 0x1fffu);
        if (more_fragments) {
            frag_field |= 0x0001u;
        }
        write_be16(fh + 2, frag_field);
        write_be32(fh + 4, fragment_id);
        ip[6] = 44; /* Fragment header */
        write_be16(ip + 4, plen);
        memcpy(out + l2_l3 + 8u, full + copy_off, frag_l4_len);
    } else {
        return -1;
    }

    *outlen = out_len < 60 ? 60 : out_len;
    if (*outlen > outsz) {
        return -1;
    }
    if (out_len < 60) {
        memset(out + out_len, 0, 60 - out_len);
    }
    return 0;
}

int rv_build_udp_frame(const uint8_t *orig, size_t orig_len,
                       const rv_packet *pkt,
                       const uint8_t *payload, size_t payload_len,
                       uint8_t ttl_override,
                       uint8_t *out, size_t outsz, size_t *outlen)
{
    size_t l4_off;
    size_t l4_len;
    size_t l3_len;
    uint32_t sum;
    uint16_t csum;

    if (check_inputs(orig, orig_len, pkt, payload_len,
                     out, outsz, outlen) < 0) {
        return -1;
    }
    if (pkt->proto != IPPROTO_UDP ||
        (payload_len > 0 && payload == NULL)) {
        return -1;
    }

    l4_off = pkt->l2_len + pkt->l3_hdr_len;
    l4_len = pkt->l4_hdr_len + payload_len;
    l3_len = pkt->l3_hdr_len + l4_len;

    memcpy(out, orig, pkt->l2_len + pkt->l3_hdr_len + pkt->l4_hdr_len);
    if (payload_len > 0) {
        memcpy(out + l4_off + pkt->l4_hdr_len, payload, payload_len);
    }

    if (pkt->family == AF_INET) {
        uint8_t *ip = out + pkt->l2_len;

        write_be16(ip + 2, (uint16_t)l3_len);
        write_be16(ip + 4, RV_SENT_MARKER);
        if (ttl_override != 0) {
            ip[8] = ttl_override;
        }
        ip[10] = 0;
        ip[11] = 0;
        write_be16(ip + 10, rv_ip_checksum(ip, pkt->l3_hdr_len));
    } else {
        uint8_t *ip = out + pkt->l2_len;
        uint32_t first;

        write_be16(ip + 4, (uint16_t)l4_len);
        if (ttl_override != 0) {
            ip[7] = ttl_override;
        }
        first = ((uint32_t)ip[0] << 24) | ((uint32_t)ip[1] << 16) |
                ((uint32_t)ip[2] << 8) | (uint32_t)ip[3];
        first = (first & 0xFFF00000u) | RV_SENT_MARKER;
        ip[0] = (uint8_t)(first >> 24);
        ip[1] = (uint8_t)(first >> 16);
        ip[2] = (uint8_t)(first >> 8);
        ip[3] = (uint8_t)(first & 0xffu);
    }

    write_be16(out + l4_off + 4, (uint16_t)l4_len);
    out[l4_off + 6] = 0;
    out[l4_off + 7] = 0;

    sum = pseudo_sum(pkt, l4_len);
    sum = sum_bytes(out + l4_off, l4_len, sum);
    csum = fold_checksum(sum);
    if (csum == 0) {
        csum = 0xffffu;
    }
    write_be16(out + l4_off + 6, csum);
    return pad_frame(out, outsz, outlen);
}
