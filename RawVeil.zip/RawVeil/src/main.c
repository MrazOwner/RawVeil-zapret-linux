#include "awg.h"
#include "capture.h"
#include "common.h"
#include "config.h"
#include "daemon.h"
#include "log.h"
#include "routing.h"
#include "strategies.h"
#include "warp.h"

#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <inttypes.h>
#include <limits.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <unistd.h>

typedef struct rv_cli {
    int foreground;
    int show_help;
    int show_version;

    const char *config_path;
    int config_set;

    const char *interface;
    const char *send_interface;
    const char *warp_list;
    const char *warp_ip_list;
    const char *warp_iface;
    const char *awg_config;
    uint32_t warp_mark;
    int warp_mark_set;

    const char *doh_mode;
    const char *doh_endpoint;
    const char *doh_bootstrap;

    const char *profiles[RV_MAX_PROFILE_OVERRIDES];
    int profile_count;

    const char *log_level;
    int log_level_set;
    rv_log_level log_level_value;
    int threads;
    int threads_set;

    const char *pid_file;
    const char *stats_file;
} rv_cli;

static volatile sig_atomic_t g_stop;
static volatile sig_atomic_t g_reload;
static volatile sig_atomic_t g_stats;

static void notify_daemon_ready(int fd, int ok, const char *message);

enum {
    OPT_WARP_LIST = 1000,
    OPT_WARP_IP_LIST,
    OPT_WARP_IFACE,
    OPT_WARP_MARK,
    OPT_DOH_MODE,
    OPT_DOH_ENDPOINT,
    OPT_DOH_BOOTSTRAP,
    OPT_PROFILE,
    OPT_LOG_LEVEL,
    OPT_THREADS,
    OPT_STATS_FILE,
    OPT_SEND_INTERFACE,
    OPT_AWG_CONFIG
};

static void usage(FILE *out)
{
    fprintf(out,
        "RawVeil %s - raw-socket DPI circumvention daemon\n"
        "\n"
        "Usage:\n"
        "  rawveil on [OPTIONS]        start the daemon\n"
        "  rawveil off [--pid-file P]  stop the daemon (SIGTERM)\n"
        "  rawveil status [--pid-file P]\n"
        "                              show daemon status and statistics\n"
        "  rawveil reload [--pid-file P]\n"
        "                              reload configuration (SIGHUP)\n"
        "  rawveil --help | --version\n"
        "\n"
        "Options for 'on' (CLI overrides config for this run only):\n"
        "  --config PATH          configuration file (default: %s)\n"
        "  --interface IFACE      capture interface\n"
        "  --send-interface IFACE TX interface (default: capture interface)\n"
        "  --foreground           do not daemonize\n"
        "  --warp-list PATH       WARP domain list\n"
        "  --warp-ip-list PATH    WARP IP/CIDR list\n"
        "  --warp-iface IFACE     WARP/AWG tunnel interface\n"
        "  --awg-config PATH      AmneziaWG .conf for WARP routing\n"
        "  --warp-mark VALUE      WARP fwmark (0x... accepted)\n"
        "  --doh-mode MODE        only 'system' is implemented\n"
        "  --doh-endpoint URL     DoH endpoint (stored, unused in mode=system)\n"
        "  --doh-bootstrap LIST   bootstrap resolver IPs (stored)\n"
        "  --profile P.K=V        override a strategy profile value\n"
        "  --log-level LEVEL      debug, info, warn, error\n"
        "  --threads N            worker count (reserved for strategy stage)\n"
        "  --pid-file PATH        pid file\n"
        "  --stats-file PATH      statistics file (also used by status)\n"
        "\n"
        "Strategies rewrite/split matching packets and emit them via AF_PACKET "
        "TX + sendmmsg. WARP destinations can be routed through an existing "
        "AmneziaWG interface using awg_config. RawVeil does not start AWG or "
        "manage its keys.\n",
        RV_VERSION, RV_DEFAULT_CONFIG);
}

static int parse_u32(const char *text, uint32_t *out)
{
    char *end = NULL;
    unsigned long value;

    errno = 0;
    value = strtoul(text, &end, 0);
    if (errno != 0 || end == text || *end != '\0' || value > UINT32_MAX) {
        return -1;
    }
    *out = (uint32_t)value;
    return 0;
}

static int parse_threads(const char *text, int *out)
{
    char *end = NULL;
    long value;

    errno = 0;
    value = strtol(text, &end, 10);
    if (errno != 0 || end == text || *end != '\0' ||
        value < 1 || value > RV_MAX_THREADS) {
        return -1;
    }
    *out = (int)value;
    return 0;
}

static int parse_cli(int argc, char **argv, rv_cli *cli)
{
    static const struct option options[] = {
        {"config", required_argument, NULL, 'c'},
        {"interface", required_argument, NULL, 'i'},
        {"send-interface", required_argument, NULL, OPT_SEND_INTERFACE},
        {"foreground", no_argument, NULL, 'f'},
        {"pid-file", required_argument, NULL, 'p'},
        {"help", no_argument, NULL, 'h'},
        {"version", no_argument, NULL, 'V'},
        {"warp-list", required_argument, NULL, OPT_WARP_LIST},
        {"warp-ip-list", required_argument, NULL, OPT_WARP_IP_LIST},
        {"warp-iface", required_argument, NULL, OPT_WARP_IFACE},
        {"awg-config", required_argument, NULL, OPT_AWG_CONFIG},
        {"warp-mark", required_argument, NULL, OPT_WARP_MARK},
        {"doh-mode", required_argument, NULL, OPT_DOH_MODE},
        {"doh-endpoint", required_argument, NULL, OPT_DOH_ENDPOINT},
        {"doh-bootstrap", required_argument, NULL, OPT_DOH_BOOTSTRAP},
        {"profile", required_argument, NULL, OPT_PROFILE},
        {"log-level", required_argument, NULL, OPT_LOG_LEVEL},
        {"threads", required_argument, NULL, OPT_THREADS},
        {"stats-file", required_argument, NULL, OPT_STATS_FILE},
        {NULL, 0, NULL, 0}
    };
    int c;

    memset(cli, 0, sizeof(*cli));
    opterr = 0;
    optind = 1;

    while ((c = getopt_long(argc, argv, ":c:i:fp:hV", options, NULL)) != -1) {
        switch (c) {
        case 'c':
            cli->config_path = optarg;
            cli->config_set = 1;
            break;
        case 'i':
            cli->interface = optarg;
            break;
        case OPT_SEND_INTERFACE:
            cli->send_interface = optarg;
            break;
        case 'f':
            cli->foreground = 1;
            break;
        case 'p':
            cli->pid_file = optarg;
            break;
        case 'h':
            cli->show_help = 1;
            return 0;
        case 'V':
            cli->show_version = 1;
            return 0;
        case OPT_WARP_LIST:
            cli->warp_list = optarg;
            break;
        case OPT_WARP_IP_LIST:
            cli->warp_ip_list = optarg;
            break;
        case OPT_WARP_IFACE:
            cli->warp_iface = optarg;
            break;
        case OPT_AWG_CONFIG:
            cli->awg_config = optarg;
            break;
        case OPT_WARP_MARK:
            if (parse_u32(optarg, &cli->warp_mark) < 0) {
                fprintf(stderr, "rawveil: invalid --warp-mark '%s'\n", optarg);
                return -1;
            }
            cli->warp_mark_set = 1;
            break;
        case OPT_DOH_MODE:
            cli->doh_mode = optarg;
            break;
        case OPT_DOH_ENDPOINT:
            cli->doh_endpoint = optarg;
            break;
        case OPT_DOH_BOOTSTRAP:
            cli->doh_bootstrap = optarg;
            break;
        case OPT_PROFILE:
            if (cli->profile_count >= RV_MAX_PROFILE_OVERRIDES) {
                fprintf(stderr, "rawveil: too many --profile options\n");
                return -1;
            }
            cli->profiles[cli->profile_count++] = optarg;
            break;
        case OPT_LOG_LEVEL:
            if (rv_log_level_parse(optarg, &cli->log_level_value) < 0) {
                fprintf(stderr, "rawveil: invalid --log-level '%s'\n", optarg);
                return -1;
            }
            cli->log_level = optarg;
            cli->log_level_set = 1;
            break;
        case OPT_THREADS:
            if (parse_threads(optarg, &cli->threads) < 0) {
                fprintf(stderr, "rawveil: invalid --threads '%s' "
                        "(expected 1..%d)\n", optarg, RV_MAX_THREADS);
                return -1;
            }
            cli->threads_set = 1;
            break;
        case OPT_STATS_FILE:
            cli->stats_file = optarg;
            break;
        case ':':
            fprintf(stderr, "rawveil: option requires an argument: %s\n",
                    argv[optind - 1]);
            return -1;
        case '?':
        default:
            fprintf(stderr, "rawveil: unknown option: %s\n",
                    argv[optind - 1]);
            return -1;
        }
    }

    if (optind < argc) {
        fprintf(stderr, "rawveil: unexpected argument '%s'\n", argv[optind]);
        return -1;
    }
    return 0;
}

static int copy_cli_string(char *dst, size_t dstsz, const char *value,
                           const char *option)
{
    if (strlen(value) >= dstsz) {
        fprintf(stderr, "rawveil: value for %s is too long\n", option);
        return -1;
    }
    rv_strlcpy(dst, dstsz, value);
    return 0;
}

static int apply_cli(rv_config *cfg, const rv_cli *cli)
{
    int i;

    if (cli->interface != NULL &&
        copy_cli_string(cfg->global.interface,
                        sizeof(cfg->global.interface), cli->interface,
                        "--interface") < 0) {
        return -1;
    }
    if (cli->send_interface != NULL &&
        copy_cli_string(cfg->global.send_interface,
                        sizeof(cfg->global.send_interface),
                        cli->send_interface, "--send-interface") < 0) {
        return -1;
    }
    if (cli->warp_list != NULL &&
        copy_cli_string(cfg->warp.domain_list,
                        sizeof(cfg->warp.domain_list), cli->warp_list,
                        "--warp-list") < 0) {
        return -1;
    }
    if (cli->warp_ip_list != NULL &&
        copy_cli_string(cfg->warp.ip_list,
                        sizeof(cfg->warp.ip_list), cli->warp_ip_list,
                        "--warp-ip-list") < 0) {
        return -1;
    }
    if (cli->warp_iface != NULL &&
        copy_cli_string(cfg->warp.interface,
                        sizeof(cfg->warp.interface), cli->warp_iface,
                        "--warp-iface") < 0) {
        return -1;
    }
    if (cli->awg_config != NULL &&
        copy_cli_string(cfg->warp.awg_config,
                        sizeof(cfg->warp.awg_config), cli->awg_config,
                        "--awg-config") < 0) {
        return -1;
    }
    if (cli->warp_mark_set) {
        cfg->warp.mark = cli->warp_mark;
    }
    if (cli->doh_mode != NULL &&
        copy_cli_string(cfg->doh.mode,
                        sizeof(cfg->doh.mode), cli->doh_mode,
                        "--doh-mode") < 0) {
        return -1;
    }
    if (cli->doh_endpoint != NULL &&
        copy_cli_string(cfg->doh.endpoint,
                        sizeof(cfg->doh.endpoint), cli->doh_endpoint,
                        "--doh-endpoint") < 0) {
        return -1;
    }
    if (cli->doh_bootstrap != NULL &&
        copy_cli_string(cfg->doh.bootstrap_ips,
                        sizeof(cfg->doh.bootstrap_ips), cli->doh_bootstrap,
                        "--doh-bootstrap") < 0) {
        return -1;
    }
    if (cli->threads_set) {
        cfg->global.threads = cli->threads;
    }
    if (cli->log_level_set) {
        cfg->global.log_level = cli->log_level_value;
    }
    if (cli->pid_file != NULL &&
        copy_cli_string(cfg->global.pid_file,
                        sizeof(cfg->global.pid_file), cli->pid_file,
                        "--pid-file") < 0) {
        return -1;
    }
    if (cli->stats_file != NULL &&
        copy_cli_string(cfg->global.stats_file,
                        sizeof(cfg->global.stats_file), cli->stats_file,
                        "--stats-file") < 0) {
        return -1;
    }

    for (i = 0; i < cli->profile_count; i++) {
        if (rv_config_apply_profile_override(cfg, cli->profiles[i]) < 0) {
            fprintf(stderr, "rawveil: invalid --profile '%s' "
                    "(expected profile.key=value)\n", cli->profiles[i]);
            return -1;
        }
    }
    return 0;
}

static char g_startup_dir[RV_MAX_PATH];

static int resolve_path(const char *path, char *out, size_t outsz)
{
    int len;

    if (path == NULL || *path == '\0') {
        out[0] = '\0';
        return 0;
    }
    if (path[0] == '/') {
        if (strlen(path) >= outsz) {
            return -1;
        }
        rv_strlcpy(out, outsz, path);
        return 0;
    }
    len = snprintf(out, outsz, "%s/%s", g_startup_dir, path);
    if (len < 0 || (size_t)len >= outsz) {
        return -1;
    }
    return 0;
}

static void config_directory(const char *config_path, char *out, size_t outsz)
{
    const char *slash = strrchr(config_path, '/');

    if (slash == NULL) {
        rv_strlcpy(out, outsz, g_startup_dir);
        return;
    }
    if (slash == config_path) {
        rv_strlcpy(out, outsz, "/");
        return;
    }
    if ((size_t)(slash - config_path) >= outsz) {
        rv_strlcpy(out, outsz, g_startup_dir);
        return;
    }
    memcpy(out, config_path, (size_t)(slash - config_path));
    out[slash - config_path] = '\0';
}

static int resolve_config_paths(rv_config *cfg)
{
    char tmp[RV_MAX_PATH];

    if (resolve_path(cfg->global.pid_file, tmp, sizeof(tmp)) < 0) {
        return -1;
    }
    rv_strlcpy(cfg->global.pid_file, sizeof(cfg->global.pid_file), tmp);
    if (resolve_path(cfg->global.stats_file, tmp, sizeof(tmp)) < 0) {
        return -1;
    }
    rv_strlcpy(cfg->global.stats_file, sizeof(cfg->global.stats_file), tmp);
    if (resolve_path(cfg->warp.domain_list, tmp, sizeof(tmp)) < 0) {
        return -1;
    }
    rv_strlcpy(cfg->warp.domain_list, sizeof(cfg->warp.domain_list), tmp);
    if (resolve_path(cfg->warp.ip_list, tmp, sizeof(tmp)) < 0) {
        return -1;
    }
    rv_strlcpy(cfg->warp.ip_list, sizeof(cfg->warp.ip_list), tmp);
    if (resolve_path(cfg->warp.awg_config, tmp, sizeof(tmp)) < 0) {
        return -1;
    }
    rv_strlcpy(cfg->warp.awg_config, sizeof(cfg->warp.awg_config), tmp);
    return 0;
}

static int load_config_file(rv_config *cfg, const char *path, int required)
{
    int rc;

    rv_config_defaults(cfg);
    rc = rv_config_load(cfg, path, required);
    if (rc == 1) {
        LOG_INFO("config '%s' not found; using built-in defaults", path);
        return 0;
    }
    if (rc < 0) {
        rv_config_free(cfg);
        return -1;
    }
    LOG_INFO("loaded configuration from %s", path);
    return 0;
}

static void log_startup_summary(const rv_config *cfg, int foreground)
{
    LOG_INFO("RawVeil %s starting (%s mode)", RV_VERSION,
             foreground ? "foreground" : "daemon");
    LOG_INFO("capture: interface=%s send_interface=%s threads=%d "
             "buffer_size=%d log_level=%s",
             cfg->global.interface,
             cfg->global.send_interface[0] != '\0'
                 ? cfg->global.send_interface : cfg->global.interface,
             cfg->global.threads, cfg->global.buffer_size,
             rv_log_level_name(cfg->global.log_level));
    LOG_INFO("doh: enabled=%d mode=%s (system resolver via getaddrinfo)",
             cfg->doh.enabled, cfg->doh.mode);
    LOG_INFO("warp: enabled=%d interface=%s mark=0x%x "
             "domain_list='%s' ip_list='%s' awg_config='%s'",
             cfg->warp.enabled, cfg->warp.interface, cfg->warp.mark,
             cfg->warp.domain_list, cfg->warp.ip_list,
             cfg->warp.awg_config);
    LOG_INFO("warp routing: manage=%d mode=%s table=%d priority=%d",
             cfg->warp.manage_routing,
             cfg->warp.routing_mode == RV_ROUTING_NFT ? "nft" : "route",
             cfg->warp.routing_table, cfg->warp.routing_priority);
    if (cfg->global.threads > 1) {
        LOG_INFO("MVP: capture runs in one reader thread; 'threads=%d' is "
                 "reserved for the strategy worker stage",
                 cfg->global.threads);
    }
    LOG_INFO("strategies: AF_PACKET TX/sendmmsg enabled; nftables and "
             "AmneziaWG are not managed by RawVeil");
}

static void signal_handler(int signo)
{
    if (signo == SIGTERM || signo == SIGINT) {
        g_stop = 1;
    } else if (signo == SIGHUP) {
        g_reload = 1;
    } else if (signo == SIGUSR1) {
        g_stats = 1;
    }
}

static int install_signal_handlers(void)
{
    struct sigaction sa;

    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = signal_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    if (sigaction(SIGTERM, &sa, NULL) < 0 ||
        sigaction(SIGINT, &sa, NULL) < 0 ||
        sigaction(SIGHUP, &sa, NULL) < 0 ||
        sigaction(SIGUSR1, &sa, NULL) < 0) {
        return -1;
    }
    if (signal(SIGPIPE, SIG_IGN) == SIG_ERR) {
        return -1;
    }
    return 0;
}

static void write_stats(const rv_config *cfg, const rv_capture *cap,
                        rv_warp *warp, rv_engine *engine,
                        time_t started, const char *reason)
{
    rv_capture_stats st;
    rv_engine_stats est;
    FILE *fp;
    int fd;
    char timestamp[64];
    time_t now = time(NULL);
    struct tm tm_now;
    int failed = 0;

    rv_capture_get_stats(cap, &st);
    rv_engine_get_stats(engine, &est);
    timestamp[0] = '\0';
    if (localtime_r(&now, &tm_now) != NULL) {
        (void)strftime(timestamp, sizeof(timestamp),
                       "%Y-%m-%dT%H:%M:%S", &tm_now);
    }

    fd = open(cfg->global.stats_file,
              O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC | O_NOFOLLOW, 0644);
    if (fd < 0) {
        LOG_WARN("cannot write statistics to '%s': %s",
                 cfg->global.stats_file, strerror(errno));
        return;
    }
    fp = fdopen(fd, "w");
    if (fp == NULL) {
        LOG_WARN("cannot open statistics stream for '%s': %s",
                 cfg->global.stats_file, strerror(errno));
        close(fd);
        return;
    }

    if (fprintf(fp, "rawveil_version=%s\n", RV_VERSION) < 0 ||
        fprintf(fp, "pid=%ld\n", (long)getpid()) < 0 ||
        fprintf(fp, "timestamp=%s\n", timestamp) < 0 ||
        fprintf(fp, "uptime_seconds=%lld\n",
                (long long)(now - started)) < 0 ||
        fprintf(fp, "reason=%s\n", reason) < 0 ||
        fprintf(fp, "interface=%s\n",
                rv_capture_interface(cap)) < 0 ||
        fprintf(fp, "send_interface=%s\n",
                cfg->global.send_interface[0] != '\0'
                    ? cfg->global.send_interface : cfg->global.interface) < 0 ||
        fprintf(fp, "warp_enabled=%d\n", rv_warp_enabled(warp)) < 0 ||
        fprintf(fp, "warp_mark=0x%" PRIx32 "\n", cfg->warp.mark) < 0 ||
        fprintf(fp, "awg_config=%s\n", cfg->warp.awg_config) < 0 ||
        fprintf(fp, "warp_manage_routing=%d\n",
                cfg->warp.manage_routing) < 0 ||
        fprintf(fp, "warp_routing_mode=%s\n",
                cfg->warp.routing_mode == RV_ROUTING_NFT ? "nft" : "route")
            < 0 ||
        fprintf(fp, "warp_routing_table=%d\n",
                cfg->warp.routing_table) < 0 ||
        fprintf(fp, "warp_routing_priority=%d\n",
                cfg->warp.routing_priority) < 0 ||
        fprintf(fp, "warp_ips=%zu\n", rv_warp_ip_count(warp)) < 0 ||
        fprintf(fp, "warp_domains=%zu\n",
                rv_warp_domain_count(warp)) < 0 ||
        fprintf(fp, "frames_seen=%" PRIu64 "\n", st.frames_seen) < 0 ||
        fprintf(fp, "outgoing=%" PRIu64 "\n", st.outgoing) < 0 ||
        fprintf(fp, "incoming_ignored=%" PRIu64 "\n",
                st.incoming_ignored) < 0 ||
        fprintf(fp, "ipv4=%" PRIu64 "\n", st.ipv4) < 0 ||
        fprintf(fp, "ipv6=%" PRIu64 "\n", st.ipv6) < 0 ||
        fprintf(fp, "tcp=%" PRIu64 "\n", st.tcp) < 0 ||
        fprintf(fp, "udp=%" PRIu64 "\n", st.udp) < 0 ||
        fprintf(fp, "other_l4=%" PRIu64 "\n", st.other_l4) < 0 ||
        fprintf(fp, "warp_matches=%" PRIu64 "\n", st.warp_matches) < 0 ||
        fprintf(fp, "injected_ignored=%" PRIu64 "\n",
                st.injected_ignored) < 0 ||
        fprintf(fp, "strategy_matched=%" PRIu64 "\n",
                est.matched_packets) < 0 ||
        fprintf(fp, "strategy_applied=%" PRIu64 "\n",
                est.strategy_packets) < 0 ||
        fprintf(fp, "strategy_injected_frames=%" PRIu64 "\n",
                est.injected_frames) < 0 ||
        fprintf(fp, "strategy_resent_frames=%" PRIu64 "\n",
                est.resent_frames) < 0 ||
        fprintf(fp, "strategy_send_errors=%" PRIu64 "\n",
                est.send_errors) < 0 ||
        fprintf(fp, "strategy_skipped_truncated=%" PRIu64 "\n",
                est.skipped_truncated) < 0 ||
        fprintf(fp, "tracker_entries=%zu\n",
                rv_engine_tracker_count(engine)) < 0 ||
        fprintf(fp, "read_errors=%" PRIu64 "\n", st.read_errors) < 0 ||
        fprintf(fp, "parse_errors=%" PRIu64 "\n", st.parse_errors) < 0 ||
        fprintf(fp, "truncated=%" PRIu64 "\n", st.truncated) < 0) {
        failed = 1;
    }
    if (fclose(fp) != 0) {
        failed = 1;
    }
    if (failed) {
        LOG_WARN("failed to write complete statistics to '%s'",
                 cfg->global.stats_file);
        return;
    }

    LOG_INFO("statistics (%s): outgoing=%" PRIu64 " tcp=%" PRIu64
             " udp=%" PRIu64 " warp_matches=%" PRIu64
             " parse_errors=%" PRIu64,
             reason, st.outgoing, st.tcp, st.udp, st.warp_matches,
             st.parse_errors);
}

static void reload_config(rv_config *cfg, const rv_cli *cli, rv_warp *warp,
                          rv_engine *engine, rv_routing *routing,
                          const char *path, int required)
{
    rv_config new_cfg;
    char err[256];
    int rc;

    rv_config_defaults(&new_cfg);
    rc = rv_config_load(&new_cfg, path, required);
    if (rc == 1) {
        LOG_WARN("config '%s' disappeared; keeping the current "
                 "configuration", path);
        rv_config_free(&new_cfg);
        return;
    }
    if (rc < 0) {
        LOG_ERROR("reload failed; keeping the current configuration");
        rv_config_free(&new_cfg);
        return;
    }
    if (apply_cli(&new_cfg, cli) < 0 ||
        resolve_config_paths(&new_cfg) < 0 ||
        rv_config_validate(&new_cfg) < 0) {
        LOG_ERROR("reload failed validation; keeping the current "
                  "configuration");
        rv_config_free(&new_cfg);
        return;
    }

    if (new_cfg.warp.enabled != cfg->warp.enabled ||
        new_cfg.warp.manage_routing != cfg->warp.manage_routing ||
        new_cfg.warp.routing_mode != cfg->warp.routing_mode ||
        new_cfg.warp.mark != cfg->warp.mark ||
        strcmp(new_cfg.warp.interface, cfg->warp.interface) != 0 ||
        new_cfg.warp.routing_table != cfg->warp.routing_table ||
        new_cfg.warp.routing_priority != cfg->warp.routing_priority ||
        strcmp(new_cfg.warp.awg_config, cfg->warp.awg_config) != 0) {
        LOG_WARN("WARP/AWG routing settings require a restart; reload "
                 "aborted");
        rv_config_free(&new_cfg);
        return;
    }
    if (strcmp(new_cfg.global.interface, cfg->global.interface) != 0 ||
        strcmp(new_cfg.global.send_interface,
               cfg->global.send_interface) != 0) {
        LOG_WARN("interface/send_interface change requires a restart; "
                 "keeping '%s' -> '%s'",
                 cfg->global.interface,
                 cfg->global.send_interface[0] != '\0'
                     ? cfg->global.send_interface : cfg->global.interface);
        LOG_WARN("reload aborted");
        rv_config_free(&new_cfg);
        return;
    }
    if (new_cfg.global.buffer_size != cfg->global.buffer_size) {
        LOG_WARN("buffer_size change requires a restart; keeping %d",
                 cfg->global.buffer_size);
        new_cfg.global.buffer_size = cfg->global.buffer_size;
    }
    if (new_cfg.global.threads != cfg->global.threads) {
        LOG_WARN("threads change requires a restart; keeping %d",
                 cfg->global.threads);
        new_cfg.global.threads = cfg->global.threads;
    }
    if (strcmp(new_cfg.global.pid_file, cfg->global.pid_file) != 0) {
        LOG_WARN("pid_file change requires a restart; keeping '%s'",
                 cfg->global.pid_file);
        rv_strlcpy(new_cfg.global.pid_file,
                   sizeof(new_cfg.global.pid_file), cfg->global.pid_file);
    }
    if (strcmp(new_cfg.global.stats_file, cfg->global.stats_file) != 0) {
        LOG_WARN("stats_file change requires a restart; keeping '%s'",
                 cfg->global.stats_file);
        rv_strlcpy(new_cfg.global.stats_file,
                   sizeof(new_cfg.global.stats_file),
                   cfg->global.stats_file);
    }

    err[0] = '\0';
    if (rv_warp_reload(warp, &new_cfg.warp, err, sizeof(err)) < 0) {
        LOG_ERROR("WARP reload failed: %s", err);
        rv_config_free(&new_cfg);
        return;
    }

    rv_log_set_level(new_cfg.global.log_level);
    rv_config_free(cfg);
    *cfg = new_cfg;
    if (engine != NULL) {
        err[0] = '\0';
        if (rv_engine_reload(engine, cfg, err, sizeof(err)) < 0) {
            LOG_ERROR("strategy reload failed, keeping old profiles: %s",
                      err);
        }
    }
    if (routing != NULL && routing->active) {
        err[0] = '\0';
        if (rv_routing_refresh(routing, warp, err, sizeof(err)) < 0) {
            LOG_ERROR("WARP routing set refresh failed: %s", err);
        }
    }
    LOG_INFO("configuration reloaded from %s", path);
}

static void run_loop(rv_config *cfg, const rv_cli *cli, rv_capture *cap,
                     rv_warp *warp, rv_engine *engine, rv_routing *routing,
                     const char *config_path, int config_required,
                     time_t started)
{
    time_t last_expire = time(NULL);

    while (!g_stop) {
        if (g_reload) {
            g_reload = 0;
            reload_config(cfg, cli, warp, engine, routing, config_path,
                          config_required);
        }
        if (g_stats) {
            g_stats = 0;
            write_stats(cfg, cap, warp, engine, started, "signal");
        }
        if (engine != NULL) {
            time_t now = time(NULL);

            if (now - last_expire >= 30) {
                rv_engine_expire(engine, now);
                last_expire = now;
            }
        }

        if (rv_capture_read(cap, warp, cfg->warp.mark,
                            cfg->warp.bypass_strategies,
                            engine, 500) < 0) {
            LOG_ERROR("capture loop stopped after a fatal read error");
            break;
        }
    }

    if (g_stats) {
        g_stats = 0;
        write_stats(cfg, cap, warp, engine, started, "signal");
    }
    write_stats(cfg, cap, warp, engine, started, "shutdown");
}

static int cmd_on(const rv_cli *cli)
{
    rv_config cfg;
    rv_pidfile pidfile;
    rv_warp *warp = NULL;
    rv_capture *cap = NULL;
    rv_engine *engine = NULL;
    rv_awg_config awg;
    rv_routing routing;
    int awg_loaded = 0;
    const char *config_path;
    char config_abs[RV_MAX_PATH];
    char config_dir[RV_MAX_PATH];
    char err[256] = {0};
    time_t started;
    int config_required;
    int exit_code = 1;
    int ready_fd = -1;
    int ready_sent = 0;

    if (getcwd(g_startup_dir, sizeof(g_startup_dir)) == NULL) {
        rv_strlcpy(g_startup_dir, sizeof(g_startup_dir), "/");
    }
    config_path = cli->config_path != NULL ? cli->config_path
                                           : RV_DEFAULT_CONFIG;
    config_required = cli->config_set;
    if (resolve_path(config_path, config_abs, sizeof(config_abs)) < 0) {
        fprintf(stderr, "rawveil: config path is too long\n");
        return 1;
    }
    config_path = config_abs;
    config_directory(config_path, config_dir, sizeof(config_dir));

    rv_log_init(cli->log_level_set ? cli->log_level_value : RV_LOG_INFO,
                0, RV_PROGRAM_NAME);

    if (load_config_file(&cfg, config_path, config_required) < 0) {
        return 1;
    }
    if (apply_cli(&cfg, cli) < 0) {
        rv_config_free(&cfg);
        return 1;
    }
    if (resolve_config_paths(&cfg) < 0) {
        fprintf(stderr, "rawveil: pid/stats/WARP list path is too long\n");
        rv_config_free(&cfg);
        return 1;
    }
    memset(&routing, 0, sizeof(routing));
    memset(&awg, 0, sizeof(awg));
    if (cfg.warp.enabled && cfg.warp.awg_config[0] != '\0') {
        err[0] = '\0';
        if (rv_awg_load(cfg.warp.awg_config, &awg,
                        err, sizeof(err)) < 0) {
            LOG_ERROR("cannot load AWG config: %s", err);
            rv_config_free(&cfg);
            return 1;
        }
        awg_loaded = 1;
        if (strcmp(cfg.warp.interface, awg.interface) != 0) {
            LOG_WARN("AWG config interface is '%s' (derived from %s); "
                     "overriding warp.interface='%s'", awg.interface,
                     awg.path, cfg.warp.interface);
            rv_strlcpy(cfg.warp.interface, sizeof(cfg.warp.interface),
                       awg.interface);
        }
        LOG_INFO("AWG: interface=%s address=%s mtu=%d table=%s "
                 "allowed_ips=%s", awg.interface,
                 awg.address[0] != '\0' ? awg.address : "(none)",
                 awg.mtu, awg.table[0] != '\0' ? awg.table : "(auto)",
                 awg.allowed_ips[0] != '\0' ? awg.allowed_ips : "(none)");
    }
    rv_log_set_level(cfg.global.log_level);
    if (rv_config_validate(&cfg) < 0) {
        rv_config_free(&cfg);
        return 1;
    }

    if (!cli->foreground) {
        err[0] = '\0';
        if (rv_daemonize(&ready_fd, err, sizeof(err)) < 0) {
            fprintf(stderr, "rawveil: daemonize failed: %s\n", err);
            rv_config_free(&cfg);
            return 1;
        }
        rv_log_init(cfg.global.log_level, 1, RV_PROGRAM_NAME);
    }

    log_startup_summary(&cfg, cli->foreground);

    memset(&pidfile, 0, sizeof(pidfile));
    pidfile.fd = -1;
    if (rv_pidfile_create(&pidfile, cfg.global.pid_file,
                          err, sizeof(err)) < 0) {
        LOG_ERROR("cannot create pid file: %s", err);
        goto cleanup;
    }
    err[0] = '\0';
    if (rv_prepare_stats_file(cfg.global.stats_file,
                              cfg.security.drop_privileges_to,
                              err, sizeof(err)) < 0) {
        LOG_WARN("statistics file is unavailable: %s", err);
    }
    err[0] = '\0';
    if (install_signal_handlers() < 0) {
        (void)snprintf(err, sizeof(err), "cannot install signal handlers: %s",
                       strerror(errno));
        LOG_ERROR("%s", err);
        goto cleanup;
    }

    err[0] = '\0';
    warp = rv_warp_create(&cfg.warp, err, sizeof(err));
    if (warp == NULL) {
        LOG_ERROR("cannot initialise WARP lists: %s", err);
        goto cleanup;
    }
    if (awg_loaded && cfg.warp.enabled && cfg.warp.manage_routing) {
        err[0] = '\0';
        if (rv_routing_setup(&routing, &cfg.warp, &awg, warp,
                             err, sizeof(err)) < 0) {
            LOG_ERROR("cannot set up AWG WARP routing: %s", err);
            goto cleanup;
        }
    } else if (awg_loaded) {
        LOG_INFO("routing: managed externally (manage_routing=%d, "
                 "warp.enabled=%d)", cfg.warp.manage_routing,
                 cfg.warp.enabled);
    } else if (cfg.warp.enabled && cfg.warp.manage_routing) {
        LOG_INFO("routing: no awg_config configured; managed externally");
    }

    err[0] = '\0';
    engine = rv_engine_create(&cfg,
                              cfg.global.send_interface[0] != '\0'
                                  ? cfg.global.send_interface
                                  : cfg.global.interface,
                              config_dir, err, sizeof(err));
    if (engine == NULL) {
        LOG_ERROR("cannot initialise strategy engine: %s", err);
        goto cleanup;
    }

    err[0] = '\0';
    cap = rv_capture_open(cfg.global.interface, cfg.global.buffer_size,
                          err, sizeof(err));
    if (cap == NULL) {
        LOG_ERROR("cannot open capture socket: %s", err);
        goto cleanup;
    }

    err[0] = '\0';
    if (rv_drop_privileges(cfg.security.drop_privileges_to,
                           cfg.security.required_caps,
                           err, sizeof(err)) < 0) {
        LOG_ERROR("privilege drop failed: %s", err);
        goto cleanup;
    }

    started = time(NULL);
    LOG_INFO("started; SIGTERM=stop, SIGHUP=reload, SIGUSR1=statistics");
    notify_daemon_ready(ready_fd, 1, NULL);
    ready_fd = -1;
    ready_sent = 1;
    if (!g_stop) {
        run_loop(&cfg, cli, cap, warp, engine, &routing, config_path,
                 config_required, started);
    }
    exit_code = 0;

cleanup:
    if (!ready_sent && ready_fd >= 0) {
        notify_daemon_ready(ready_fd, 0,
                            err[0] != '\0' ? err : "initialisation failed");
        ready_fd = -1;
    }
    rv_engine_destroy(engine);
    if (cap != NULL) {
        rv_capture_close(cap);
    }
    rv_routing_cleanup(&routing);
    if (warp != NULL) {
        rv_warp_destroy(warp);
    }
    if (pidfile.active) {
        rv_pidfile_remove(&pidfile);
    }
    LOG_INFO("stopped");
    rv_log_shutdown();
    rv_config_free(&cfg);
    return exit_code;
}

static int read_verified_pid(const char *pid_file, pid_t *pid,
                             char *err, size_t errlen)
{
    if (rv_pid_read(pid_file, pid, err, errlen) < 0) {
        return -1;
    }
    if (!rv_pid_is_alive(*pid)) {
        (void)snprintf(err, errlen,
                       "daemon is not running (stale pid file %s, pid %ld)",
                       pid_file, (long)*pid);
        return -1;
    }
    if (!rv_pid_matches_name(*pid, RV_PROGRAM_NAME)) {
        (void)snprintf(err, errlen,
                       "pid %ld from %s is not %s; refusing to signal it",
                       (long)*pid, pid_file, RV_PROGRAM_NAME);
        return -1;
    }
    return 0;
}

static void sleep_msec(long ms)
{
    struct timespec ts;

    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (ms % 1000) * 1000000L;
    while (nanosleep(&ts, &ts) < 0 && errno == EINTR) {
        /* continue */
    }
}

static void notify_daemon_ready(int fd, int ok, const char *message)
{
    char buf[512];
    int len;
    ssize_t off = 0;

    if (fd < 0) {
        return;
    }
    if (ok) {
        len = snprintf(buf, sizeof(buf), "OK\n");
    } else {
        len = snprintf(buf, sizeof(buf), "ERR: %s\n",
                       message != NULL ? message : "initialisation failed");
    }
    if (len < 0) {
        close(fd);
        return;
    }
    if ((size_t)len >= sizeof(buf)) {
        len = (int)sizeof(buf) - 1;
    }
    while (off < len) {
        ssize_t n = write(fd, buf + off, (size_t)(len - off));
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            break;
        }
        off += n;
    }
    close(fd);
}

static int cmd_off(const char *pid_file)
{
    char err[256];
    pid_t pid;
    int i;

    err[0] = '\0';
    if (read_verified_pid(pid_file, &pid, err, sizeof(err)) < 0) {
        fprintf(stderr, "rawveil: %s\n", err);
        return 1;
    }
    if (kill(pid, SIGTERM) < 0) {
        fprintf(stderr, "rawveil: kill(%ld, SIGTERM): %s\n",
                (long)pid, strerror(errno));
        return 1;
    }

    for (i = 0; i < 50; i++) {
        sleep_msec(100);
        if (!rv_pid_is_alive(pid)) {
            printf("rawveil: stopped (pid %ld)\n", (long)pid);
            return 0;
        }
    }
    fprintf(stderr, "rawveil: pid %ld did not stop within 5 seconds\n",
            (long)pid);
    return 1;
}

static void print_stats_file(const char *path)
{
    FILE *fp;
    char line[512];

    fp = fopen(path, "r");
    if (fp == NULL) {
        printf("statistics: not available (%s: %s)\n", path,
               strerror(errno));
        return;
    }
    printf("--- statistics (%s) ---\n", path);
    while (fgets(line, sizeof(line), fp) != NULL) {
        fputs(line, stdout);
    }
    printf("--- end statistics ---\n");
    fclose(fp);
}

static int cmd_status(const char *pid_file, const char *stats_file)
{
    char err[256];
    pid_t pid;

    err[0] = '\0';
    if (read_verified_pid(pid_file, &pid, err, sizeof(err)) < 0) {
        printf("rawveil: not running (%s)\n", err);
        return 3;
    }

    printf("rawveil: running (pid %ld)\n", (long)pid);
    if (kill(pid, SIGUSR1) < 0) {
        printf("rawveil: could not request fresh statistics: %s\n",
               strerror(errno));
    } else {
        /* The capture loop wakes at least every 500 ms (recvmmsg timeout). */
        sleep_msec(700);
    }
    print_stats_file(stats_file);
    return 0;
}

static int cmd_reload(const char *pid_file)
{
    char err[256];
    pid_t pid;

    err[0] = '\0';
    if (read_verified_pid(pid_file, &pid, err, sizeof(err)) < 0) {
        fprintf(stderr, "rawveil: %s\n", err);
        return 1;
    }
    if (kill(pid, SIGHUP) < 0) {
        fprintf(stderr, "rawveil: kill(%ld, SIGHUP): %s\n",
                (long)pid, strerror(errno));
        return 1;
    }
    printf("rawveil: reload requested (pid %ld)\n", (long)pid);
    return 0;
}

static int non_on_options_used(const rv_cli *cli)
{
    return cli->config_set || cli->interface != NULL ||
           cli->send_interface != NULL || cli->foreground ||
           cli->warp_list != NULL || cli->warp_ip_list != NULL ||
           cli->warp_iface != NULL || cli->awg_config != NULL ||
           cli->warp_mark_set ||
           cli->doh_mode != NULL || cli->doh_endpoint != NULL ||
           cli->doh_bootstrap != NULL || cli->profile_count > 0 ||
           cli->log_level_set || cli->threads_set;
}

int main(int argc, char **argv)
{
    const char *command;
    const char *pid_file;
    const char *stats_file;
    rv_cli cli;

    if (argc < 2) {
        usage(stderr);
        return 1;
    }
    if (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0) {
        usage(stdout);
        return 0;
    }
    if (strcmp(argv[1], "--version") == 0 || strcmp(argv[1], "-V") == 0) {
        printf("rawveil %s\n", RV_VERSION);
        return 0;
    }

    command = argv[1];
    if (strcmp(command, "on") != 0 && strcmp(command, "off") != 0 &&
        strcmp(command, "status") != 0 && strcmp(command, "reload") != 0) {
        fprintf(stderr, "rawveil: unknown command '%s'\n", command);
        usage(stderr);
        return 2;
    }

    if (parse_cli(argc - 1, argv + 1, &cli) < 0) {
        fprintf(stderr, "Try 'rawveil --help' for usage.\n");
        return 2;
    }
    if (cli.show_help) {
        usage(stdout);
        return 0;
    }
    if (cli.show_version) {
        printf("rawveil %s\n", RV_VERSION);
        return 0;
    }

    pid_file = cli.pid_file != NULL ? cli.pid_file : RV_DEFAULT_PID_FILE;
    stats_file = cli.stats_file != NULL ? cli.stats_file
                                        : RV_DEFAULT_STATS_FILE;

    if (strcmp(command, "on") == 0) {
        return cmd_on(&cli);
    }

    if (non_on_options_used(&cli)) {
        fprintf(stderr, "rawveil: only --pid-file/--stats-file are valid "
                "with '%s'\n", command);
        return 2;
    }
    if (strcmp(command, "off") == 0) {
        return cmd_off(pid_file);
    }
    if (strcmp(command, "status") == 0) {
        return cmd_status(pid_file, stats_file);
    }
    return cmd_reload(pid_file);
}
