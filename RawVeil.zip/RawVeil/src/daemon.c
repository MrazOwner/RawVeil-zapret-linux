#include "daemon.h"

#include "log.h"

#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <limits.h>
#include <linux/capability.h>
#include <pwd.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>

static void set_err(char *err, size_t errlen, const char *fmt, ...)
    __attribute__((format(printf, 3, 4)));

static void set_err(char *err, size_t errlen, const char *fmt, ...)
{
    va_list ap;

    if (err == NULL || errlen == 0) {
        return;
    }
    va_start(ap, fmt);
    (void)vsnprintf(err, errlen, fmt, ap);
    va_end(ap);
}

static void notify_pipe(int fd, const char *text)
{
    if (fd < 0) {
        return;
    }
    if (text != NULL) {
        size_t len = strlen(text);
        ssize_t off = 0;
        while ((size_t)off < len) {
            ssize_t n = write(fd, text + off, len - (size_t)off);
            if (n < 0) {
                if (errno == EINTR) {
                    continue;
                }
                break;
            }
            off += n;
        }
    }
    close(fd);
}

static void daemon_fail(int ready_fd, char *err, size_t errlen,
                        const char *what)
{
    char msg[512];

    (void)snprintf(msg, sizeof(msg), "ERR: %s\n", what);
    notify_pipe(ready_fd, msg);
    set_err(err, errlen, "%s", what);
}

int rv_daemonize(int *ready_fd, char *err, size_t errlen)
{
    pid_t pid;
    int fd;
    int pipefd[2];

    if (ready_fd == NULL) {
        set_err(err, errlen, "internal error: ready_fd is NULL");
        return -1;
    }
    *ready_fd = -1;

    if (pipe(pipefd) < 0) {
        set_err(err, errlen, "pipe: %s", strerror(errno));
        return -1;
    }

    pid = fork();
    if (pid < 0) {
        set_err(err, errlen, "fork: %s", strerror(errno));
        close(pipefd[0]);
        close(pipefd[1]);
        return -1;
    }
    if (pid > 0) {
        char buf[512];
        ssize_t n;

        close(pipefd[1]);
        do {
            n = read(pipefd[0], buf, sizeof(buf) - 1);
        } while (n < 0 && errno == EINTR);
        close(pipefd[0]);
        if (n > 0) {
            buf[n] = '\0';
            if (strncmp(buf, "OK", 2) == 0) {
                _exit(EXIT_SUCCESS);
            }
            if (strncmp(buf, "ERR:", 4) == 0) {
                fprintf(stderr, "rawveil: daemon startup failed:%s",
                        buf + 4);
            } else {
                fprintf(stderr, "rawveil: unexpected daemon response: %s\n",
                        buf);
            }
        } else {
            fprintf(stderr, "rawveil: daemon exited before reporting "
                    "readiness\n");
        }
        _exit(EXIT_FAILURE);
    }

    close(pipefd[0]);

    if (setsid() < 0) {
        daemon_fail(pipefd[1], err, errlen, "setsid failed");
        return -1;
    }

    /* Second fork: the daemon is not a session leader and cannot acquire a
     * controlling terminal. */
    pid = fork();
    if (pid < 0) {
        daemon_fail(pipefd[1], err, errlen, "second fork failed");
        return -1;
    }
    if (pid > 0) {
        _exit(EXIT_SUCCESS);
    }

    umask(022);
    if (chdir("/") < 0) {
        daemon_fail(pipefd[1], err, errlen, "chdir(/) failed");
        return -1;
    }

    fd = open("/dev/null", O_RDWR | O_CLOEXEC);
    if (fd < 0) {
        daemon_fail(pipefd[1], err, errlen, "open(/dev/null) failed");
        return -1;
    }
    if (dup2(fd, STDIN_FILENO) < 0 ||
        dup2(fd, STDOUT_FILENO) < 0 ||
        dup2(fd, STDERR_FILENO) < 0) {
        set_err(err, errlen, "dup2(/dev/null): %s", strerror(errno));
        daemon_fail(pipefd[1], err, errlen, "stdio redirection failed");
        if (fd > STDERR_FILENO) {
            close(fd);
        }
        return -1;
    }
    if (fd > STDERR_FILENO) {
        close(fd);
    }

    *ready_fd = pipefd[1];
    return 0;
}

static int cap_name_to_num(const char *name)
{
    if (strcmp(name, "CAP_NET_RAW") == 0) {
        return CAP_NET_RAW;
    }
    if (strcmp(name, "CAP_NET_ADMIN") == 0) {
        return CAP_NET_ADMIN;
    }
    if (strcmp(name, "CAP_NET_BIND_SERVICE") == 0) {
        return CAP_NET_BIND_SERVICE;
    }
    if (strcmp(name, "CAP_DAC_OVERRIDE") == 0) {
        return CAP_DAC_OVERRIDE;
    }
    return -1;
}

static int parse_required_caps(const char *text, uint32_t mask[2],
                               char *err, size_t errlen)
{
    char buf[RV_MAX_STR];
    char *save = NULL;
    char *token;

    mask[0] = 0;
    mask[1] = 0;
    if (text == NULL || *text == '\0') {
        return 0;
    }
    if (strlen(text) >= sizeof(buf)) {
        set_err(err, errlen, "required_caps value is too long");
        return -1;
    }
    rv_strlcpy(buf, sizeof(buf), text);
    for (token = strtok_r(buf, ",", &save); token != NULL;
         token = strtok_r(NULL, ",", &save)) {
        int cap;
        token = rv_trim(token);
        if (*token == '\0') {
            continue;
        }
        cap = cap_name_to_num(token);
        if (cap < 0) {
            set_err(err, errlen, "unsupported capability '%s'", token);
            return -1;
        }
        if (cap < 32) {
            mask[0] |= (uint32_t)1u << (unsigned)cap;
        } else {
            mask[1] |= (uint32_t)1u << (unsigned)(cap - 32);
        }
    }
    return 0;
}

int rv_drop_privileges(const char *user, const char *required_caps,
                       char *err, size_t errlen)
{
    struct passwd *pw;
    uint32_t cap_mask[2];
    int keep_caps;

    if (user == NULL || *user == '\0') {
        LOG_DEBUG("privilege drop disabled");
        return 0;
    }
    if (geteuid() != 0) {
        LOG_INFO("not running as root; skipping privilege drop to '%s'",
                 user);
        return 0;
    }
    if (parse_required_caps(required_caps, cap_mask, err, errlen) < 0) {
        return -1;
    }
    keep_caps = cap_mask[0] != 0 || cap_mask[1] != 0;

    pw = getpwnam(user);
    if (pw == NULL) {
        set_err(err, errlen, "unknown user '%s'", user);
        return -1;
    }

    if (initgroups(pw->pw_name, pw->pw_gid) < 0) {
        set_err(err, errlen, "initgroups(%s): %s", user, strerror(errno));
        return -1;
    }
    if (setgid(pw->pw_gid) < 0) {
        set_err(err, errlen, "setgid(%ld): %s", (long)pw->pw_gid,
                strerror(errno));
        return -1;
    }
    if (keep_caps && prctl(PR_SET_KEEPCAPS, 1, 0, 0, 0) < 0) {
        set_err(err, errlen, "prctl(PR_SET_KEEPCAPS): %s", strerror(errno));
        return -1;
    }
    if (setuid(pw->pw_uid) < 0) {
        set_err(err, errlen, "setuid(%ld): %s", (long)pw->pw_uid,
                strerror(errno));
        return -1;
    }

    if (keep_caps) {
        struct __user_cap_header_struct hdr;
        struct __user_cap_data_struct data[2];

        memset(&hdr, 0, sizeof(hdr));
        memset(data, 0, sizeof(data));
        hdr.version = _LINUX_CAPABILITY_VERSION_3;
        hdr.pid = 0;
        data[0].effective = cap_mask[0];
        data[0].permitted = cap_mask[0];
        data[1].effective = cap_mask[1];
        data[1].permitted = cap_mask[1];
        if (syscall(SYS_capset, &hdr, data) < 0) {
            set_err(err, errlen, "capset: %s", strerror(errno));
            return -1;
        }
        (void)prctl(PR_SET_KEEPCAPS, 0, 0, 0, 0);
    }

    if (setuid(0) == 0) {
        set_err(err, errlen, "privilege drop verification failed");
        return -1;
    }
    LOG_INFO("dropped privileges to user '%s' (uid=%ld, gid=%ld, "
             "retained_caps=0x%08x%08x)", user, (long)pw->pw_uid,
             (long)pw->pw_gid, cap_mask[1], cap_mask[0]);
    return 0;
}

int rv_pidfile_create(rv_pidfile *pf, const char *path,
                      char *err, size_t errlen)
{
    char buf[64];
    int len;
    int fd;

    if (pf == NULL || path == NULL || *path == '\0') {
        set_err(err, errlen, "invalid pid file path");
        return -1;
    }
    memset(pf, 0, sizeof(*pf));
    pf->fd = -1;
    rv_strlcpy(pf->path, sizeof(pf->path), path);

    fd = open(path, O_RDWR | O_CREAT | O_CLOEXEC | O_NOFOLLOW, 0644);
    if (fd < 0) {
        set_err(err, errlen, "open(%s): %s", path, strerror(errno));
        return -1;
    }
    if (flock(fd, LOCK_EX | LOCK_NB) < 0) {
        if (errno == EWOULDBLOCK) {
            set_err(err, errlen, "another rawveil instance holds %s", path);
        } else {
            set_err(err, errlen, "flock(%s): %s", path, strerror(errno));
        }
        close(fd);
        return -1;
    }
    if (ftruncate(fd, 0) < 0) {
        set_err(err, errlen, "ftruncate(%s): %s", path, strerror(errno));
        close(fd);
        return -1;
    }

    len = snprintf(buf, sizeof(buf), "%ld\n", (long)getpid());
    if (len < 0 || (size_t)len >= sizeof(buf)) {
        set_err(err, errlen, "cannot format pid");
        close(fd);
        return -1;
    }
    if (lseek(fd, 0, SEEK_SET) < 0) {
        set_err(err, errlen, "lseek(%s): %s", path, strerror(errno));
        close(fd);
        return -1;
    }
    {
        ssize_t written = 0;
        while (written < len) {
            ssize_t n = write(fd, buf + written, (size_t)(len - written));
            if (n < 0) {
                if (errno == EINTR) {
                    continue;
                }
                set_err(err, errlen, "write(%s): %s", path, strerror(errno));
                close(fd);
                return -1;
            }
            written += n;
        }
    }
    if (fsync(fd) < 0) {
        LOG_WARN("fsync(%s): %s", path, strerror(errno));
    }

    pf->fd = fd;
    pf->active = 1;
    return 0;
}

void rv_pidfile_remove(rv_pidfile *pf)
{
    if (pf == NULL || !pf->active) {
        return;
    }
    if (unlink(pf->path) < 0 && errno != ENOENT) {
        /* After setuid() the daemon may not have write permission on the
         * pid-file directory (/var/run). A stale, unlocked file is harmless:
         * the next start detects that nobody holds the flock. */
        LOG_DEBUG("could not unlink pid file %s: %s", pf->path,
                  strerror(errno));
    }
    if (pf->fd >= 0) {
        close(pf->fd);
    }
    pf->fd = -1;
    pf->active = 0;
}

int rv_pid_read(const char *path, pid_t *pid, char *err, size_t errlen)
{
    FILE *fp;
    char buf[64];
    char *end = NULL;
    long value;

    if (path == NULL || pid == NULL) {
        set_err(err, errlen, "invalid pid file path");
        return -1;
    }
    fp = fopen(path, "r");
    if (fp == NULL) {
        set_err(err, errlen, "cannot open pid file %s: %s", path,
                strerror(errno));
        return -1;
    }
    if (fgets(buf, sizeof(buf), fp) == NULL) {
        set_err(err, errlen, "pid file %s is empty", path);
        fclose(fp);
        return -1;
    }
    fclose(fp);

    errno = 0;
    value = strtol(buf, &end, 10);
    if (errno != 0 || end == buf || value <= 1 || value > INT_MAX) {
        set_err(err, errlen, "pid file %s contains an invalid pid", path);
        return -1;
    }
    while (*end == ' ' || *end == '\t' || *end == '\r' || *end == '\n') {
        end++;
    }
    if (*end != '\0') {
        set_err(err, errlen, "pid file %s contains an invalid pid", path);
        return -1;
    }
    *pid = (pid_t)value;
    return 0;
}

int rv_pid_is_alive(pid_t pid)
{
    if (pid <= 1) {
        return 0;
    }
    if (kill(pid, 0) == 0) {
        return 1;
    }
    if (errno == EPERM) {
        return 1;
    }
    return 0;
}

int rv_pid_matches_name(pid_t pid, const char *name)
{
    char path[64];
    char comm[64];
    FILE *fp;
    size_t len;

    if (pid <= 1 || name == NULL) {
        return 0;
    }
    (void)snprintf(path, sizeof(path), "/proc/%ld/comm", (long)pid);
    fp = fopen(path, "r");
    if (fp == NULL) {
        return 0;
    }
    if (fgets(comm, sizeof(comm), fp) == NULL) {
        fclose(fp);
        return 0;
    }
    fclose(fp);

    len = strlen(comm);
    while (len > 0 && (comm[len - 1] == '\n' || comm[len - 1] == '\r')) {
        comm[--len] = '\0';
    }
    return strcmp(comm, name) == 0;
}

int rv_prepare_stats_file(const char *path, const char *run_as,
                          char *err, size_t errlen)
{
    struct passwd *pw = NULL;
    int fd;

    if (path == NULL || *path == '\0') {
        set_err(err, errlen, "invalid stats file path");
        return -1;
    }

    fd = open(path, O_WRONLY | O_CREAT | O_CLOEXEC | O_NOFOLLOW, 0644);
    if (fd < 0) {
        set_err(err, errlen, "open(%s): %s", path, strerror(errno));
        return -1;
    }
    if (fchmod(fd, 0644) < 0) {
        LOG_WARN("fchmod(%s): %s", path, strerror(errno));
    }

    if (geteuid() == 0 && run_as != NULL && *run_as != '\0') {
        pw = getpwnam(run_as);
        if (pw == NULL) {
            LOG_WARN("stats file: unknown user '%s', keeping root ownership",
                     run_as);
        } else if (fchown(fd, pw->pw_uid, pw->pw_gid) < 0) {
            LOG_WARN("fchown(%s): %s", path, strerror(errno));
        }
    }
    close(fd);
    return 0;
}
