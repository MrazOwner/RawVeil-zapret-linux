/*
 * Classic BPF program builder for the RawVeil capture socket.
 *
 * Keeping the builder in a separate translation unit makes it testable
 * without CAP_NET_RAW: tests/bpf_test.c runs the generated program through a
 * small cBPF interpreter against synthetic Ethernet frames.
 */
#include "bpf_filter.h"

#include <stdint.h>
#include <string.h>

#define ETH_TYPE_IPV4 0x0800u
#define ETH_TYPE_IPV6 0x86ddu
#define ETH_TYPE_VLAN 0x8100u
#define ETH_TYPE_QINQ 0x88a8u

#define IPPROTO_TCP_ 6u
#define IPPROTO_UDP_ 17u

#define PORT_TLS 443u
#define PORT_WARP_MIN 50000u
#define PORT_WARP_MAX 50099u

/* Extra TLS ports used by the example Discord media profile. The MVP BPF
 * filter is a fixed superset; extend these constants for custom ports. */
#define PORT_MEDIA_1 2053u
#define PORT_MEDIA_2 2083u
#define PORT_MEDIA_3 2087u
#define PORT_MEDIA_4 2096u
#define PORT_MEDIA_5 8443u

enum bpf_label {
    L_ACCEPT = 0,
    L_REJECT,
    L_VLAN,
    L_IPV4,
    L_IPV6,
    L_V4_TCP,
    L_V4_UDP,
    L_V4_UDP_SRC_HI,
    L_V4_UDP_DST,
    L_V4_UDP_DST_HI,
    L_V6_TCP,
    L_V6_UDP,
    L_V6_UDP_SRC_HI,
    L_V6_UDP_DST,
    L_V6_UDP_DST_HI,
    L_V4_VLAN,
    L_V6_VLAN,
    L_V4_TCP_VLAN,
    L_V4_UDP_VLAN,
    L_V4_UDP_VLAN_SRC_HI,
    L_V4_UDP_VLAN_DST,
    L_V4_UDP_VLAN_DST_HI,
    L_V6_TCP_VLAN,
    L_V6_UDP_VLAN,
    L_V6_UDP_VLAN_SRC_HI,
    L_V6_UDP_VLAN_DST,
    L_V6_UDP_VLAN_DST_HI,
    L_COUNT
};

typedef struct bpf_fixup {
    int idx;
    int jt_label;
    int jf_label;
} bpf_fixup;

typedef struct bpf_builder {
    struct sock_filter insns[RV_BPF_MAX_INSNS];
    size_t count;
    int labels[L_COUNT];
    bpf_fixup fixups[RV_BPF_MAX_INSNS];
    size_t fixup_count;
} bpf_builder;

static int emit(bpf_builder *b, uint16_t code, uint32_t k)
{
    if (b->count >= RV_BPF_MAX_INSNS) {
        return -1;
    }
    b->insns[b->count].code = code;
    b->insns[b->count].jt = 0;
    b->insns[b->count].jf = 0;
    b->insns[b->count].k = k;
    b->count++;
    return 0;
}

static int emit_ja(bpf_builder *b, int label)
{
    int idx;

    if (b->fixup_count >= RV_BPF_MAX_INSNS) {
        return -1;
    }
    idx = (int)b->count;
    if (emit(b, (uint16_t)(BPF_JMP | BPF_JA), 0) < 0) {
        return -1;
    }
    b->fixups[b->fixup_count].idx = idx;
    b->fixups[b->fixup_count].jt_label = label;
    b->fixups[b->fixup_count].jf_label = -1;
    b->fixup_count++;
    return 0;
}

static int emit_jump(bpf_builder *b, uint16_t op, uint32_t k,
                     int jt_label, int jf_label)
{
    int idx;

    if (b->fixup_count >= RV_BPF_MAX_INSNS) {
        return -1;
    }
    idx = (int)b->count;
    if (emit(b, (uint16_t)(BPF_JMP | op | BPF_K), k) < 0) {
        return -1;
    }
    b->fixups[b->fixup_count].idx = idx;
    b->fixups[b->fixup_count].jt_label = jt_label;
    b->fixups[b->fixup_count].jf_label = jf_label;
    b->fixup_count++;
    return 0;
}

static void set_label(bpf_builder *b, int label)
{
    if (label >= 0 && label < L_COUNT) {
        b->labels[label] = (int)b->count;
    }
}

static int resolve_fixups(bpf_builder *b)
{
    size_t i;

    for (i = 0; i < b->fixup_count; i++) {
        const bpf_fixup *fix = &b->fixups[i];
        int jt_off;
        int jf_off;

        if (fix->jt_label < 0 || fix->jt_label >= L_COUNT) {
            return -1;
        }
        jt_off = b->labels[fix->jt_label] - (fix->idx + 1);
        if (jt_off < 0 || jt_off > 255) {
            return -1;
        }

        if (b->insns[fix->idx].code == (BPF_JMP | BPF_JA)) {
            b->insns[fix->idx].k = (uint32_t)jt_off;
            continue;
        }

        b->insns[fix->idx].jt = (uint8_t)jt_off;
        if (fix->jf_label >= 0) {
            if (fix->jf_label >= L_COUNT) {
                return -1;
            }
            jf_off = b->labels[fix->jf_label] - (fix->idx + 1);
            if (jf_off < 0 || jf_off > 255) {
                return -1;
            }
            b->insns[fix->idx].jf = (uint8_t)jf_off;
        } else {
            b->insns[fix->idx].jf = 0;
        }
    }
    return 0;
}

int rv_bpf_build_egress_filter(rv_bpf_program *out)
{
    bpf_builder b;
    size_t i;

    if (out == NULL) {
        return -1;
    }
    memset(&b, 0, sizeof(b));
    for (i = 0; i < L_COUNT; i++) {
        b.labels[i] = -1;
    }

    /* Ethernet type, with optional 802.1Q / QinQ tags. */
    if (emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 12) < 0 ||
        emit_jump(&b, BPF_JEQ, ETH_TYPE_IPV4, L_IPV4, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, ETH_TYPE_IPV6, L_IPV6, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, ETH_TYPE_VLAN, L_VLAN, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, ETH_TYPE_QINQ, L_VLAN, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }

    set_label(&b, L_VLAN);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 16) < 0 ||
        emit_jump(&b, BPF_JEQ, ETH_TYPE_IPV4, L_V4_VLAN, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, ETH_TYPE_IPV6, L_V6_VLAN, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }

    /* ---------- Untagged IPv4 ---------- */
    set_label(&b, L_IPV4);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_B | BPF_ABS), 23) < 0 ||
        emit_jump(&b, BPF_JEQ, IPPROTO_TCP_, L_V4_TCP, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, IPPROTO_UDP_, L_V4_UDP, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }

    set_label(&b, L_V4_TCP);
    if (emit(&b, (uint16_t)(BPF_LDX | BPF_B | BPF_MSH), 14) < 0 ||
        emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 20) < 0 ||
        emit_jump(&b, BPF_JSET, 0x1fffu, L_REJECT, -1) < 0 ||
        emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_IND), 14) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_IND), 16) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_1, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_2, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_3, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_4, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_5, L_ACCEPT, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }

    set_label(&b, L_V4_UDP);
    if (emit(&b, (uint16_t)(BPF_LDX | BPF_B | BPF_MSH), 14) < 0 ||
        emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 20) < 0 ||
        emit_jump(&b, BPF_JSET, 0x1fffu, L_REJECT, -1) < 0 ||
        emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_IND), 14) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JGE, PORT_WARP_MIN, L_V4_UDP_SRC_HI, -1) < 0 ||
        emit_ja(&b, L_V4_UDP_DST) < 0) {
        return -1;
    }
    set_label(&b, L_V4_UDP_SRC_HI);
    if (emit_jump(&b, BPF_JGT, PORT_WARP_MAX, L_V4_UDP_DST, -1) < 0 ||
        emit_ja(&b, L_ACCEPT) < 0) {
        return -1;
    }
    set_label(&b, L_V4_UDP_DST);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_IND), 16) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JGE, PORT_WARP_MIN, L_V4_UDP_DST_HI, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }
    set_label(&b, L_V4_UDP_DST_HI);
    if (emit_jump(&b, BPF_JGT, PORT_WARP_MAX, L_REJECT, -1) < 0 ||
        emit_ja(&b, L_ACCEPT) < 0) {
        return -1;
    }

    /* ---------- Untagged IPv6 (no extension headers) ---------- */
    set_label(&b, L_IPV6);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_B | BPF_ABS), 20) < 0 ||
        emit_jump(&b, BPF_JEQ, IPPROTO_TCP_, L_V6_TCP, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, IPPROTO_UDP_, L_V6_UDP, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }
    set_label(&b, L_V6_TCP);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 54) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 56) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_1, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_2, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_3, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_4, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_5, L_ACCEPT, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }
    set_label(&b, L_V6_UDP);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 54) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JGE, PORT_WARP_MIN, L_V6_UDP_SRC_HI, -1) < 0 ||
        emit_ja(&b, L_V6_UDP_DST) < 0) {
        return -1;
    }
    set_label(&b, L_V6_UDP_SRC_HI);
    if (emit_jump(&b, BPF_JGT, PORT_WARP_MAX, L_V6_UDP_DST, -1) < 0 ||
        emit_ja(&b, L_ACCEPT) < 0) {
        return -1;
    }
    set_label(&b, L_V6_UDP_DST);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 56) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JGE, PORT_WARP_MIN, L_V6_UDP_DST_HI, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }
    set_label(&b, L_V6_UDP_DST_HI);
    if (emit_jump(&b, BPF_JGT, PORT_WARP_MAX, L_REJECT, -1) < 0 ||
        emit_ja(&b, L_ACCEPT) < 0) {
        return -1;
    }

    /* ---------- Single VLAN tag: L3 starts at offset 18 ---------- */
    set_label(&b, L_V4_VLAN);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_B | BPF_ABS), 27) < 0 ||
        emit_jump(&b, BPF_JEQ, IPPROTO_TCP_, L_V4_TCP_VLAN, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, IPPROTO_UDP_, L_V4_UDP_VLAN, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }
    set_label(&b, L_V4_TCP_VLAN);
    if (emit(&b, (uint16_t)(BPF_LDX | BPF_B | BPF_MSH), 18) < 0 ||
        emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 24) < 0 ||
        emit_jump(&b, BPF_JSET, 0x1fffu, L_REJECT, -1) < 0 ||
        emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_IND), 18) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_IND), 20) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_1, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_2, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_3, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_4, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_5, L_ACCEPT, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }
    set_label(&b, L_V4_UDP_VLAN);
    if (emit(&b, (uint16_t)(BPF_LDX | BPF_B | BPF_MSH), 18) < 0 ||
        emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 24) < 0 ||
        emit_jump(&b, BPF_JSET, 0x1fffu, L_REJECT, -1) < 0 ||
        emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_IND), 18) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JGE, PORT_WARP_MIN, L_V4_UDP_VLAN_SRC_HI, -1) < 0 ||
        emit_ja(&b, L_V4_UDP_VLAN_DST) < 0) {
        return -1;
    }
    set_label(&b, L_V4_UDP_VLAN_SRC_HI);
    if (emit_jump(&b, BPF_JGT, PORT_WARP_MAX, L_V4_UDP_VLAN_DST, -1) < 0 ||
        emit_ja(&b, L_ACCEPT) < 0) {
        return -1;
    }
    set_label(&b, L_V4_UDP_VLAN_DST);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_IND), 20) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JGE, PORT_WARP_MIN, L_V4_UDP_VLAN_DST_HI, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }
    set_label(&b, L_V4_UDP_VLAN_DST_HI);
    if (emit_jump(&b, BPF_JGT, PORT_WARP_MAX, L_REJECT, -1) < 0 ||
        emit_ja(&b, L_ACCEPT) < 0) {
        return -1;
    }

    set_label(&b, L_V6_VLAN);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_B | BPF_ABS), 24) < 0 ||
        emit_jump(&b, BPF_JEQ, IPPROTO_TCP_, L_V6_TCP_VLAN, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, IPPROTO_UDP_, L_V6_UDP_VLAN, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }
    set_label(&b, L_V6_TCP_VLAN);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 58) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 60) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_1, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_2, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_3, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_4, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_MEDIA_5, L_ACCEPT, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }
    set_label(&b, L_V6_UDP_VLAN);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 58) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JGE, PORT_WARP_MIN, L_V6_UDP_VLAN_SRC_HI, -1) < 0 ||
        emit_ja(&b, L_V6_UDP_VLAN_DST) < 0) {
        return -1;
    }
    set_label(&b, L_V6_UDP_VLAN_SRC_HI);
    if (emit_jump(&b, BPF_JGT, PORT_WARP_MAX, L_V6_UDP_VLAN_DST, -1) < 0 ||
        emit_ja(&b, L_ACCEPT) < 0) {
        return -1;
    }
    set_label(&b, L_V6_UDP_VLAN_DST);
    if (emit(&b, (uint16_t)(BPF_LD | BPF_H | BPF_ABS), 60) < 0 ||
        emit_jump(&b, BPF_JEQ, PORT_TLS, L_ACCEPT, -1) < 0 ||
        emit_jump(&b, BPF_JGE, PORT_WARP_MIN, L_V6_UDP_VLAN_DST_HI, -1) < 0 ||
        emit_ja(&b, L_REJECT) < 0) {
        return -1;
    }
    set_label(&b, L_V6_UDP_VLAN_DST_HI);
    if (emit_jump(&b, BPF_JGT, PORT_WARP_MAX, L_REJECT, -1) < 0 ||
        emit_ja(&b, L_ACCEPT) < 0) {
        return -1;
    }

    set_label(&b, L_ACCEPT);
    if (emit(&b, (uint16_t)(BPF_RET | BPF_K), UINT32_MAX) < 0) {
        return -1;
    }
    set_label(&b, L_REJECT);
    if (emit(&b, (uint16_t)(BPF_RET | BPF_K), 0) < 0) {
        return -1;
    }

    if (resolve_fixups(&b) < 0) {
        return -1;
    }

    memcpy(out->insns, b.insns, b.count * sizeof(b.insns[0]));
    out->count = b.count;
    return 0;
}
