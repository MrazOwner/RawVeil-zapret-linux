#include "strategies.h"

#include "l7.h"
#include "log.h"
#include "netbuild.h"
#include "quic.h"
#include "sender.h"
#include "tracker.h"
#include "tls_parser.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define RV_MAX_TX_BATCH 64
#define RV_MAX_FRAME (65535 + 128)
#define RV_MAX_UDP_FAKE_PAYLOAD 1200u
#define RV_MAX_PORT_RANGES 16
#define RV_MAX_FAKE_COUNT 16
#define RV_MAX_SEGMENTS 8
#define RV_MAX_FAKE_PAYLOAD 4096
#define RV_MAX_FILTER_SNI 1024
#define RV_MAX_LIST_PATTERNS 8192
#define RV_MAX_LIST_LINE 512
#define RV_MAX_IP_RANGES 8192

typedef struct rv_ip_range {
    int family;
    uint8_t addr[16];
    uint8_t mask[16];
} rv_ip_range;

typedef enum rv_strategy_kind {
    RV_STRATEGY_NONE = 0,
    RV_STRATEGY_MULTISPLIT,
    RV_STRATEGY_FAKE,
    RV_STRATEGY_FAKEDSPLIT,
    RV_STRATEGY_FAKE_SESSION,
    RV_STRATEGY_FAKE_QUIC_INITIAL,
    RV_STRATEGY_QUIC_BLOCK,
    RV_STRATEGY_QUIC_FRAGMENT
} rv_strategy_kind;

typedef struct rv_port_range {
    uint16_t lo;
    uint16_t hi;
} rv_port_range;

typedef struct rv_compiled_profile {
    char name[RV_MAX_NAME];
    int proto;                 /* 0 = any */
    rv_port_range ports[RV_MAX_PORT_RANGES];
    size_t port_count;
    unsigned l7_mask;          /* RV_L7_* */
    int l7_any;
    rv_strategy_kind strategy;
    int split_pos;
    int seqovl;
    int segments;
    int split_reverse;
    int split_all;
    int split_extra_one;
    int desync_data_packets;
    int desync_data_bytes;
    int desync_data_start;
    int fake_bad_checksum;
    int fake_md5sig;
    int fake_seq_offset;
    int wssize;
    int fake_count;
    int session_freeze_after;
    int fake_ttl;
    int tcp_ack_offset;
    int replace_original;
    int fake_before;
    int priority;
    int frag_pos;
    int frag_count;
    int frag_reverse;
    int split_sni_mode;        /* 0=off, 1=before, 2=middle, 3=after */
    char filter_sni[RV_MAX_FILTER_SNI];
    char filter_sni_exclude[RV_MAX_FILTER_SNI];
    char **list_patterns;
    size_t list_pattern_count;
    rv_ip_range *ip_ranges;
    size_t ip_range_count;
    char fallback[RV_MAX_NAME];
    char fake_sni[RV_TLS_SNI_MAX];

    uint8_t *fake_payload;
    size_t fake_payload_len;
    int fake_payload_from_file;
} rv_compiled_profile;

struct rv_engine {
    const rv_config *cfg;
    rv_sender *sender;
    rv_tracker *tracker;
    char base_dir[RV_MAX_PATH];
    int capture_mode;
    int redirect_original;

    rv_compiled_profile *profiles;
    size_t profile_count;

    uint8_t *tx_bufs[RV_MAX_TX_BATCH];
    rv_tx_frame tx_frames[RV_MAX_TX_BATCH];
    size_t tx_count;
    uint16_t tx_window;

    rv_engine_stats stats;
};

static int sni_token_matches(const char *token, const char *sni);

static const char *profile_str(const rv_config *cfg, const char *name,
                               const char *key, const char *def)
{
    const char *value = rv_config_profile_get(cfg, name, key);
    return value != NULL ? value : def;
}

static int profile_int_strict(const rv_config *cfg, const char *name,
                              const char *key, int def, int base,
                              long min, long max, int *out)
{
    const char *value = rv_config_profile_get(cfg, name, key);
    char *end = NULL;
    long parsed;

    if (value == NULL) {
        *out = def;
        return 0;
    }
    errno = 0;
    parsed = strtol(value, &end, base);
    if (errno != 0 || end == value || *end != '\0' ||
        parsed < min || parsed > max) {
        LOG_ERROR("profile '%s': invalid integer for '%s': '%s'",
                  name, key, value);
        return -1;
    }
    *out = (int)parsed;
    return 0;
}

static int profile_bool_strict(const rv_config *cfg, const char *name,
                               const char *key, int def, int *out)
{
    const char *value = rv_config_profile_get(cfg, name, key);

    if (value == NULL) {
        *out = def;
        return 0;
    }
    if (strcasecmp(value, "true") == 0 || strcasecmp(value, "yes") == 0 ||
        strcasecmp(value, "on") == 0 || strcmp(value, "1") == 0) {
        *out = 1;
        return 0;
    }
    if (strcasecmp(value, "false") == 0 || strcasecmp(value, "no") == 0 ||
        strcasecmp(value, "off") == 0 || strcmp(value, "0") == 0) {
        *out = 0;
        return 0;
    }
    LOG_ERROR("profile '%s': invalid boolean for '%s': '%s'",
              name, key, value);
    return -1;
}

static int profile_sni_mode(const rv_config *cfg, const char *name, int *out)
{
    const char *value = rv_config_profile_get(cfg, name, "split_sni");

    if (value == NULL) {
        *out = 0;
        return 0;
    }
    if (strcasecmp(value, "false") == 0 || strcasecmp(value, "no") == 0 ||
        strcasecmp(value, "off") == 0 || strcmp(value, "0") == 0) {
        *out = 0;
    } else if (strcasecmp(value, "true") == 0 ||
               strcasecmp(value, "yes") == 0 ||
               strcasecmp(value, "on") == 0 || strcmp(value, "1") == 0 ||
               strcasecmp(value, "middle") == 0) {
        *out = 2;
    } else if (strcasecmp(value, "start") == 0 ||
               strcasecmp(value, "before") == 0) {
        *out = 1;
    } else if (strcasecmp(value, "end") == 0 ||
               strcasecmp(value, "after") == 0) {
        *out = 3;
    } else {
        LOG_ERROR("profile '%s': invalid split_sni '%s' "
                  "(false|start|middle|end)", name, value);
        return -1;
    }
    return 0;
}

static int parse_strategy_name(const char *name, rv_strategy_kind *out)
{
    if (name == NULL) {
        return -1;
    }
    if (strcasecmp(name, "multisplit") == 0) {
        *out = RV_STRATEGY_MULTISPLIT;
    } else if (strcasecmp(name, "fake") == 0) {
        *out = RV_STRATEGY_FAKE;
    } else if (strcasecmp(name, "fakedsplit") == 0) {
        *out = RV_STRATEGY_FAKEDSPLIT;
    } else if (strcasecmp(name, "fake_session") == 0) {
        *out = RV_STRATEGY_FAKE_SESSION;
    } else if (strcasecmp(name, "fake_quic_initial") == 0) {
        *out = RV_STRATEGY_FAKE_QUIC_INITIAL;
    } else if (strcasecmp(name, "none") == 0 ||
               strcasecmp(name, "passthrough") == 0) {
        *out = RV_STRATEGY_NONE;
    } else if (strcasecmp(name, "quic_block") == 0 ||
               strcasecmp(name, "force_tcp") == 0) {
        *out = RV_STRATEGY_QUIC_BLOCK;
    } else if (strcasecmp(name, "quic_fragment") == 0 ||
               strcasecmp(name, "fragment") == 0) {
        *out = RV_STRATEGY_QUIC_FRAGMENT;
    } else {
        return -1;
    }
    return 0;
}

static int parse_proto_name(const char *name)
{
    if (name == NULL || *name == '\0' || strcasecmp(name, "any") == 0) {
        return 0;
    }
    if (strcasecmp(name, "tcp") == 0) {
        return IPPROTO_TCP;
    }
    if (strcasecmp(name, "udp") == 0) {
        return IPPROTO_UDP;
    }
    return -1;
}

static int parse_l7_mask(const char *text, unsigned *mask, int *is_any)
{
    char buf[RV_MAX_STR];
    char *save = NULL;
    char *token;
    unsigned result = 0;

    *mask = 0;
    *is_any = 1;
    if (text == NULL || *text == '\0') {
        return 0;
    }
    if (strlen(text) >= sizeof(buf)) {
        return -1;
    }
    rv_strlcpy(buf, sizeof(buf), text);
    *is_any = 0;

    for (token = strtok_r(buf, ",", &save); token != NULL;
         token = strtok_r(NULL, ",", &save)) {
        token = rv_trim(token);
        if (*token == '\0') {
            continue;
        }
        if (strcasecmp(token, "tls") == 0) {
            result |= RV_L7_TLS;
        } else if (strcasecmp(token, "quic") == 0) {
            result |= RV_L7_QUIC;
        } else if (strcasecmp(token, "quic_initial") == 0) {
            result |= RV_L7_QUIC | RV_L7_QUIC_INITIAL;
        } else if (strcasecmp(token, "stun") == 0) {
            result |= RV_L7_STUN;
        } else if (strcasecmp(token, "rtp") == 0) {
            result |= RV_L7_RTP;
        } else if (strcasecmp(token, "discord") == 0) {
            result |= RV_L7_RTP | RV_L7_STUN;
        } else {
            return -1;
        }
    }
    *mask = result;
    *is_any = result == 0;
    return 0;
}

static int parse_ports(const char *text, rv_compiled_profile *profile)
{
    char buf[RV_MAX_STR];
    char *cur;

    if (text == NULL || *text == '\0') {
        return 0;
    }
    if (strlen(text) >= sizeof(buf)) {
        return -1;
    }
    rv_strlcpy(buf, sizeof(buf), text);
    cur = buf;

    while (*cur != '\0') {
        unsigned long lo;
        unsigned long hi;
        char *end = NULL;

        while (*cur == ',' || isspace((unsigned char)*cur)) {
            cur++;
        }
        if (*cur == '\0') {
            break;
        }
        if (!isdigit((unsigned char)*cur)) {
            return -1;
        }
        errno = 0;
        lo = strtoul(cur, &end, 10);
        if (errno != 0 || end == cur || lo > 65535u) {
            return -1;
        }
        cur = end;
        while (isspace((unsigned char)*cur)) {
            cur++;
        }
        hi = lo;
        if (*cur == '-') {
            cur++;
            while (isspace((unsigned char)*cur)) {
                cur++;
            }
            if (!isdigit((unsigned char)*cur)) {
                return -1;
            }
            errno = 0;
            hi = strtoul(cur, &end, 10);
            if (errno != 0 || end == cur || hi > 65535u || hi < lo) {
                return -1;
            }
            cur = end;
        }
        while (isspace((unsigned char)*cur)) {
            cur++;
        }
        if (*cur != '\0' && *cur != ',') {
            return -1;
        }
        if (profile->port_count >= RV_MAX_PORT_RANGES) {
            return -1;
        }
        profile->ports[profile->port_count].lo = (uint16_t)lo;
        profile->ports[profile->port_count].hi = (uint16_t)hi;
        profile->port_count++;
        if (*cur == ',') {
            cur++;
        }
    }
    return 0;
}

static uint8_t pattern_byte(size_t i)
{
    return (uint8_t)(((i * 73u) + 41u) ^ ((i >> 3) * 19u));
}

static uint8_t *make_builtin_payload(const rv_compiled_profile *profile,
                                     size_t *out_len)
{
    uint8_t *data;
    size_t len;
    size_t i;

    if ((profile->l7_mask & RV_L7_QUIC) != 0) {
        len = 1200;
        data = malloc(len);
        if (data == NULL) {
            return NULL;
        }
        memset(data, 0, len);
        data[0] = 0xc0; /* long header + fixed bit */
        data[1] = 0x00;
        data[2] = 0x00;
        data[3] = 0x00;
        data[4] = 0x01; /* QUIC v1 */
        data[5] = 8;    /* DCID length */
        for (i = 0; i < 8; i++) {
            data[6 + i] = pattern_byte(i + 1);
        }
        data[14] = 0; /* SCID length */
        data[15] = 0; /* token length varint */
        /* Length varint covers the 1-byte packet number and ciphertext. */
        data[16] = (uint8_t)(0x40u | (((len - 18u) >> 8) & 0x3fu));
        data[17] = (uint8_t)((len - 18u) & 0xffu);
        data[18] = 0; /* packet number */
        for (i = 19; i < len; i++) {
            data[i] = pattern_byte(i);
        }
    } else if ((profile->l7_mask & RV_L7_STUN) != 0) {
        len = 20;
        data = calloc(1, len);
        if (data == NULL) {
            return NULL;
        }
        data[0] = 0x00;
        data[1] = 0x01; /* Binding request */
        data[2] = 0x00;
        data[3] = 0x00;
        data[4] = 0x21;
        data[5] = 0x12;
        data[6] = 0xa4;
        data[7] = 0x42;
        for (i = 8; i < 20; i++) {
            data[i] = pattern_byte(i);
        }
    } else if ((profile->l7_mask & RV_L7_RTP) != 0) {
        len = 44;
        data = calloc(1, len);
        if (data == NULL) {
            return NULL;
        }
        data[0] = 0x80; /* RTP v2 */
        data[1] = 0x60;
        data[2] = 0x00;
        data[3] = 0x01;
        for (i = 4; i < len; i++) {
            data[i] = pattern_byte(i);
        }
    } else {
        len = 64;
        data = malloc(len);
        if (data == NULL) {
            return NULL;
        }
        for (i = 0; i < len; i++) {
            data[i] = pattern_byte(i);
        }
    }
    *out_len = len;
    return data;
}

static void ip_ranges_free(rv_compiled_profile *profile)
{
    free(profile->ip_ranges);
    profile->ip_ranges = NULL;
    profile->ip_range_count = 0;
}

static int ip_range_add(rv_compiled_profile *profile, const char *line)
{
    char text[RV_MAX_LIST_LINE];
    char *slash;
    char *end = NULL;
    long prefix = -1;
    int family;
    uint8_t addr[16];
    uint8_t mask[16];
    size_t addr_len;
    size_t i;
    rv_ip_range *next;

    rv_strlcpy(text, sizeof(text), line);
    slash = strchr(text, '/');
    if (slash != NULL) {
        *slash++ = '\0';
        errno = 0;
        prefix = strtol(slash, &end, 10);
        if (errno != 0 || end == slash || *end != '\0') {
            return -1;
        }
    }
    if (inet_pton(AF_INET, rv_trim(text), addr) == 1) {
        family = AF_INET;
        addr_len = 4;
        if (prefix < 0) {
            prefix = 32;
        }
    } else if (inet_pton(AF_INET6, rv_trim(text), addr) == 1) {
        family = AF_INET6;
        addr_len = 16;
        if (prefix < 0) {
            prefix = 128;
        }
    } else {
        return -1;
    }
    if (prefix > (long)(addr_len * 8u)) {
        return -1;
    }
    if (profile->ip_range_count >= RV_MAX_IP_RANGES) {
        return -1;
    }
    memset(mask, 0, sizeof(mask));
    for (i = 0; i < addr_len; i++) {
        long bits = prefix - (long)(i * 8u);
        if (bits >= 8) {
            mask[i] = 0xffu;
        } else if (bits > 0) {
            mask[i] = (uint8_t)(0xffu << (8 - bits));
        }
    }
    next = realloc(profile->ip_ranges,
                   (profile->ip_range_count + 1) * sizeof(*next));
    if (next == NULL) {
        return -1;
    }
    profile->ip_ranges = next;
    profile->ip_ranges[profile->ip_range_count].family = family;
    memcpy(profile->ip_ranges[profile->ip_range_count].addr, addr,
           sizeof(addr));
    memcpy(profile->ip_ranges[profile->ip_range_count].mask, mask,
           sizeof(mask));
    profile->ip_range_count++;
    return 0;
}

static int load_ip_list_files(rv_engine *engine, rv_compiled_profile *profile,
                              const char *value)
{
    char paths[RV_MAX_STR];
    char *save = NULL;
    char *token;
    int loaded = 0;

    if (value == NULL || *value == '\0') {
        return 0;
    }
    if (strlen(value) >= sizeof(paths)) {
        LOG_ERROR("profile '%s': ip_lists value is too long", profile->name);
        return -1;
    }
    rv_strlcpy(paths, sizeof(paths), value);
    for (token = strtok_r(paths, ",", &save); token != NULL;
         token = strtok_r(NULL, ",", &save)) {
        char path[RV_MAX_PATH];
        char line[RV_MAX_LIST_LINE];
        FILE *fp;
        int count = 0;

        token = rv_trim(token);
        if (*token == '\0') {
            continue;
        }
        if (token[0] == '/') {
            rv_strlcpy(path, sizeof(path), token);
        } else if (engine->base_dir[0] != '\0') {
            int n = snprintf(path, sizeof(path), "%s/%s",
                             engine->base_dir, token);
            if (n < 0 || (size_t)n >= sizeof(path)) {
                LOG_ERROR("profile '%s': IP list path is too long",
                          profile->name);
                return -1;
            }
        } else {
            rv_strlcpy(path, sizeof(path), token);
        }
        fp = fopen(path, "r");
        if (fp == NULL) {
            LOG_ERROR("profile '%s': cannot open IP list '%s': %s",
                      profile->name, path, strerror(errno));
            return -1;
        }
        while (fgets(line, sizeof(line), fp) != NULL) {
            char *comment = strchr(line, '#');
            char *trimmed;

            if (comment != NULL) {
                *comment = '\0';
            }
            trimmed = rv_trim(line);
            if (*trimmed == '\0') {
                continue;
            }
            if (ip_range_add(profile, trimmed) < 0) {
                LOG_ERROR("profile '%s': invalid IP/CIDR '%s'",
                          profile->name, trimmed);
                fclose(fp);
                return -1;
            }
            count++;
        }
        fclose(fp);
        loaded += count;
        LOG_INFO("profile '%s': loaded %d IP/CIDR entries from %s",
                 profile->name, count, path);
    }
    if (loaded == 0) {
        LOG_WARN("profile '%s': IP lists matched no entries", profile->name);
    }
    return 0;
}

static int ip_ranges_match(const rv_compiled_profile *profile,
                           int family, const uint8_t *dst)
{
    size_t i;
    size_t len = family == AF_INET ? 4u : 16u;

    if (profile->ip_range_count == 0) {
        return 1;
    }
    if (family != AF_INET && family != AF_INET6) {
        return 0;
    }
    for (i = 0; i < profile->ip_range_count; i++) {
        const rv_ip_range *range = &profile->ip_ranges[i];
        size_t j;
        int match = 1;

        if (range->family != family) {
            continue;
        }
        for (j = 0; j < len; j++) {
            if ((dst[j] & range->mask[j]) != range->addr[j]) {
                match = 0;
                break;
            }
        }
        if (match) {
            return 1;
        }
    }
    return 0;
}

static void list_patterns_free(rv_compiled_profile *profile)
{
    size_t i;

    for (i = 0; i < profile->list_pattern_count; i++) {
        free(profile->list_patterns[i]);
    }
    free(profile->list_patterns);
    profile->list_patterns = NULL;
    profile->list_pattern_count = 0;
}

static int list_patterns_add(rv_compiled_profile *profile, const char *line)
{
    char normalized[RV_MAX_LIST_LINE];
    char **next;
    size_t len;

    if (profile->list_pattern_count >= RV_MAX_LIST_PATTERNS) {
        LOG_ERROR("profile '%s': too many list patterns", profile->name);
        return -1;
    }
    rv_strlcpy(normalized, sizeof(normalized), line);
    len = strlen(normalized);
    while (len > 0 &&
           (normalized[len - 1] == ' ' || normalized[len - 1] == '\t' ||
            normalized[len - 1] == '\r' || normalized[len - 1] == '\n')) {
        normalized[--len] = '\0';
    }
    if (len > 0 && normalized[len - 1] == '.') {
        normalized[--len] = '\0';
    }
    if (len > 1 && normalized[0] == '.') {
        memmove(normalized, normalized + 1, len);
        len--;
    }
    if (len == 0 || strchr(normalized, '/') != NULL) {
        return 0;
    }
    next = realloc(profile->list_patterns,
                   (profile->list_pattern_count + 1) * sizeof(*next));
    if (next == NULL) {
        return -1;
    }
    profile->list_patterns = next;
    profile->list_patterns[profile->list_pattern_count] = strdup(normalized);
    if (profile->list_patterns[profile->list_pattern_count] == NULL) {
        return -1;
    }
    profile->list_pattern_count++;
    return 0;
}

static int load_list_files(rv_engine *engine, rv_compiled_profile *profile,
                           const char *value)
{
    char paths[RV_MAX_STR];
    char *save = NULL;
    char *token;
    int loaded = 0;

    if (value == NULL || *value == '\0') {
        return 0;
    }
    if (strlen(value) >= sizeof(paths)) {
        LOG_ERROR("profile '%s': lists value is too long", profile->name);
        return -1;
    }
    rv_strlcpy(paths, sizeof(paths), value);
    for (token = strtok_r(paths, ",", &save); token != NULL;
         token = strtok_r(NULL, ",", &save)) {
        char path[RV_MAX_PATH];
        char line[RV_MAX_LIST_LINE];
        FILE *fp;
        int count = 0;

        token = rv_trim(token);
        if (*token == '\0') {
            continue;
        }
        if (token[0] == '/') {
            rv_strlcpy(path, sizeof(path), token);
        } else if (engine->base_dir[0] != '\0') {
            int n = snprintf(path, sizeof(path), "%s/%s",
                             engine->base_dir, token);
            if (n < 0 || (size_t)n >= sizeof(path)) {
                LOG_ERROR("profile '%s': list path is too long: %s",
                          profile->name, token);
                return -1;
            }
        } else {
            rv_strlcpy(path, sizeof(path), token);
        }
        fp = fopen(path, "r");
        if (fp == NULL) {
            LOG_ERROR("profile '%s': cannot open list '%s': %s",
                      profile->name, path, strerror(errno));
            return -1;
        }
        while (fgets(line, sizeof(line), fp) != NULL) {
            char *comment = strchr(line, '#');
            char *trimmed;

            if (comment != NULL) {
                *comment = '\0';
            }
            trimmed = rv_trim(line);
            if (*trimmed == '\0') {
                continue;
            }
            if (list_patterns_add(profile, trimmed) < 0) {
                LOG_ERROR("profile '%s': cannot add list entry '%s'",
                          profile->name, trimmed);
                fclose(fp);
                return -1;
            }
            count++;
        }
        fclose(fp);
        loaded += count;
        LOG_INFO("profile '%s': loaded %d entries from %s",
                 profile->name, count, path);
    }
    if (loaded == 0) {
        LOG_WARN("profile '%s': lists matched no entries", profile->name);
    }
    return 0;
}

static void free_profile_payloads(rv_compiled_profile *profiles, size_t count)
{
    size_t i;

    for (i = 0; i < count; i++) {
        free(profiles[i].fake_payload);
        profiles[i].fake_payload = NULL;
        profiles[i].fake_payload_len = 0;
        list_patterns_free(&profiles[i]);
        ip_ranges_free(&profiles[i]);
    }
}

static void load_fake_payload(rv_engine *engine, rv_compiled_profile *profile,
                              const char *configured_path)
{
    char path[RV_MAX_PATH];
    FILE *fp;
    uint8_t *data;
    size_t length;
    int n;

    if (configured_path == NULL || *configured_path == '\0') {
        profile->fake_payload = make_builtin_payload(profile, &length);
        profile->fake_payload_len = profile->fake_payload != NULL ? length : 0;
        return;
    }
    if (configured_path[0] == '/') {
        rv_strlcpy(path, sizeof(path), configured_path);
    } else if (engine->base_dir[0] != '\0') {
        n = snprintf(path, sizeof(path), "%s/%s",
                     engine->base_dir, configured_path);
        if (n < 0 || (size_t)n >= sizeof(path)) {
            LOG_WARN("profile '%s': fake_payload path is too long",
                     profile->name);
            path[0] = '\0';
        }
    } else {
        rv_strlcpy(path, sizeof(path), configured_path);
    }

    fp = path[0] != '\0' ? fopen(path, "rb") : NULL;
    if (fp == NULL) {
        LOG_DEBUG("profile '%s': fake_payload '%s' is unavailable, "
                  "using built-in payload", profile->name,
                  path[0] != '\0' ? path : configured_path);
        profile->fake_payload = make_builtin_payload(profile, &length);
        profile->fake_payload_len = profile->fake_payload != NULL ? length : 0;
        return;
    }

    data = malloc(RV_MAX_FAKE_PAYLOAD);
    if (data == NULL) {
        fclose(fp);
        profile->fake_payload = make_builtin_payload(profile, &length);
        profile->fake_payload_len = profile->fake_payload != NULL ? length : 0;
        return;
    }
    length = fread(data, 1, RV_MAX_FAKE_PAYLOAD, fp);
    if (ferror(fp)) {
        LOG_WARN("profile '%s': error reading fake_payload '%s'",
                 profile->name, path);
        free(data);
        data = NULL;
    }
    fclose(fp);
    if (data == NULL || length == 0) {
        free(data);
        profile->fake_payload = make_builtin_payload(profile, &length);
        profile->fake_payload_len = profile->fake_payload != NULL ? length : 0;
        return;
    }
    profile->fake_payload = data;
    profile->fake_payload_len = length;
    profile->fake_payload_from_file = 1;
    LOG_INFO("profile '%s': loaded %zu-byte fake payload from %s",
             profile->name, length, path);
}

static int compile_one_profile(rv_engine *engine, const rv_config *cfg,
                               const rv_profile *src,
                               rv_compiled_profile *profile)
{
    const char *strategy_name;
    const char *value;
    int proto;
    int enabled;

    memset(profile, 0, sizeof(*profile));
    if (profile_bool_strict(cfg, src->name, "enabled", 0, &enabled) < 0) {
        return -1;
    }
    if (!enabled) {
        return 0;
    }
    rv_strlcpy(profile->name, sizeof(profile->name), src->name);

    value = profile_str(cfg, src->name, "filter_proto", "any");
    proto = parse_proto_name(value);
    if (proto < 0) {
        LOG_ERROR("profile '%s': invalid filter_proto '%s'",
                  src->name, value);
        return -1;
    }
    profile->proto = proto;

    if (parse_ports(profile_str(cfg, src->name, "filter_ports", ""),
                    profile) < 0) {
        LOG_ERROR("profile '%s': invalid filter_ports", src->name);
        return -1;
    }
    if (parse_l7_mask(profile_str(cfg, src->name, "filter_l7", ""),
                      &profile->l7_mask, &profile->l7_any) < 0) {
        LOG_ERROR("profile '%s': invalid filter_l7", src->name);
        return -1;
    }

    strategy_name = profile_str(cfg, src->name, "strategy", "");
    if (*strategy_name == '\0' ||
        parse_strategy_name(strategy_name, &profile->strategy) < 0) {
        LOG_ERROR("profile '%s': invalid strategy '%s'",
                  src->name, strategy_name);
        return -1;
    }

    if (profile_int_strict(cfg, src->name, "split_pos", 1, 10,
                           0, 65535, &profile->split_pos) < 0 ||
        profile_int_strict(cfg, src->name, "seqovl", 0, 10,
                           0, 65535, &profile->seqovl) < 0 ||
        profile_int_strict(cfg, src->name, "segments", 2, 10,
                           2, RV_MAX_SEGMENTS, &profile->segments) < 0 ||
        profile_sni_mode(cfg, src->name, &profile->split_sni_mode) < 0 ||
        profile_bool_strict(cfg, src->name, "split_reverse", 0,
                            &profile->split_reverse) < 0 ||
        profile_bool_strict(cfg, src->name, "split_all", 0,
                            &profile->split_all) < 0 ||
        profile_bool_strict(cfg, src->name, "split_extra_one", 0,
                            &profile->split_extra_one) < 0 ||
        profile_int_strict(cfg, src->name, "desync_data_packets", 0, 10,
                           0, 1000000,
                           &profile->desync_data_packets) < 0 ||
        profile_int_strict(cfg, src->name, "desync_data_bytes", 0, 10,
                           0, INT_MAX, &profile->desync_data_bytes) < 0 ||
        profile_int_strict(cfg, src->name, "desync_data_start", 0, 10,
                           0, INT_MAX, &profile->desync_data_start) < 0 ||
        profile_bool_strict(cfg, src->name, "fake_bad_checksum", 0,
                            &profile->fake_bad_checksum) < 0 ||
        profile_bool_strict(cfg, src->name, "fake_md5sig", 0,
                            &profile->fake_md5sig) < 0 ||
        profile_int_strict(cfg, src->name, "fake_seq_offset", 0, 0,
                           INT_MIN, INT_MAX,
                           &profile->fake_seq_offset) < 0 ||
        profile_int_strict(cfg, src->name, "wssize", 0, 0,
                           0, 65535, &profile->wssize) < 0 ||
        profile_int_strict(cfg, src->name, "fake_count", 1, 10,
                           1, RV_MAX_FAKE_COUNT,
                           &profile->fake_count) < 0 ||
        profile_int_strict(cfg, src->name, "session_freeze_after", 1, 10,
                           0, 1000000,
                           &profile->session_freeze_after) < 0 ||
        profile_int_strict(cfg, src->name, "fake_ttl", 0, 10,
                           0, 255, &profile->fake_ttl) < 0 ||
        profile_int_strict(cfg, src->name, "tcp_ack_offset", 0, 0,
                           INT_MIN, INT_MAX,
                           &profile->tcp_ack_offset) < 0 ||
        profile_bool_strict(cfg, src->name, "replace_original", 1,
                            &profile->replace_original) < 0 ||
        profile_bool_strict(cfg, src->name, "fake_before", 1,
                            &profile->fake_before) < 0 ||
        profile_int_strict(cfg, src->name, "priority", 0, 10,
                           -1000000, 1000000, &profile->priority) < 0 ||
        profile_int_strict(cfg, src->name, "frag_pos", 24, 10,
                           8, 65535, &profile->frag_pos) < 0 ||
        profile_int_strict(cfg, src->name, "frag_count", 2, 10,
                           2, 8, &profile->frag_count) < 0 ||
        profile_bool_strict(cfg, src->name, "frag_reverse", 0,
                            &profile->frag_reverse) < 0) {
        return -1;
    }
    rv_strlcpy(profile->filter_sni, sizeof(profile->filter_sni),
               profile_str(cfg, src->name, "filter_sni", ""));
    rv_strlcpy(profile->filter_sni_exclude,
               sizeof(profile->filter_sni_exclude),
               profile_str(cfg, src->name, "filter_sni_exclude", ""));
    if (load_list_files(engine, profile,
                        profile_str(cfg, src->name, "lists",
                                    profile_str(cfg, src->name,
                                                "filter_lists", ""))) < 0) {
        return -1;
    }
    if (load_ip_list_files(engine, profile,
                           profile_str(cfg, src->name, "ip_lists",
                                       profile_str(cfg, src->name,
                                                   "filter_ips", ""))) < 0) {
        return -1;
    }
    rv_strlcpy(profile->fallback, sizeof(profile->fallback),
               profile_str(cfg, src->name, "fallback", ""));
    rv_strlcpy(profile->fake_sni, sizeof(profile->fake_sni),
               profile_str(cfg, src->name, "fake_sni", ""));

    if ((profile->split_sni_mode != 0 || profile->fake_sni[0] != '\0') &&
        (profile->strategy == RV_STRATEGY_QUIC_BLOCK ||
         profile->strategy == RV_STRATEGY_QUIC_FRAGMENT)) {
        LOG_ERROR("profile '%s': split_sni/fake_sni require a TCP strategy",
                  src->name);
        return -1;
    }
    /*
     * Make the first emitted segment avoid a complete SNI:
     * before-SNI split needs normal order; after-SNI split needs reverse.
     */
    if (profile->split_sni_mode == 1 && profile->split_reverse) {
        LOG_WARN("profile '%s': split_sni=start with split_reverse would "
                 "send the hostname first; forcing split_reverse=false",
                 src->name);
        profile->split_reverse = 0;
    } else if (profile->split_sni_mode == 3 && !profile->split_reverse) {
        LOG_WARN("profile '%s': split_sni=end with normal order would send "
                 "the full SNI first; forcing split_reverse=true", src->name);
        profile->split_reverse = 1;
    }
    if (profile->strategy == RV_STRATEGY_QUIC_FRAGMENT) {
        if (profile->frag_pos % 8 != 0) {
            LOG_ERROR("profile '%s': frag_pos must be a multiple of 8",
                      src->name);
            return -1;
        }
        if (profile->frag_count != 2) {
            LOG_ERROR("profile '%s': only frag_count=2 is implemented",
                      src->name);
            return -1;
        }
    }

    if (profile->split_pos < 0 || profile->split_pos > 65535 ||
        profile->seqovl < 0 || profile->seqovl > 65535) {
        LOG_ERROR("profile '%s': split_pos/seqovl out of range", src->name);
        return -1;
    }
    if (profile->segments < 2 || profile->segments > RV_MAX_SEGMENTS) {
        LOG_ERROR("profile '%s': segments must be in [2, %d]",
                  src->name, RV_MAX_SEGMENTS);
        return -1;
    }
    if (profile->fake_count < 1 ||
        profile->fake_count > RV_MAX_FAKE_COUNT) {
        LOG_ERROR("profile '%s': fake_count must be in [1, %d]",
                  src->name, RV_MAX_FAKE_COUNT);
        return -1;
    }
    if (profile->session_freeze_after < 0 ||
        profile->session_freeze_after > 1000000) {
        LOG_ERROR("profile '%s': session_freeze_after out of range",
                  src->name);
        return -1;
    }
    if (profile->fake_ttl < 0 || profile->fake_ttl > 255) {
        LOG_ERROR("profile '%s': fake_ttl must be in [0, 255]", src->name);
        return -1;
    }
    if ((profile->strategy == RV_STRATEGY_MULTISPLIT ||
         profile->strategy == RV_STRATEGY_FAKEDSPLIT) &&
        profile->proto != IPPROTO_TCP) {
        LOG_ERROR("profile '%s': %s requires filter_proto=tcp",
                  src->name, strategy_name);
        return -1;
    }
    if ((profile->strategy == RV_STRATEGY_FAKE_SESSION ||
         profile->strategy == RV_STRATEGY_FAKE_QUIC_INITIAL ||
         profile->strategy == RV_STRATEGY_QUIC_BLOCK ||
         profile->strategy == RV_STRATEGY_QUIC_FRAGMENT) &&
        profile->proto != IPPROTO_UDP) {
        LOG_ERROR("profile '%s': %s requires filter_proto=udp",
                  src->name, strategy_name);
        return -1;
    }
    if ((profile->strategy == RV_STRATEGY_MULTISPLIT ||
         profile->strategy == RV_STRATEGY_FAKEDSPLIT) &&
        profile->proto == IPPROTO_UDP) {
        LOG_ERROR("profile '%s': %s requires a TCP profile",
                  src->name, strategy_name);
        return -1;
    }

    load_fake_payload(engine, profile,
                      profile_str(cfg, src->name, "fake_payload", ""));
    if (profile->fake_payload == NULL || profile->fake_payload_len == 0) {
        LOG_ERROR("profile '%s': cannot create fake payload", src->name);
        return -1;
    }
    /*
     * A fake with a different payload and the same sequence number can be
     * accepted by the real server as valid stream data.  Move it outside the
     * receive window unless the user explicitly chose a bad checksum.
     */
    if (profile->proto == IPPROTO_TCP &&
        (profile->fake_sni[0] != '\0' || profile->fake_payload_from_file) &&
        profile->fake_seq_offset == 0 && !profile->fake_bad_checksum) {
        profile->fake_seq_offset = -10000;
        LOG_INFO("profile '%s': fake payload differs from the real stream; "
                 "using fake_seq_offset=-10000 to keep it out of the TCP "
                 "window", profile->name);
    }

    LOG_INFO("profile '%s': strategy=%s proto=%s ports=%zu l7=0x%x "
             "split=%d seqovl=%d segments=%d split_sni=%d "
             "split_reverse=%d split_all=%d split_extra_one=%d "
             "desync_data=%d fakes=%d freeze=%d replace_original=%d "
             "fake_ttl=%d fake_badsum=%d fake_md5sig=%d fake_seqoff=%d "
             "wssize=%d",
             profile->name, strategy_name,
             profile->proto == IPPROTO_TCP ? "tcp" :
             (profile->proto == IPPROTO_UDP ? "udp" : "any"),
             profile->port_count, profile->l7_mask, profile->split_pos,
             profile->seqovl, profile->segments, profile->split_sni_mode,
             profile->split_reverse, profile->split_all,
             profile->split_extra_one, profile->desync_data_packets,
             profile->fake_count, profile->session_freeze_after,
             profile->replace_original,
             profile->fake_ttl, profile->fake_bad_checksum,
             profile->fake_md5sig, profile->fake_seq_offset,
             profile->wssize);
    return 1;
}

static int compile_profiles(rv_engine *engine, const rv_config *cfg,
                            rv_compiled_profile **out, size_t *out_count)
{
    rv_compiled_profile *profiles;
    size_t capacity;
    size_t i;
    size_t count = 0;

    capacity = cfg->profile_count > 0 ? cfg->profile_count : 1;
    profiles = calloc(capacity, sizeof(*profiles));
    if (profiles == NULL) {
        return -1;
    }
    for (i = 0; i < cfg->profile_count; i++) {
        int rc = compile_one_profile(engine, cfg, &cfg->profiles[i],
                                     &profiles[count]);
        if (rc < 0) {
            free_profile_payloads(profiles, count + 1);
            free(profiles);
            return -1;
        }
        if (rc > 0) {
            count++;
        }
    }
    if (count == 0) {
        LOG_WARN("no enabled strategy profiles; only packet logging and "
                 "loop suppression are active");
    }
    *out = profiles;
    *out_count = count;
    return 0;
}

static rv_engine *engine_create_common(const rv_config *cfg,
                                       const char *ifname,
                                       const char *base_dir,
                                       int open_sender,
                                       char *err, size_t errlen)
{
    rv_engine *engine;
    rv_compiled_profile *profiles = NULL;
    size_t profile_count = 0;
    size_t i;

    if (err != NULL && errlen > 0) {
        err[0] = '\0';
    }
    if (cfg == NULL || (open_sender && ifname == NULL)) {
        (void)snprintf(err, errlen, "invalid engine arguments");
        return NULL;
    }

    engine = calloc(1, sizeof(*engine));
    if (engine == NULL) {
        (void)snprintf(err, errlen, "out of memory");
        return NULL;
    }
    engine->cfg = cfg;
    engine->capture_mode = cfg->global.capture_mode;
    engine->redirect_original =
        cfg->global.capture_mode == RV_CAPTURE_REDIRECT;
    rv_strlcpy(engine->base_dir, sizeof(engine->base_dir),
               base_dir != NULL ? base_dir : "");

    if (compile_profiles(engine, cfg, &profiles, &profile_count) < 0) {
        (void)snprintf(err, errlen, "cannot compile strategy profiles");
        rv_engine_destroy(engine);
        return NULL;
    }
    engine->profiles = profiles;
    engine->profile_count = profile_count;

    if (open_sender) {
        engine->sender = rv_sender_create(ifname, err, errlen);
        if (engine->sender == NULL) {
            rv_engine_destroy(engine);
            return NULL;
        }
    }
    engine->tracker = rv_tracker_create(cfg->tracking.max_entries,
                                        cfg->tracking.tcp_timeout,
                                        cfg->tracking.udp_timeout);
    if (engine->tracker == NULL) {
        (void)snprintf(err, errlen, "cannot create connection tracker");
        rv_engine_destroy(engine);
        return NULL;
    }

    for (i = 0; i < RV_MAX_TX_BATCH; i++) {
        engine->tx_bufs[i] = malloc(RV_MAX_FRAME);
        if (engine->tx_bufs[i] == NULL) {
            (void)snprintf(err, errlen, "out of memory");
            rv_engine_destroy(engine);
            return NULL;
        }
    }

    LOG_INFO("strategies: %zu profile(s), %zu TX buffers, tracker "
             "max_entries=%d%s", profile_count, (size_t)RV_MAX_TX_BATCH,
             cfg->tracking.max_entries, open_sender ? "" : " (offline)");
    return engine;
}

rv_engine *rv_engine_create(const rv_config *cfg, const char *ifname,
                            const char *base_dir, char *err, size_t errlen)
{
    return engine_create_common(cfg, ifname, base_dir, 1, err, errlen);
}

rv_engine *rv_engine_create_offline(const rv_config *cfg,
                                    const char *base_dir,
                                    char *err, size_t errlen)
{
    return engine_create_common(cfg, NULL, base_dir, 0, err, errlen);
}

int rv_engine_reload(rv_engine *engine, const rv_config *cfg,
                     char *err, size_t errlen)
{
    rv_compiled_profile *profiles = NULL;
    size_t profile_count = 0;

    if (engine == NULL || cfg == NULL) {
        (void)snprintf(err, errlen, "invalid engine reload arguments");
        return -1;
    }
    if (compile_profiles(engine, cfg, &profiles, &profile_count) < 0) {
        (void)snprintf(err, errlen, "cannot compile strategy profiles");
        return -1;
    }

    free_profile_payloads(engine->profiles, engine->profile_count);
    free(engine->profiles);
    engine->profiles = profiles;
    engine->profile_count = profile_count;
    engine->cfg = cfg;
    engine->capture_mode = cfg->global.capture_mode;
    engine->redirect_original =
        cfg->global.capture_mode == RV_CAPTURE_REDIRECT;
    rv_tracker_clear(engine->tracker);
    LOG_INFO("strategies: reloaded %zu profile(s)", profile_count);
    return 0;
}

void rv_engine_destroy(rv_engine *engine)
{
    size_t i;

    if (engine == NULL) {
        return;
    }
    free_profile_payloads(engine->profiles, engine->profile_count);
    free(engine->profiles);
    for (i = 0; i < RV_MAX_TX_BATCH; i++) {
        free(engine->tx_bufs[i]);
    }
    rv_tracker_destroy(engine->tracker);
    rv_sender_destroy(engine->sender);
    free(engine);
}

static int tx_add_tcp(rv_engine *engine, const uint8_t *orig,
                      size_t orig_len, const rv_packet *pkt,
                      uint32_t seq, uint32_t ack, uint8_t flags,
                      const uint8_t *payload, size_t payload_len,
                      uint8_t ttl_override)
{
    size_t frame_len;
    uint8_t *buf;

    if (engine->tx_count >= RV_MAX_TX_BATCH) {
        return -1;
    }
    buf = engine->tx_bufs[engine->tx_count];
    if (rv_build_tcp_frame(orig, orig_len, pkt, seq, ack, flags,
                           payload, payload_len, ttl_override,
                           buf, RV_MAX_FRAME, &frame_len) < 0) {
        return -1;
    }
    if (engine->tx_window != 0) {
        if (rv_tcp_set_window(buf, frame_len, pkt, engine->tx_window) < 0) {
            return -1;
        }
    }
    engine->tx_frames[engine->tx_count].data = buf;
    engine->tx_frames[engine->tx_count].len = frame_len;
    engine->tx_count++;
    return 0;
}

static int tx_add_udp(rv_engine *engine, const uint8_t *orig,
                      size_t orig_len, const rv_packet *pkt,
                      const uint8_t *payload, size_t payload_len,
                      uint8_t ttl_override)
{
    size_t frame_len;
    uint8_t *buf;

    if (engine->tx_count >= RV_MAX_TX_BATCH) {
        return -1;
    }
    buf = engine->tx_bufs[engine->tx_count];
    if (rv_build_udp_frame(orig, orig_len, pkt, payload, payload_len,
                           ttl_override, buf, RV_MAX_FRAME,
                           &frame_len) < 0) {
        return -1;
    }
    engine->tx_frames[engine->tx_count].data = buf;
    engine->tx_frames[engine->tx_count].len = frame_len;
    engine->tx_count++;
    return 0;
}

static int tx_add_frame(rv_engine *engine, const uint8_t *frame,
                        size_t frame_len)
{
    uint8_t *buf;

    if (engine->tx_count >= RV_MAX_TX_BATCH ||
        frame == NULL || frame_len > RV_MAX_FRAME) {
        return -1;
    }
    buf = engine->tx_bufs[engine->tx_count];
    memcpy(buf, frame, frame_len);
    engine->tx_frames[engine->tx_count].data = buf;
    engine->tx_frames[engine->tx_count].len = frame_len;
    engine->tx_count++;
    return 0;
}

/*
 * Re-emit an untouched captured frame in redirect mode.  The IPv4 ID / IPv6
 * flow label marker prevents the nftables egress hook from redirecting our
 * own frame back into the capture interface.
 */
static int tx_add_raw_marked(rv_engine *engine, const rv_packet *pkt,
                             const uint8_t *frame, size_t frame_len)
{
    uint8_t *buf;

    if (engine->tx_count >= RV_MAX_TX_BATCH ||
        frame_len > RV_MAX_FRAME || pkt == NULL) {
        return -1;
    }
    buf = engine->tx_bufs[engine->tx_count];
    memcpy(buf, frame, frame_len);
    if (pkt->family == AF_INET && pkt->l2_len + 6 <= frame_len) {
        buf[pkt->l2_len + 4] = (uint8_t)(RV_SENT_MARKER >> 8);
        buf[pkt->l2_len + 5] = (uint8_t)(RV_SENT_MARKER & 0xffu);
    } else if (pkt->family == AF_INET6 && pkt->l2_len + 4 <= frame_len) {
        uint32_t first;

        first = ((uint32_t)buf[pkt->l2_len] << 24) |
                ((uint32_t)buf[pkt->l2_len + 1] << 16) |
                ((uint32_t)buf[pkt->l2_len + 2] << 8) |
                (uint32_t)buf[pkt->l2_len + 3];
        first = (first & 0xFFF00000u) | RV_SENT_MARKER;
        buf[pkt->l2_len] = (uint8_t)(first >> 24);
        buf[pkt->l2_len + 1] = (uint8_t)(first >> 16);
        buf[pkt->l2_len + 2] = (uint8_t)(first >> 8);
        buf[pkt->l2_len + 3] = (uint8_t)(first & 0xffu);
    } else {
        return -1;
    }
    engine->tx_frames[engine->tx_count].data = buf;
    engine->tx_frames[engine->tx_count].len = frame_len;
    engine->tx_count++;
    engine->stats.passthrough_frames++;
    return 0;
}

static int tx_flush(rv_engine *engine)
{
    size_t count = engine->tx_count;
    int sent;

    if (count == 0) {
        return 0;
    }
    if (engine->sender == NULL) {
        engine->stats.injected_frames += (uint64_t)count;
        engine->tx_count = 0;
        return 0;
    }
    sent = rv_sender_send_batch(engine->sender, engine->tx_frames, count);
    if (sent < 0) {
        engine->stats.send_errors++;
        LOG_ERROR("strategy send failed: %s", strerror(errno));
        engine->tx_count = 0;
        return -1;
    }
    engine->stats.injected_frames += (uint64_t)sent;
    if ((size_t)sent < count) {
        engine->stats.send_errors++;
        LOG_WARN("strategy send: %d of %zu frames accepted", sent, count);
    }
    LOG_DEBUG("strategy send: %d/%zu frames", sent, count);
    engine->tx_count = 0;
    return (size_t)sent == count ? 0 : -1;
}

static int port_match(const rv_compiled_profile *profile, uint16_t port)
{
    size_t i;

    if (profile->port_count == 0) {
        return 1;
    }
    for (i = 0; i < profile->port_count; i++) {
        if (port >= profile->ports[i].lo && port <= profile->ports[i].hi) {
            return 1;
        }
    }
    return 0;
}

static int glob_match_ci(const char *pattern, const char *text)
{
    while (*pattern != '\0') {
        if (*pattern == '*') {
            while (*pattern == '*') {
                pattern++;
            }
            if (*pattern == '\0') {
                return 1;
            }
            while (*text != '\0') {
                if (glob_match_ci(pattern, text)) {
                    return 1;
                }
                text++;
            }
            return 0;
        }
        if (*pattern == '?') {
            if (*text == '\0') {
                return 0;
            }
            pattern++;
            text++;
            continue;
        }
        if (*text == '\0' ||
            tolower((unsigned char)*pattern) !=
                tolower((unsigned char)*text)) {
            return 0;
        }
        pattern++;
        text++;
    }
    return *text == '\0';
}

static int sni_token_matches(const char *token, const char *sni)
{
    size_t token_len;
    size_t sni_len;

    if (token == NULL || sni == NULL || *token == '\0' || *sni == '\0') {
        return 0;
    }
    if (strchr(token, '*') != NULL || strchr(token, '?') != NULL) {
        return glob_match_ci(token, sni);
    }
    token_len = strlen(token);
    sni_len = strlen(sni);
    if (token_len == sni_len && strcasecmp(token, sni) == 0) {
        return 1;
    }
    if (sni_len > token_len &&
        sni[sni_len - token_len - 1] == '.' &&
        strcasecmp(sni + sni_len - token_len, token) == 0) {
        return 1;
    }
    return 0;
}

static int sni_list_matches(const char *list, const char *sni)
{
    char buf[RV_MAX_FILTER_SNI];
    char *save = NULL;
    char *token;

    if (list == NULL || *list == '\0' || sni == NULL || *sni == '\0') {
        return 0;
    }
    rv_strlcpy(buf, sizeof(buf), list);
    for (token = strtok_r(buf, ",", &save); token != NULL;
         token = strtok_r(NULL, ",", &save)) {
        token = rv_trim(token);
        if (sni_token_matches(token, sni)) {
            return 1;
        }
    }
    return 0;
}

static int sni_patterns_match(const rv_compiled_profile *profile,
                              const char *sni)
{
    size_t i;

    if (profile->list_pattern_count == 0 || sni == NULL || *sni == '\0') {
        return 0;
    }
    for (i = 0; i < profile->list_pattern_count; i++) {
        if (sni_token_matches(profile->list_patterns[i], sni)) {
            return 1;
        }
    }
    return 0;
}

static int profile_matches(const rv_compiled_profile *profile,
                           const rv_packet *pkt, unsigned l7,
                           const char *sni)
{
    if (profile->proto != 0 && profile->proto != pkt->proto) {
        return 0;
    }
    if (!port_match(profile, pkt->dport)) {
        return 0;
    }
    if (profile->ip_range_count > 0 &&
        !ip_ranges_match(profile, pkt->family, pkt->dst)) {
        return 0;
    }
    if (profile->filter_sni[0] != '\0' || profile->list_pattern_count > 0) {
        int matched = 0;

        if (sni == NULL || *sni == '\0') {
            return 0;
        }
        if (profile->filter_sni[0] != '\0' &&
            sni_list_matches(profile->filter_sni, sni)) {
            matched = 1;
        }
        if (profile->list_pattern_count > 0 &&
            sni_patterns_match(profile, sni)) {
            matched = 1;
        }
        if (!matched) {
            return 0;
        }
    }
    if (profile->filter_sni_exclude[0] != '\0' && sni != NULL &&
        sni_list_matches(profile->filter_sni_exclude, sni)) {
        return 0;
    }
    if (!profile->l7_any) {
        if ((profile->l7_mask & RV_L7_QUIC_INITIAL) != 0) {
            if ((l7 & RV_L7_QUIC_INITIAL) == 0) {
                return 0;
            }
        } else if ((l7 & profile->l7_mask) == 0) {
            return 0;
        }
    }
    return 1;
}

static int profile_score(const rv_compiled_profile *profile,
                         const rv_packet *pkt, unsigned l7,
                         const char *sni)
{
    int score = profile->priority * 1000;

    if ((profile->filter_sni[0] != '\0' || profile->list_pattern_count > 0) &&
        sni != NULL && *sni != '\0') {
        score += 100;
    }
    if (profile->ip_range_count > 0 &&
        ip_ranges_match(profile, pkt->family, pkt->dst)) {
        score += 100;
    }
    if (!profile->l7_any && (l7 & profile->l7_mask) != 0) {
        score += 50;
    }
    if (profile->proto != 0) {
        score += 10;
    }
    if (profile->port_count > 0) {
        score += 5;
    }
    (void)pkt;
    return score;
}

static rv_compiled_profile *find_profile(rv_engine *engine,
                                         const rv_packet *pkt,
                                         const rv_tracker_view *view,
                                         unsigned l7, const char *sni)
{
    rv_compiled_profile *best = NULL;
    int best_score = 0;
    size_t i;

    if (view != NULL && view->profile_index >= 0 &&
        (size_t)view->profile_index < engine->profile_count) {
        rv_compiled_profile *locked =
            &engine->profiles[view->profile_index];
        if (profile_matches(locked, pkt, l7, sni)) {
            return locked;
        }
    }
    for (i = 0; i < engine->profile_count; i++) {
        rv_compiled_profile *profile = &engine->profiles[i];
        int score;

        if (!profile_matches(profile, pkt, l7, sni)) {
            continue;
        }
        score = profile_score(profile, pkt, l7, sni);
        if (best == NULL || score > best_score) {
            best = profile;
            best_score = score;
        }
    }
    return best;
}

static rv_compiled_profile *find_profile_by_name(rv_engine *engine,
                                                 const char *name)
{
    size_t i;

    if (name == NULL || *name == '\0') {
        return NULL;
    }
    for (i = 0; i < engine->profile_count; i++) {
        if (strcmp(engine->profiles[i].name, name) == 0) {
            return &engine->profiles[i];
        }
    }
    return NULL;
}

static size_t tcp_max_payload(rv_engine *engine, const rv_packet *pkt)
{
    unsigned int mtu = rv_sender_mtu(engine->sender);
    size_t overhead = pkt->l3_hdr_len + pkt->l4_hdr_len;

    if (mtu <= overhead + 1) {
        return 1;
    }
    return (size_t)mtu - overhead;
}

static int send_tcp_chunks(rv_engine *engine, const uint8_t *frame,
                           size_t frame_len, const rv_packet *pkt,
                           uint32_t seq, uint32_t ack, uint8_t flags,
                           const uint8_t *payload, size_t payload_len,
                           uint8_t ttl_override)
{
    size_t max_payload = tcp_max_payload(engine, pkt);
    size_t offset = 0;

    if (max_payload > 60000) {
        max_payload = 60000;
    }
    if (payload_len == 0) {
        return tx_add_tcp(engine, frame, frame_len, pkt, seq, ack, flags,
                          payload, 0, ttl_override);
    }

    while (offset < payload_len) {
        size_t chunk = payload_len - offset;
        uint8_t chunk_flags = flags;

        if (chunk > max_payload) {
            chunk = max_payload;
        }
        if (offset + chunk < payload_len) {
            chunk_flags &= (uint8_t)~0x08u; /* clear PSH */
        }
        if (tx_add_tcp(engine, frame, frame_len, pkt,
                       seq + (uint32_t)offset, ack, chunk_flags,
                       payload + offset, chunk, ttl_override) < 0) {
            return -1;
        }
        offset += chunk;
    }
    return 0;
}

static int send_original_tcp(rv_engine *engine, const uint8_t *frame,
                             size_t frame_len, const rv_packet *pkt)
{
    if (send_tcp_chunks(engine, frame, frame_len, pkt,
                        pkt->tcp_seq, pkt->tcp_ack, pkt->tcp_flags,
                        frame + pkt->payload_off, pkt->payload_len, 0) < 0) {
        return -1;
    }
    engine->stats.resent_frames++;
    return 0;
}

static int send_original_udp(rv_engine *engine, const uint8_t *frame,
                             size_t frame_len, const rv_packet *pkt)
{
    if (tx_add_udp(engine, frame, frame_len, pkt,
                   frame + pkt->payload_off, pkt->payload_len, 0) < 0) {
        return -1;
    }
    engine->stats.resent_frames++;
    return 0;
}

static int send_tcp_fakes(rv_engine *engine,
                          const rv_compiled_profile *profile,
                          const uint8_t *frame, size_t frame_len,
                          const rv_packet *pkt)
{
    uint8_t fake_copy[RV_MAX_FAKE_PAYLOAD];
    const uint8_t *payload = frame + pkt->payload_off;
    size_t max_payload = tcp_max_payload(engine, pkt);
    size_t fake_len = pkt->payload_len;
    uint32_t ack = pkt->tcp_ack + (uint32_t)profile->tcp_ack_offset;
    int i;

    /*
     * A fake packet must not carry the blocked SNI.  A configured
     * fake_payload file is used verbatim; otherwise rebuild the captured
     * ClientHello with fake_sni, changing all TLS length fields.  If this is
     * not possible we skip the fake instead of leaking the real SNI.
     */
    if (profile->fake_payload_from_file && profile->fake_payload_len > 0) {
        fake_len = profile->fake_payload_len;
        if (fake_len > sizeof(fake_copy)) {
            fake_len = sizeof(fake_copy);
        }
        memcpy(fake_copy, profile->fake_payload, fake_len);
        payload = fake_copy;
    } else if (profile->fake_sni[0] != '\0') {
        int replaced;

        if (pkt->payload_len > sizeof(fake_copy)) {
            LOG_WARN("profile '%s': ClientHello too large for fake_sni, "
                     "fake skipped", profile->name);
            return 0;
        }
        replaced = rv_tls_replace_sni(payload, pkt->payload_len,
                                      profile->fake_sni,
                                      fake_copy, sizeof(fake_copy));
        if (replaced < 0) {
            LOG_WARN("profile '%s': cannot rebuild fake_sni '%s'; "
                     "fake skipped to avoid leaking the real SNI",
                     profile->name, profile->fake_sni);
            return 0;
        }
        fake_len = (size_t)replaced;
        payload = fake_copy;
    }

    if (fake_len > max_payload) {
        fake_len = max_payload;
    }
    if (profile->fake_md5sig && fake_len + 20 > max_payload) {
        fake_len = max_payload > 20 ? max_payload - 20 : 1;
    }
    for (i = 0; i < profile->fake_count; i++) {
        /*
         * Zapret puts every fake at the same sequence as the original and
         * applies --dpi-desync-fooling=badseq to shift it out of the real
         * TCP window.  Do not subtract (i+1): that is a different packet
         * shape and is much easier for DPI to reject as a retransmission.
         */
        uint32_t seq = pkt->tcp_seq + (uint32_t)profile->fake_seq_offset;
        size_t built_len = frame_len;

        if (tx_add_tcp(engine, frame, frame_len, pkt, seq, ack,
                       pkt->tcp_flags, payload,
                       fake_len, (uint8_t)profile->fake_ttl) < 0) {
            return -1;
        }
        if (engine->tx_count > 0) {
            uint8_t *buf = engine->tx_bufs[engine->tx_count - 1];
            size_t len = engine->tx_frames[engine->tx_count - 1].len;

            if (profile->fake_md5sig &&
                rv_tcp_add_md5_option(buf, &len, RV_MAX_FRAME, pkt) == 0) {
                engine->tx_frames[engine->tx_count - 1].len = len;
                built_len = len;
            }
            if (profile->fake_bad_checksum) {
                /* Keep the IP checksum valid, but make the TCP checksum
                 * invalid: the server discards this packet, while DPI
                 * commonly still parses the payload. */
                buf[pkt->l4_off + 16] = 0;
                buf[pkt->l4_off + 17] = 0;
            }
            (void)built_len;
        }
    }
    return 0;
}

static int send_udp_fakes(rv_engine *engine,
                          const rv_compiled_profile *profile,
                          const uint8_t *frame, size_t frame_len,
                          const rv_packet *pkt)
{
    uint8_t fake_copy[RV_MAX_UDP_FAKE_PAYLOAD];
    size_t fake_len = profile->fake_payload_len;
    int i;

    if (fake_len > RV_MAX_UDP_FAKE_PAYLOAD) {
        fake_len = RV_MAX_UDP_FAKE_PAYLOAD;
    }
    if (fake_len == 0) {
        return -1;
    }
    memcpy(fake_copy, profile->fake_payload, fake_len);
    for (i = 0; i < profile->fake_count; i++) {
        /* Make fake datagrams distinguishable for middleboxes that dedupe
         * identical UDP payloads. QUIC/STUN parsers tolerate the last byte
         * change; a custom payload remains valid for DPI purposes. */
        fake_copy[fake_len - 1] ^= (uint8_t)(0x40u + (unsigned)i);
        if (tx_add_udp(engine, frame, frame_len, pkt,
                       fake_copy, fake_len,
                       (uint8_t)profile->fake_ttl) < 0) {
            return -1;
        }
        if (profile->fake_bad_checksum && engine->tx_count > 0) {
            uint8_t *buf = engine->tx_bufs[engine->tx_count - 1];

            /* 0x0000 disables the UDP checksum for IPv4 and is invalid for
             * IPv6; 0xffff is invalid for both. */
            buf[pkt->l4_off + 6] = 0xff;
            buf[pkt->l4_off + 7] = 0xff;
        }
    }
    return 0;
}

static const char *strategy_name_of(rv_strategy_kind kind)
{
    switch (kind) {
    case RV_STRATEGY_MULTISPLIT:
        return "multisplit";
    case RV_STRATEGY_FAKE:
        return "fake";
    case RV_STRATEGY_FAKEDSPLIT:
        return "fakedsplit";
    case RV_STRATEGY_FAKE_SESSION:
        return "fake_session";
    case RV_STRATEGY_FAKE_QUIC_INITIAL:
        return "fake_quic_initial";
    case RV_STRATEGY_QUIC_BLOCK:
        return "quic_block";
    case RV_STRATEGY_QUIC_FRAGMENT:
        return "quic_fragment";
    case RV_STRATEGY_NONE:
        return "none";
    default:
        return "none";
    }
}

static void format_ip(int family, const uint8_t *addr,
                      char *buf, size_t buflen)
{
    if (inet_ntop(family, addr, buf, (socklen_t)buflen) == NULL) {
        rv_strlcpy(buf, buflen, "?");
    }
}

static int send_tcp_splits(rv_engine *engine,
                           const rv_compiled_profile *profile,
                           size_t split_pos,
                           const uint8_t *frame, size_t frame_len,
                           const rv_packet *pkt)
{
    size_t boundaries[RV_MAX_SEGMENTS + 1];
    size_t payload_len = pkt->payload_len;
    size_t segments = (size_t)profile->segments;
    size_t i;
    size_t step;

    if (payload_len < 2 || split_pos == 0 || split_pos >= payload_len) {
        return -1;
    }

    boundaries[0] = 0;

    if (profile->split_extra_one && segments == 2 && split_pos > 1) {
        /*
         * Zapret-style multidisorder: split at byte 1 and at the middle of
         * the SNI, then emit the three parts in reverse order:
         *   3 (tail), 2 (SNI tail), 1 (first byte).
         */
        segments = 3;
        boundaries[1] = 1;
        boundaries[2] = split_pos;
        boundaries[3] = payload_len;
    } else {
        boundaries[1] = split_pos;
        if (segments > 2) {
            for (i = 2; i < segments; i++) {
                size_t offset = ((payload_len - split_pos) * (i - 1)) /
                                (segments - 1);
                boundaries[i] = split_pos + offset;
                if (boundaries[i] <= boundaries[i - 1] ||
                    boundaries[i] >= payload_len) {
                    return -1;
                }
            }
        }
        boundaries[segments] = payload_len;
    }

    for (step = 0; step < segments; step++) {
        size_t start;
        size_t end;
        uint8_t flags = pkt->tcp_flags;

        /*
         * Normal order is 0,1,...; reverse order sends the tail before the
         * head.  A receiver's TCP stack reassembles both; a stateless DPI
         * that only inspects the first segment sees a non-TLS-looking tail
         * first and may skip the flow.
         */
        i = profile->split_reverse ? (segments - 1 - step) : step;
        start = boundaries[i];
        end = boundaries[i + 1];

        if (segments == 2 && i == 1 && profile->seqovl > 0) {
            size_t overlap = (size_t)profile->seqovl;
            start = overlap < split_pos ? split_pos - overlap : 0;
        }
        if (i + 1 < segments) {
            flags &= (uint8_t)~0x08u; /* clear PSH */
        }
        if (send_tcp_chunks(engine, frame, frame_len, pkt,
                            pkt->tcp_seq + (uint32_t)start,
                            pkt->tcp_ack, flags,
                            frame + pkt->payload_off + start,
                            end - start, 0) < 0) {
            return -1;
        }
    }
    return 0;
}

static int apply_tcp_strategy(rv_engine *engine, rv_compiled_profile *profile,
                              const rv_flow_key *key, rv_tracker_view *view,
                              const uint8_t *frame, size_t frame_len,
                              const rv_packet *pkt, int allow_fallback)
{
    const uint8_t *payload = frame + pkt->payload_off;
    rv_tls_info tls;
    int tls_rc;
    int is_tls;
    int target;
    int action = 0;
    size_t split_pos = (size_t)profile->split_pos;

    engine->tx_window = (uint16_t)profile->wssize;
    memset(&tls, 0, sizeof(tls));
    tls_rc = rv_tls_parse_client_hello(payload, pkt->payload_len, &tls);
    is_tls = tls_rc == 1 || rv_l7_tls_clienthello_start(payload,
                                                        pkt->payload_len);
    target = is_tls && (profile->l7_any ||
                        (profile->l7_mask & RV_L7_TLS) != 0);

    /*
     * Split in the middle of the SNI host_name instead of the fixed byte
     * offset.  This keeps the complete domain out of both TCP segments,
     * which defeats DPI that only parses the first segment but does not
     * reassemble the stream.
     */
    if (target && profile->split_sni_mode != 0 && tls.has_sni &&
        tls.sni_len > 0 && tls.sni_offset < pkt->payload_len) {
        size_t candidate = tls.sni_offset;

        if (profile->split_sni_mode == 2) {
            candidate = tls.sni_offset + (tls.sni_len + 1) / 2;
        } else if (profile->split_sni_mode == 3) {
            candidate = tls.sni_offset + tls.sni_len;
        }
        if (candidate > 0 && candidate < pkt->payload_len) {
            split_pos = candidate;
            LOG_DEBUG("profile '%s': SNI-aware split mode=%d at %zu "
                      "(sni=%s offset=%zu len=%zu)",
                      profile->name, profile->split_sni_mode, split_pos,
                      tls.sni, tls.sni_offset, tls.sni_len);
        }
    }
    /*
     * A fixed split at byte 1 combined with reverse order sends almost the
     * entire ClientHello (including a complete SNI) first.  Move the split
     * past the fixed TLS header in that case.
     */
    if (target && tls.has_sni && profile->split_sni_mode == 0 &&
        profile->split_reverse && split_pos < 5 &&
        pkt->payload_len > 5) {
        split_pos = 5;
    }

    /*
     * A retransmitted ClientHello must be split again.  Previously we fell
     * through to send_original_tcp() for an already handled flow, which
     * leaked the complete SNI on every retransmit and made flaky CDN IPs
     * fail permanently once the first replacement was lost.
     */
    if (target && view->handled && profile->replace_original &&
        (profile->strategy == RV_STRATEGY_MULTISPLIT ||
         profile->strategy == RV_STRATEGY_FAKEDSPLIT)) {
        if (send_tcp_splits(engine, profile, split_pos,
                            frame, frame_len, pkt) == 0) {
            LOG_DEBUG("profile '%s': re-split retransmitted ClientHello "
                      "(sni=%s)", profile->name,
                      tls.has_sni ? tls.sni : "?");
            return 1;
        }
        engine->tx_count = 0;
    }

    if (target && !view->handled) {
        switch (profile->strategy) {
        case RV_STRATEGY_MULTISPLIT:
            if (profile->replace_original) {
                action = send_tcp_splits(engine, profile, split_pos,
                                         frame, frame_len,
                                         pkt) == 0 ? 1 : -1;
            }
            break;
        case RV_STRATEGY_FAKE:
            action = 0;
            if (profile->fake_before) {
                action = send_tcp_fakes(engine, profile, frame, frame_len,
                                        pkt) == 0 ? 1 : -1;
            }
            if (action >= 0 && profile->replace_original &&
                engine->redirect_original) {
                action = send_original_tcp(engine, frame, frame_len,
                                           pkt) == 0 ? 1 : -1;
            }
            if (action >= 0 && !profile->fake_before) {
                action = send_tcp_fakes(engine, profile, frame, frame_len,
                                        pkt) == 0 ? 1 : -1;
            }
            break;
        case RV_STRATEGY_NONE:
            action = 0;
            break;
        case RV_STRATEGY_FAKEDSPLIT:
            action = 0;
            if (profile->fake_before) {
                action = send_tcp_fakes(engine, profile, frame, frame_len,
                                        pkt) == 0 ? 1 : -1;
            }
            if (action >= 0 && profile->replace_original) {
                action = send_tcp_splits(engine, profile, split_pos,
                                         frame, frame_len,
                                         pkt) == 0 ? 1 : -1;
            }
            if (action >= 0 && !profile->fake_before) {
                action = send_tcp_fakes(engine, profile, frame, frame_len,
                                        pkt) == 0 ? 1 : -1;
            }
            break;
        default:
            action = -1;
            break;
        }

        if (action < 0 && allow_fallback && profile->fallback[0] != '\0') {
            rv_compiled_profile *fallback =
                find_profile_by_name(engine, profile->fallback);
            if (fallback != NULL) {
                LOG_WARN("profile '%s' failed, trying fallback '%s'",
                         profile->name, fallback->name);
                engine->tx_count = 0;
                action = apply_tcp_strategy(engine, fallback, key, view,
                                            frame, frame_len, pkt, 0);
                if (action > 0) {
                    rv_tracker_set_flags(engine->tracker, key, 1, 0);
                    engine->stats.strategy_packets++;
                    LOG_INFO("strategy fallback %s profile=%s",
                             strategy_name_of(fallback->strategy),
                             fallback->name);
                    return 1;
                }
                engine->tx_count = 0;
            }
        }
        if (action < 0) {
            LOG_WARN("profile '%s': strategy build failed, resending original",
                     profile->name);
            engine->tx_count = 0;
            action = 0;
        }

        if (action > 0) {
            char src[INET6_ADDRSTRLEN];
            char dst[INET6_ADDRSTRLEN];

            format_ip(pkt->family, pkt->src, src, sizeof(src));
            format_ip(pkt->family, pkt->dst, dst, sizeof(dst));
            rv_tracker_set_flags(engine->tracker, key, 1, 0);
            engine->stats.strategy_packets++;
            if (tls.has_sni) {
                LOG_INFO("strategy %s profile=%s %s:%u -> %s:%u sni=%s",
                         strategy_name_of(profile->strategy), profile->name,
                         src, (unsigned)pkt->sport, dst,
                         (unsigned)pkt->dport, tls.sni);
            } else {
                LOG_INFO("strategy %s profile=%s %s:%u -> %s:%u "
                         "(SNI unavailable)",
                         strategy_name_of(profile->strategy), profile->name,
                         src, (unsigned)pkt->sport, dst,
                         (unsigned)pkt->dport);
            }
            return 1;
        }
    }

    /*
     * Zapret's cutoff analogue: desync only the first N outgoing packets of
     * the flow.  Unlike split_all this does not split every HTTP/2 data
     * packet forever, so TCP/HTTP2 remain stable.
     */
    if (pkt->payload_len > 0 && profile->replace_original) {
        uint64_t data_index = view->data_packets;
        uint64_t bytes_before = view->payload_bytes -
                                (uint64_t)pkt->payload_len;
        int in_packet_window =
            profile->desync_data_packets == 0 ||
            data_index <= (uint64_t)profile->desync_data_packets;
        int in_byte_window =
            profile->desync_data_bytes == 0 ||
            bytes_before < (uint64_t)profile->desync_data_bytes;
        int after_start =
            bytes_before >= (uint64_t)profile->desync_data_start;

        if ((profile->desync_data_packets > 0 ||
             profile->desync_data_bytes > 0) &&
            in_packet_window && in_byte_window && after_start) {
            if (send_tcp_splits(engine, profile, split_pos,
                                frame, frame_len, pkt) == 0) {
                return 1;
            }
            engine->tx_count = 0;
        }
    }

    /*
     * Optional Zapret-style data desync: split every packet with TCP
     * payload, not only the first ClientHello.  This prevents DPI from
     * classifying the application-data phase by a complete TLS record.
     */
    if (profile->split_all && pkt->payload_len > 0 &&
        profile->replace_original) {
        if (send_tcp_splits(engine, profile, split_pos,
                            frame, frame_len, pkt) == 0) {
            return 1;
        }
        engine->tx_count = 0;
    }

    if (profile->replace_original && engine->redirect_original) {
        if (send_original_tcp(engine, frame, frame_len, pkt) < 0) {
            return -1;
        }
        return 1;
    }
    return 0;
}

static int send_udp_fragments(rv_engine *engine,
                              const rv_compiled_profile *profile,
                              const uint8_t *frame, size_t frame_len,
                              const rv_packet *pkt)
{
    uint8_t *full;
    uint8_t *frag;
    size_t full_len;
    size_t l4_len;
    size_t first_len;
    size_t second_len;
    size_t frag_len;
    uint32_t id;
    int order[2];
    int i;

    l4_len = pkt->l4_hdr_len + pkt->payload_len;
    if (l4_len < 16 || profile->frag_pos < 8 ||
        profile->frag_pos % 8 != 0 ||
        (size_t)profile->frag_pos >= l4_len) {
        return -1;
    }
    first_len = (size_t)profile->frag_pos;
    second_len = l4_len - first_len;
    full = malloc(RV_MAX_FRAME);
    frag = malloc(RV_MAX_FRAME);
    if (full == NULL || frag == NULL) {
        free(full);
        free(frag);
        return -1;
    }
    if (rv_build_udp_frame(frame, frame_len, pkt,
                           frame + pkt->payload_off, pkt->payload_len, 0,
                           full, RV_MAX_FRAME, &full_len) < 0) {
        free(full);
        free(frag);
        return -1;
    }

    id = RV_SENT_MARKER;
    order[0] = profile->frag_reverse ? 1 : 0;
    order[1] = profile->frag_reverse ? 0 : 1;
    for (i = 0; i < 2; i++) {
        int second = order[i];
        int more = second == 0;
        size_t frag_off = second ? first_len : 0;
        size_t frag_data = second ? second_len : first_len;

        if (rv_build_ip_fragment(full, full_len, pkt, frag_off, frag_data,
                                 more, id, frag, RV_MAX_FRAME,
                                 &frag_len) < 0) {
            free(full);
            free(frag);
            return -1;
        }
        if (tx_add_frame(engine, frag, frag_len) < 0) {
            free(full);
            free(frag);
            return -1;
        }
    }
    free(full);
    free(frag);
    engine->stats.fragmented_packets++;
    LOG_DEBUG("profile '%s': fragmented UDP payload at L4 offset %d "
              "(len=%zu)", profile->name, profile->frag_pos, l4_len);
    return 0;
}

static int apply_udp_strategy(rv_engine *engine, rv_compiled_profile *profile,
                              const rv_flow_key *key, rv_tracker_view *view,
                              const uint8_t *frame, size_t frame_len,
                              const rv_packet *pkt)
{
    const uint8_t *payload = frame + pkt->payload_off;
    unsigned detected = rv_l7_detect_udp(payload, pkt->payload_len);
    int target = profile->l7_any ||
                 (detected & profile->l7_mask) != 0;
    int within_session = 0;
    int sent_original = 0;
    int action = 0;

    if (target && profile->strategy == RV_STRATEGY_QUIC_BLOCK) {
        char dst[INET6_ADDRSTRLEN];

        format_ip(pkt->family, pkt->dst, dst, sizeof(dst));
        engine->stats.dropped_packets++;
        LOG_INFO("strategy quic_block profile=%s dst=%s:%u l7=0x%x "
                 "(forcing TCP fallback)", profile->name, dst,
                 (unsigned)pkt->dport, detected);
        return 1;
    }

    if (target && profile->strategy == RV_STRATEGY_QUIC_FRAGMENT) {
        if (send_udp_fragments(engine, profile, frame, frame_len, pkt) == 0) {
            char dst[INET6_ADDRSTRLEN];

            format_ip(pkt->family, pkt->dst, dst, sizeof(dst));
            engine->stats.strategy_packets++;
            LOG_INFO("strategy quic_fragment profile=%s dst=%s:%u l7=0x%x",
                     profile->name, dst, (unsigned)pkt->dport, detected);
            return 1;
        }
        LOG_WARN("profile '%s': QUIC fragmentation failed, resending "
                 "original datagram", profile->name);
        engine->tx_count = 0;
    }

    if (target && !view->frozen) {
        uint64_t freeze = (uint64_t)profile->session_freeze_after;

        within_session = freeze > 0 && view->packets_seen <= freeze;
        if (!within_session) {
            rv_tracker_set_flags(engine->tracker, key, 0, 1);
            view->frozen = 1;
        }
    }

    if (target && within_session &&
        (profile->strategy == RV_STRATEGY_FAKE_SESSION ||
         profile->strategy == RV_STRATEGY_FAKE_QUIC_INITIAL ||
         profile->strategy == RV_STRATEGY_FAKE)) {
        if (!profile->fake_before && profile->replace_original &&
            engine->redirect_original) {
            if (send_original_udp(engine, frame, frame_len, pkt) < 0) {
                action = -1;
            } else {
                sent_original = 1;
            }
        }
        if (action >= 0) {
            action = send_udp_fakes(engine, profile, frame, frame_len,
                                    pkt) == 0 ? 1 : -1;
        }
        if (action >= 0 && profile->fake_before &&
            profile->replace_original && !sent_original &&
            engine->redirect_original) {
            if (send_original_udp(engine, frame, frame_len, pkt) < 0) {
                action = -1;
            } else {
                sent_original = 1;
            }
        }
        if (action >= 0 && view->packets_seen >=
                          (uint64_t)profile->session_freeze_after) {
            rv_tracker_set_flags(engine->tracker, key, 0, 1);
            view->frozen = 1;
        }
        if (action > 0) {
            char src[INET6_ADDRSTRLEN];
            char dst[INET6_ADDRSTRLEN];

            format_ip(pkt->family, pkt->src, src, sizeof(src));
            format_ip(pkt->family, pkt->dst, dst, sizeof(dst));
            engine->stats.strategy_packets++;
            LOG_INFO("strategy %s profile=%s %s:%u -> %s:%u l7=0x%x "
                     "packet=%llu/%d",
                     strategy_name_of(profile->strategy), profile->name,
                     src, (unsigned)pkt->sport, dst,
                     (unsigned)pkt->dport, detected,
                     (unsigned long long)view->packets_seen,
                     profile->session_freeze_after);
        }
    }

    if (action < 0) {
        LOG_WARN("profile '%s': UDP fake build failed, resending original",
                 profile->name);
        engine->tx_count = 0;
        action = 0;
        sent_original = 0;
    }

    if (profile->replace_original && !sent_original &&
        engine->redirect_original) {
        if (send_original_udp(engine, frame, frame_len, pkt) < 0) {
            return -1;
        }
        sent_original = 1;
    }
    return (action > 0 || sent_original) ? 1 : 0;
}

static void fill_flow_key(rv_flow_key *key, const rv_packet *pkt)
{
    size_t alen = pkt->family == AF_INET ? 4u : 16u;

    memset(key, 0, sizeof(*key));
    key->family = pkt->family;
    key->proto = pkt->proto;
    memcpy(key->src, pkt->src, alen);
    memcpy(key->dst, pkt->dst, alen);
    key->sport = pkt->sport;
    key->dport = pkt->dport;
}

static int resend_original(rv_engine *engine, const uint8_t *frame,
                           size_t frame_len, const rv_packet *pkt)
{
    if (pkt->proto == IPPROTO_TCP) {
        return send_original_tcp(engine, frame, frame_len, pkt);
    }
    if (pkt->proto == IPPROTO_UDP) {
        return send_original_udp(engine, frame, frame_len, pkt);
    }
    return -1;
}

static int passthrough_unhandled(rv_engine *engine, const rv_packet *pkt,
                                 const uint8_t *frame, size_t frame_len)
{
    if (!engine->redirect_original) {
        return 0;
    }
    engine->tx_count = 0;
    if (tx_add_raw_marked(engine, pkt, frame, frame_len) < 0) {
        return 0;
    }
    (void)tx_flush(engine);
    return 1;
}

static unsigned detect_packet_l7(const rv_packet *pkt, const uint8_t *frame,
                                 char *sni, size_t snilen)
{
    unsigned l7 = 0;

    if (sni != NULL && snilen > 0) {
        sni[0] = '\0';
    }
    if (pkt->payload_len == 0) {
        return 0;
    }
    if (pkt->proto == IPPROTO_TCP) {
        rv_tls_info tls;
        const uint8_t *payload = frame + pkt->payload_off;
        int rc = rv_tls_parse_client_hello(payload, pkt->payload_len, &tls);

        if (rc == 1 || rv_l7_tls_clienthello_start(payload,
                                                   pkt->payload_len)) {
            l7 |= RV_L7_TLS;
        }
        if (rc == 1 && tls.has_sni && sni != NULL && snilen > 0) {
            rv_strlcpy(sni, snilen, tls.sni);
        }
    } else if (pkt->proto == IPPROTO_UDP) {
        l7 = rv_l7_detect_udp(frame + pkt->payload_off, pkt->payload_len);
    }
    return l7;
}

int rv_engine_handle(rv_engine *engine, const rv_packet *pkt,
                     const uint8_t *frame, size_t frame_len)
{
    rv_flow_key key;
    rv_tracker_view view;
    rv_compiled_profile *profile;
    unsigned l7;
    char sni[RV_TLS_SNI_MAX];
    int action;
    int track_rc;
    int result = 0;

    if (engine == NULL || pkt == NULL || frame == NULL) {
        return 0;
    }
    if (pkt->sent_by_us || pkt->family == 0) {
        return 0;
    }
    if (!pkt->has_ports) {
        return passthrough_unhandled(engine, pkt, frame, frame_len);
    }
    if (pkt->proto != IPPROTO_TCP && pkt->proto != IPPROTO_UDP) {
        return passthrough_unhandled(engine, pkt, frame, frame_len);
    }
    if (pkt->truncated || pkt->ip_fragmented) {
        engine->stats.skipped_truncated++;
        LOG_DEBUG("strategy: passing %s packet through "
                  "(truncated=%d fragmented=%d)",
                  pkt->proto == IPPROTO_TCP ? "TCP" : "UDP",
                  pkt->truncated, pkt->ip_fragmented);
        return passthrough_unhandled(engine, pkt, frame, frame_len);
    }

    fill_flow_key(&key, pkt);
    l7 = detect_packet_l7(pkt, frame, sni, sizeof(sni));
    track_rc = rv_tracker_touch_ex(engine->tracker, &key, time(NULL),
                                   pkt->payload_len, &view);
    if (track_rc >= 0) {
        if (l7 == 0) {
            l7 = view.l7;
        }
        if (sni[0] == '\0') {
            rv_strlcpy(sni, sizeof(sni), view.sni);
        }
    }

    profile = find_profile(engine, pkt, track_rc >= 0 ? &view : NULL,
                           l7, sni);
    if (profile == NULL) {
        LOG_DEBUG("strategy: no profile for %s dport=%u l7=0x%x sni=%s",
                  pkt->proto == IPPROTO_TCP ? "tcp" : "udp",
                  (unsigned)pkt->dport, l7, sni[0] != '\0' ? sni : "-");
        return passthrough_unhandled(engine, pkt, frame, frame_len);
    }
    engine->stats.matched_packets++;
    engine->tx_count = 0;
    rv_tracker_set_meta(engine->tracker, &key, l7, sni,
                        (int)(profile - engine->profiles));

    if (track_rc < 0) {
        LOG_WARN("connection tracker is full; resending original packet");
        if (profile->replace_original && engine->redirect_original &&
            resend_original(engine, frame, frame_len, pkt) == 0) {
            (void)tx_flush(engine);
            return 1;
        }
        return passthrough_unhandled(engine, pkt, frame, frame_len);
    }

    if (pkt->proto == IPPROTO_TCP) {
        action = apply_tcp_strategy(engine, profile, &key, &view,
                                    frame, frame_len, pkt, 1);
    } else {
        action = apply_udp_strategy(engine, profile, &key, &view,
                                    frame, frame_len, pkt);
    }

    if (action < 0) {
        LOG_ERROR("profile '%s': cannot build replacement, packet skipped",
                  profile->name);
        engine->tx_count = 0;
        return 0;
    }
    if (engine->tx_count > 0) {
        if (tx_flush(engine) < 0) {
            return 0;
        }
        result = 1;
    } else {
        result = action > 0 ? 1 : 0;
    }
    return result;
}

void rv_engine_expire(rv_engine *engine, time_t now)
{
    if (engine != NULL) {
        rv_tracker_expire(engine->tracker, now);
    }
}

void rv_engine_get_stats(rv_engine *engine, rv_engine_stats *out)
{
    if (out == NULL) {
        return;
    }
    if (engine == NULL) {
        memset(out, 0, sizeof(*out));
        return;
    }
    *out = engine->stats;
}

size_t rv_engine_tracker_count(rv_engine *engine)
{
    return engine != NULL ? rv_tracker_count(engine->tracker) : 0;
}
