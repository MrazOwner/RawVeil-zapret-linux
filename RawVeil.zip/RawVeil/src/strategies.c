#include "strategies.h"

#include "l7.h"
#include "log.h"
#include "netbuild.h"
#include "sender.h"
#include "tracker.h"
#include "tls_parser.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define RV_MAX_TX_BATCH 64
#define RV_MAX_FRAME (65535 + 128)
#define RV_MAX_UDP_FAKE_PAYLOAD 1200u
#define RV_MAX_PORT_RANGES 16
#define RV_MAX_FAKE_COUNT 16
#define RV_MAX_SEGMENTS 8
#define RV_MAX_FAKE_PAYLOAD 4096

typedef enum rv_strategy_kind {
    RV_STRATEGY_NONE = 0,
    RV_STRATEGY_MULTISPLIT,
    RV_STRATEGY_FAKE,
    RV_STRATEGY_FAKEDSPLIT,
    RV_STRATEGY_FAKE_SESSION,
    RV_STRATEGY_FAKE_QUIC_INITIAL
} rv_strategy_kind;

typedef struct rv_port_range {
    uint16_t lo;
    uint16_t hi;
} rv_port_range;

typedef struct rv_compiled_profile {
    char name[RV_MAX_NAME];
    int proto;                 /* 0 = any */
    rv_port_range ports[RV_MAX_PORT_RANGES];
    size_t port_count;
    unsigned l7_mask;          /* RV_L7_* */
    int l7_any;
    rv_strategy_kind strategy;
    int split_pos;
    int seqovl;
    int segments;
    int split_sni;
    int split_reverse;
    int split_all;
    int split_extra_one;
    int desync_data_packets;
    int fake_bad_checksum;
    int fake_md5sig;
    int fake_seq_offset;
    int wssize;
    int fake_count;
    int session_freeze_after;
    int fake_ttl;
    int tcp_ack_offset;
    int replace_original;
    int fake_before;
    char fallback[RV_MAX_NAME];
    char fake_sni[RV_TLS_SNI_MAX];

    uint8_t *fake_payload;
    size_t fake_payload_len;
    int fake_payload_from_file;
} rv_compiled_profile;

struct rv_engine {
    const rv_config *cfg;
    rv_sender *sender;
    rv_tracker *tracker;
    char base_dir[RV_MAX_PATH];

    rv_compiled_profile *profiles;
    size_t profile_count;

    uint8_t *tx_bufs[RV_MAX_TX_BATCH];
    rv_tx_frame tx_frames[RV_MAX_TX_BATCH];
    size_t tx_count;
    uint16_t tx_window;

    rv_engine_stats stats;
};

static const char *profile_str(const rv_config *cfg, const char *name,
                               const char *key, const char *def)
{
    const char *value = rv_config_profile_get(cfg, name, key);
    return value != NULL ? value : def;
}

static int profile_int_strict(const rv_config *cfg, const char *name,
                              const char *key, int def, int base,
                              long min, long max, int *out)
{
    const char *value = rv_config_profile_get(cfg, name, key);
    char *end = NULL;
    long parsed;

    if (value == NULL) {
        *out = def;
        return 0;
    }
    errno = 0;
    parsed = strtol(value, &end, base);
    if (errno != 0 || end == value || *end != '\0' ||
        parsed < min || parsed > max) {
        LOG_ERROR("profile '%s': invalid integer for '%s': '%s'",
                  name, key, value);
        return -1;
    }
    *out = (int)parsed;
    return 0;
}

static int profile_bool_strict(const rv_config *cfg, const char *name,
                               const char *key, int def, int *out)
{
    const char *value = rv_config_profile_get(cfg, name, key);

    if (value == NULL) {
        *out = def;
        return 0;
    }
    if (strcasecmp(value, "true") == 0 || strcasecmp(value, "yes") == 0 ||
        strcasecmp(value, "on") == 0 || strcmp(value, "1") == 0) {
        *out = 1;
        return 0;
    }
    if (strcasecmp(value, "false") == 0 || strcasecmp(value, "no") == 0 ||
        strcasecmp(value, "off") == 0 || strcmp(value, "0") == 0) {
        *out = 0;
        return 0;
    }
    LOG_ERROR("profile '%s': invalid boolean for '%s': '%s'",
              name, key, value);
    return -1;
}

static int parse_strategy_name(const char *name, rv_strategy_kind *out)
{
    if (name == NULL) {
        return -1;
    }
    if (strcasecmp(name, "multisplit") == 0) {
        *out = RV_STRATEGY_MULTISPLIT;
    } else if (strcasecmp(name, "fake") == 0) {
        *out = RV_STRATEGY_FAKE;
    } else if (strcasecmp(name, "fakedsplit") == 0) {
        *out = RV_STRATEGY_FAKEDSPLIT;
    } else if (strcasecmp(name, "fake_session") == 0) {
        *out = RV_STRATEGY_FAKE_SESSION;
    } else if (strcasecmp(name, "fake_quic_initial") == 0) {
        *out = RV_STRATEGY_FAKE_QUIC_INITIAL;
    } else {
        return -1;
    }
    return 0;
}

static int parse_proto_name(const char *name)
{
    if (name == NULL || *name == '\0' || strcasecmp(name, "any") == 0) {
        return 0;
    }
    if (strcasecmp(name, "tcp") == 0) {
        return IPPROTO_TCP;
    }
    if (strcasecmp(name, "udp") == 0) {
        return IPPROTO_UDP;
    }
    return -1;
}

static int parse_l7_mask(const char *text, unsigned *mask, int *is_any)
{
    char buf[RV_MAX_STR];
    char *save = NULL;
    char *token;
    unsigned result = 0;

    *mask = 0;
    *is_any = 1;
    if (text == NULL || *text == '\0') {
        return 0;
    }
    if (strlen(text) >= sizeof(buf)) {
        return -1;
    }
    rv_strlcpy(buf, sizeof(buf), text);
    *is_any = 0;

    for (token = strtok_r(buf, ",", &save); token != NULL;
         token = strtok_r(NULL, ",", &save)) {
        token = rv_trim(token);
        if (*token == '\0') {
            continue;
        }
        if (strcasecmp(token, "tls") == 0) {
            result |= RV_L7_TLS;
        } else if (strcasecmp(token, "quic") == 0) {
            result |= RV_L7_QUIC;
        } else if (strcasecmp(token, "stun") == 0) {
            result |= RV_L7_STUN;
        } else if (strcasecmp(token, "discord") == 0) {
            result |= RV_L7_RTP | RV_L7_STUN;
        } else {
            return -1;
        }
    }
    *mask = result;
    *is_any = result == 0;
    return 0;
}

static int parse_ports(const char *text, rv_compiled_profile *profile)
{
    char buf[RV_MAX_STR];
    char *cur;

    if (text == NULL || *text == '\0') {
        return 0;
    }
    if (strlen(text) >= sizeof(buf)) {
        return -1;
    }
    rv_strlcpy(buf, sizeof(buf), text);
    cur = buf;

    while (*cur != '\0') {
        unsigned long lo;
        unsigned long hi;
        char *end = NULL;

        while (*cur == ',' || isspace((unsigned char)*cur)) {
            cur++;
        }
        if (*cur == '\0') {
            break;
        }
        if (!isdigit((unsigned char)*cur)) {
            return -1;
        }
        errno = 0;
        lo = strtoul(cur, &end, 10);
        if (errno != 0 || end == cur || lo > 65535u) {
            return -1;
        }
        cur = end;
        while (isspace((unsigned char)*cur)) {
            cur++;
        }
        hi = lo;
        if (*cur == '-') {
            cur++;
            while (isspace((unsigned char)*cur)) {
                cur++;
            }
            if (!isdigit((unsigned char)*cur)) {
                return -1;
            }
            errno = 0;
            hi = strtoul(cur, &end, 10);
            if (errno != 0 || end == cur || hi > 65535u || hi < lo) {
                return -1;
            }
            cur = end;
        }
        while (isspace((unsigned char)*cur)) {
            cur++;
        }
        if (*cur != '\0' && *cur != ',') {
            return -1;
        }
        if (profile->port_count >= RV_MAX_PORT_RANGES) {
            return -1;
        }
        profile->ports[profile->port_count].lo = (uint16_t)lo;
        profile->ports[profile->port_count].hi = (uint16_t)hi;
        profile->port_count++;
        if (*cur == ',') {
            cur++;
        }
    }
    return 0;
}

static uint8_t pattern_byte(size_t i)
{
    return (uint8_t)(((i * 73u) + 41u) ^ ((i >> 3) * 19u));
}

static uint8_t *make_builtin_payload(const rv_compiled_profile *profile,
                                     size_t *out_len)
{
    uint8_t *data;
    size_t len;
    size_t i;

    if ((profile->l7_mask & RV_L7_QUIC) != 0) {
        len = 1200;
        data = malloc(len);
        if (data == NULL) {
            return NULL;
        }
        memset(data, 0, len);
        data[0] = 0xc0; /* long header + fixed bit */
        data[1] = 0x00;
        data[2] = 0x00;
        data[3] = 0x00;
        data[4] = 0x01; /* QUIC v1 */
        data[5] = 8;    /* DCID length */
        for (i = 0; i < 8; i++) {
            data[6 + i] = pattern_byte(i + 1);
        }
        data[14] = 0; /* SCID length */
        data[15] = 0; /* token length varint */
        data[16] = 0x40;
        data[17] = 0x64;
        for (i = 18; i < len; i++) {
            data[i] = pattern_byte(i);
        }
    } else if ((profile->l7_mask & RV_L7_STUN) != 0) {
        len = 20;
        data = calloc(1, len);
        if (data == NULL) {
            return NULL;
        }
        data[0] = 0x00;
        data[1] = 0x01; /* Binding request */
        data[2] = 0x00;
        data[3] = 0x00;
        data[4] = 0x21;
        data[5] = 0x12;
        data[6] = 0xa4;
        data[7] = 0x42;
        for (i = 8; i < 20; i++) {
            data[i] = pattern_byte(i);
        }
    } else if ((profile->l7_mask & RV_L7_RTP) != 0) {
        len = 44;
        data = calloc(1, len);
        if (data == NULL) {
            return NULL;
        }
        data[0] = 0x80; /* RTP v2 */
        data[1] = 0x60;
        data[2] = 0x00;
        data[3] = 0x01;
        for (i = 4; i < len; i++) {
            data[i] = pattern_byte(i);
        }
    } else {
        len = 64;
        data = malloc(len);
        if (data == NULL) {
            return NULL;
        }
        for (i = 0; i < len; i++) {
            data[i] = pattern_byte(i);
        }
    }
    *out_len = len;
    return data;
}

static void free_profile_payloads(rv_compiled_profile *profiles, size_t count)
{
    size_t i;

    for (i = 0; i < count; i++) {
        free(profiles[i].fake_payload);
        profiles[i].fake_payload = NULL;
        profiles[i].fake_payload_len = 0;
    }
}

static void load_fake_payload(rv_engine *engine, rv_compiled_profile *profile,
                              const char *configured_path)
{
    char path[RV_MAX_PATH];
    FILE *fp;
    uint8_t *data;
    size_t length;
    int n;

    if (configured_path == NULL || *configured_path == '\0') {
        profile->fake_payload = make_builtin_payload(profile, &length);
        profile->fake_payload_len = profile->fake_payload != NULL ? length : 0;
        return;
    }
    if (configured_path[0] == '/') {
        rv_strlcpy(path, sizeof(path), configured_path);
    } else if (engine->base_dir[0] != '\0') {
        n = snprintf(path, sizeof(path), "%s/%s",
                     engine->base_dir, configured_path);
        if (n < 0 || (size_t)n >= sizeof(path)) {
            LOG_WARN("profile '%s': fake_payload path is too long",
                     profile->name);
            path[0] = '\0';
        }
    } else {
        rv_strlcpy(path, sizeof(path), configured_path);
    }

    fp = path[0] != '\0' ? fopen(path, "rb") : NULL;
    if (fp == NULL) {
        LOG_DEBUG("profile '%s': fake_payload '%s' is unavailable, "
                  "using built-in payload", profile->name,
                  path[0] != '\0' ? path : configured_path);
        profile->fake_payload = make_builtin_payload(profile, &length);
        profile->fake_payload_len = profile->fake_payload != NULL ? length : 0;
        return;
    }

    data = malloc(RV_MAX_FAKE_PAYLOAD);
    if (data == NULL) {
        fclose(fp);
        profile->fake_payload = make_builtin_payload(profile, &length);
        profile->fake_payload_len = profile->fake_payload != NULL ? length : 0;
        return;
    }
    length = fread(data, 1, RV_MAX_FAKE_PAYLOAD, fp);
    if (ferror(fp)) {
        LOG_WARN("profile '%s': error reading fake_payload '%s'",
                 profile->name, path);
        free(data);
        data = NULL;
    }
    fclose(fp);
    if (data == NULL || length == 0) {
        free(data);
        profile->fake_payload = make_builtin_payload(profile, &length);
        profile->fake_payload_len = profile->fake_payload != NULL ? length : 0;
        return;
    }
    profile->fake_payload = data;
    profile->fake_payload_len = length;
    profile->fake_payload_from_file = 1;
    LOG_INFO("profile '%s': loaded %zu-byte fake payload from %s",
             profile->name, length, path);
}

static int compile_one_profile(rv_engine *engine, const rv_config *cfg,
                               const rv_profile *src,
                               rv_compiled_profile *profile)
{
    const char *strategy_name;
    const char *value;
    int proto;
    int enabled;

    memset(profile, 0, sizeof(*profile));
    if (profile_bool_strict(cfg, src->name, "enabled", 0, &enabled) < 0) {
        return -1;
    }
    if (!enabled) {
        return 0;
    }
    rv_strlcpy(profile->name, sizeof(profile->name), src->name);

    value = profile_str(cfg, src->name, "filter_proto", "any");
    proto = parse_proto_name(value);
    if (proto < 0) {
        LOG_ERROR("profile '%s': invalid filter_proto '%s'",
                  src->name, value);
        return -1;
    }
    profile->proto = proto;

    if (parse_ports(profile_str(cfg, src->name, "filter_ports", ""),
                    profile) < 0) {
        LOG_ERROR("profile '%s': invalid filter_ports", src->name);
        return -1;
    }
    if (parse_l7_mask(profile_str(cfg, src->name, "filter_l7", ""),
                      &profile->l7_mask, &profile->l7_any) < 0) {
        LOG_ERROR("profile '%s': invalid filter_l7", src->name);
        return -1;
    }

    strategy_name = profile_str(cfg, src->name, "strategy", "");
    if (*strategy_name == '\0' ||
        parse_strategy_name(strategy_name, &profile->strategy) < 0) {
        LOG_ERROR("profile '%s': invalid strategy '%s'",
                  src->name, strategy_name);
        return -1;
    }

    if (profile_int_strict(cfg, src->name, "split_pos", 1, 10,
                           0, 65535, &profile->split_pos) < 0 ||
        profile_int_strict(cfg, src->name, "seqovl", 0, 10,
                           0, 65535, &profile->seqovl) < 0 ||
        profile_int_strict(cfg, src->name, "segments", 2, 10,
                           2, RV_MAX_SEGMENTS, &profile->segments) < 0 ||
        profile_bool_strict(cfg, src->name, "split_sni", 0,
                            &profile->split_sni) < 0 ||
        profile_bool_strict(cfg, src->name, "split_reverse", 0,
                            &profile->split_reverse) < 0 ||
        profile_bool_strict(cfg, src->name, "split_all", 0,
                            &profile->split_all) < 0 ||
        profile_bool_strict(cfg, src->name, "split_extra_one", 0,
                            &profile->split_extra_one) < 0 ||
        profile_int_strict(cfg, src->name, "desync_data_packets", 0, 10,
                           0, 1000000,
                           &profile->desync_data_packets) < 0 ||
        profile_bool_strict(cfg, src->name, "fake_bad_checksum", 0,
                            &profile->fake_bad_checksum) < 0 ||
        profile_bool_strict(cfg, src->name, "fake_md5sig", 0,
                            &profile->fake_md5sig) < 0 ||
        profile_int_strict(cfg, src->name, "fake_seq_offset", 0, 0,
                           INT_MIN, INT_MAX,
                           &profile->fake_seq_offset) < 0 ||
        profile_int_strict(cfg, src->name, "wssize", 0, 0,
                           0, 65535, &profile->wssize) < 0 ||
        profile_int_strict(cfg, src->name, "fake_count", 1, 10,
                           1, RV_MAX_FAKE_COUNT,
                           &profile->fake_count) < 0 ||
        profile_int_strict(cfg, src->name, "session_freeze_after", 1, 10,
                           0, 1000000,
                           &profile->session_freeze_after) < 0 ||
        profile_int_strict(cfg, src->name, "fake_ttl", 1, 10,
                           0, 255, &profile->fake_ttl) < 0 ||
        profile_int_strict(cfg, src->name, "tcp_ack_offset", 0, 0,
                           INT_MIN, INT_MAX,
                           &profile->tcp_ack_offset) < 0 ||
        profile_bool_strict(cfg, src->name, "replace_original", 1,
                            &profile->replace_original) < 0 ||
        profile_bool_strict(cfg, src->name, "fake_before", 1,
                            &profile->fake_before) < 0) {
        return -1;
    }
    rv_strlcpy(profile->fallback, sizeof(profile->fallback),
               profile_str(cfg, src->name, "fallback", ""));
    rv_strlcpy(profile->fake_sni, sizeof(profile->fake_sni),
               profile_str(cfg, src->name, "fake_sni", ""));

    if (profile->split_pos < 0 || profile->split_pos > 65535 ||
        profile->seqovl < 0 || profile->seqovl > 65535) {
        LOG_ERROR("profile '%s': split_pos/seqovl out of range", src->name);
        return -1;
    }
    if (profile->segments < 2 || profile->segments > RV_MAX_SEGMENTS) {
        LOG_ERROR("profile '%s': segments must be in [2, %d]",
                  src->name, RV_MAX_SEGMENTS);
        return -1;
    }
    if (profile->fake_count < 1 ||
        profile->fake_count > RV_MAX_FAKE_COUNT) {
        LOG_ERROR("profile '%s': fake_count must be in [1, %d]",
                  src->name, RV_MAX_FAKE_COUNT);
        return -1;
    }
    if (profile->session_freeze_after < 0 ||
        profile->session_freeze_after > 1000000) {
        LOG_ERROR("profile '%s': session_freeze_after out of range",
                  src->name);
        return -1;
    }
    if (profile->fake_ttl < 0 || profile->fake_ttl > 255) {
        LOG_ERROR("profile '%s': fake_ttl must be in [0, 255]", src->name);
        return -1;
    }
    if ((profile->strategy == RV_STRATEGY_MULTISPLIT ||
         profile->strategy == RV_STRATEGY_FAKEDSPLIT) &&
        profile->proto != IPPROTO_TCP) {
        LOG_ERROR("profile '%s': %s requires filter_proto=tcp",
                  src->name, strategy_name);
        return -1;
    }
    if ((profile->strategy == RV_STRATEGY_FAKE_SESSION ||
         profile->strategy == RV_STRATEGY_FAKE_QUIC_INITIAL) &&
        profile->proto != IPPROTO_UDP) {
        LOG_ERROR("profile '%s': %s requires filter_proto=udp",
                  src->name, strategy_name);
        return -1;
    }

    load_fake_payload(engine, profile,
                      profile_str(cfg, src->name, "fake_payload", ""));
    if (profile->fake_payload == NULL || profile->fake_payload_len == 0) {
        LOG_ERROR("profile '%s': cannot create fake payload", src->name);
        return -1;
    }

    LOG_INFO("profile '%s': strategy=%s proto=%s ports=%zu l7=0x%x "
             "split=%d seqovl=%d segments=%d split_sni=%d "
             "split_reverse=%d split_all=%d split_extra_one=%d "
             "desync_data=%d fakes=%d freeze=%d replace_original=%d "
             "fake_ttl=%d fake_badsum=%d fake_md5sig=%d fake_seqoff=%d "
             "wssize=%d",
             profile->name, strategy_name,
             profile->proto == IPPROTO_TCP ? "tcp" :
             (profile->proto == IPPROTO_UDP ? "udp" : "any"),
             profile->port_count, profile->l7_mask, profile->split_pos,
             profile->seqovl, profile->segments, profile->split_sni,
             profile->split_reverse, profile->split_all,
             profile->split_extra_one, profile->desync_data_packets,
             profile->fake_count, profile->session_freeze_after,
             profile->replace_original,
             profile->fake_ttl, profile->fake_bad_checksum,
             profile->fake_md5sig, profile->fake_seq_offset,
             profile->wssize);
    return 1;
}

static int compile_profiles(rv_engine *engine, const rv_config *cfg,
                            rv_compiled_profile **out, size_t *out_count)
{
    rv_compiled_profile *profiles;
    size_t capacity;
    size_t i;
    size_t count = 0;

    capacity = cfg->profile_count > 0 ? cfg->profile_count : 1;
    profiles = calloc(capacity, sizeof(*profiles));
    if (profiles == NULL) {
        return -1;
    }
    for (i = 0; i < cfg->profile_count; i++) {
        int rc = compile_one_profile(engine, cfg, &cfg->profiles[i],
                                     &profiles[count]);
        if (rc < 0) {
            free_profile_payloads(profiles, count + 1);
            free(profiles);
            return -1;
        }
        if (rc > 0) {
            count++;
        }
    }
    if (count == 0) {
        LOG_WARN("no enabled strategy profiles; only packet logging and "
                 "loop suppression are active");
    }
    *out = profiles;
    *out_count = count;
    return 0;
}

static rv_engine *engine_create_common(const rv_config *cfg,
                                       const char *ifname,
                                       const char *base_dir,
                                       int open_sender,
                                       char *err, size_t errlen)
{
    rv_engine *engine;
    rv_compiled_profile *profiles = NULL;
    size_t profile_count = 0;
    size_t i;

    if (err != NULL && errlen > 0) {
        err[0] = '\0';
    }
    if (cfg == NULL || (open_sender && ifname == NULL)) {
        (void)snprintf(err, errlen, "invalid engine arguments");
        return NULL;
    }

    engine = calloc(1, sizeof(*engine));
    if (engine == NULL) {
        (void)snprintf(err, errlen, "out of memory");
        return NULL;
    }
    engine->cfg = cfg;
    rv_strlcpy(engine->base_dir, sizeof(engine->base_dir),
               base_dir != NULL ? base_dir : "");

    if (compile_profiles(engine, cfg, &profiles, &profile_count) < 0) {
        (void)snprintf(err, errlen, "cannot compile strategy profiles");
        rv_engine_destroy(engine);
        return NULL;
    }
    engine->profiles = profiles;
    engine->profile_count = profile_count;

    if (open_sender) {
        engine->sender = rv_sender_create(ifname, err, errlen);
        if (engine->sender == NULL) {
            rv_engine_destroy(engine);
            return NULL;
        }
    }
    engine->tracker = rv_tracker_create(cfg->tracking.max_entries,
                                        cfg->tracking.tcp_timeout,
                                        cfg->tracking.udp_timeout);
    if (engine->tracker == NULL) {
        (void)snprintf(err, errlen, "cannot create connection tracker");
        rv_engine_destroy(engine);
        return NULL;
    }

    for (i = 0; i < RV_MAX_TX_BATCH; i++) {
        engine->tx_bufs[i] = malloc(RV_MAX_FRAME);
        if (engine->tx_bufs[i] == NULL) {
            (void)snprintf(err, errlen, "out of memory");
            rv_engine_destroy(engine);
            return NULL;
        }
    }

    LOG_INFO("strategies: %zu profile(s), %zu TX buffers, tracker "
             "max_entries=%d%s", profile_count, (size_t)RV_MAX_TX_BATCH,
             cfg->tracking.max_entries, open_sender ? "" : " (offline)");
    return engine;
}

rv_engine *rv_engine_create(const rv_config *cfg, const char *ifname,
                            const char *base_dir, char *err, size_t errlen)
{
    return engine_create_common(cfg, ifname, base_dir, 1, err, errlen);
}

rv_engine *rv_engine_create_offline(const rv_config *cfg,
                                    const char *base_dir,
                                    char *err, size_t errlen)
{
    return engine_create_common(cfg, NULL, base_dir, 0, err, errlen);
}

int rv_engine_reload(rv_engine *engine, const rv_config *cfg,
                     char *err, size_t errlen)
{
    rv_compiled_profile *profiles = NULL;
    size_t profile_count = 0;

    if (engine == NULL || cfg == NULL) {
        (void)snprintf(err, errlen, "invalid engine reload arguments");
        return -1;
    }
    if (compile_profiles(engine, cfg, &profiles, &profile_count) < 0) {
        (void)snprintf(err, errlen, "cannot compile strategy profiles");
        return -1;
    }

    free_profile_payloads(engine->profiles, engine->profile_count);
    free(engine->profiles);
    engine->profiles = profiles;
    engine->profile_count = profile_count;
    engine->cfg = cfg;
    rv_tracker_clear(engine->tracker);
    LOG_INFO("strategies: reloaded %zu profile(s)", profile_count);
    return 0;
}

void rv_engine_destroy(rv_engine *engine)
{
    size_t i;

    if (engine == NULL) {
        return;
    }
    free_profile_payloads(engine->profiles, engine->profile_count);
    free(engine->profiles);
    for (i = 0; i < RV_MAX_TX_BATCH; i++) {
        free(engine->tx_bufs[i]);
    }
    rv_tracker_destroy(engine->tracker);
    rv_sender_destroy(engine->sender);
    free(engine);
}

static int tx_add_tcp(rv_engine *engine, const uint8_t *orig,
                      size_t orig_len, const rv_packet *pkt,
                      uint32_t seq, uint32_t ack, uint8_t flags,
                      const uint8_t *payload, size_t payload_len,
                      uint8_t ttl_override)
{
    size_t frame_len;
    uint8_t *buf;

    if (engine->tx_count >= RV_MAX_TX_BATCH) {
        return -1;
    }
    buf = engine->tx_bufs[engine->tx_count];
    if (rv_build_tcp_frame(orig, orig_len, pkt, seq, ack, flags,
                           payload, payload_len, ttl_override,
                           buf, RV_MAX_FRAME, &frame_len) < 0) {
        return -1;
    }
    if (engine->tx_window != 0) {
        if (rv_tcp_set_window(buf, frame_len, pkt, engine->tx_window) < 0) {
            return -1;
        }
    }
    engine->tx_frames[engine->tx_count].data = buf;
    engine->tx_frames[engine->tx_count].len = frame_len;
    engine->tx_count++;
    return 0;
}

static int tx_add_udp(rv_engine *engine, const uint8_t *orig,
                      size_t orig_len, const rv_packet *pkt,
                      const uint8_t *payload, size_t payload_len,
                      uint8_t ttl_override)
{
    size_t frame_len;
    uint8_t *buf;

    if (engine->tx_count >= RV_MAX_TX_BATCH) {
        return -1;
    }
    buf = engine->tx_bufs[engine->tx_count];
    if (rv_build_udp_frame(orig, orig_len, pkt, payload, payload_len,
                           ttl_override, buf, RV_MAX_FRAME,
                           &frame_len) < 0) {
        return -1;
    }
    engine->tx_frames[engine->tx_count].data = buf;
    engine->tx_frames[engine->tx_count].len = frame_len;
    engine->tx_count++;
    return 0;
}

static int tx_flush(rv_engine *engine)
{
    size_t count = engine->tx_count;
    int sent;

    if (count == 0) {
        return 0;
    }
    if (engine->sender == NULL) {
        engine->stats.injected_frames += (uint64_t)count;
        engine->tx_count = 0;
        return 0;
    }
    sent = rv_sender_send_batch(engine->sender, engine->tx_frames, count);
    if (sent < 0) {
        engine->stats.send_errors++;
        LOG_ERROR("strategy send failed: %s", strerror(errno));
        engine->tx_count = 0;
        return -1;
    }
    engine->stats.injected_frames += (uint64_t)sent;
    if ((size_t)sent < count) {
        engine->stats.send_errors++;
        LOG_WARN("strategy send: %d of %zu frames accepted", sent, count);
    }
    LOG_DEBUG("strategy send: %d/%zu frames", sent, count);
    engine->tx_count = 0;
    return (size_t)sent == count ? 0 : -1;
}

static int port_match(const rv_compiled_profile *profile, uint16_t port)
{
    size_t i;

    if (profile->port_count == 0) {
        return 1;
    }
    for (i = 0; i < profile->port_count; i++) {
        if (port >= profile->ports[i].lo && port <= profile->ports[i].hi) {
            return 1;
        }
    }
    return 0;
}

static rv_compiled_profile *find_profile(rv_engine *engine,
                                         const rv_packet *pkt)
{
    size_t i;

    for (i = 0; i < engine->profile_count; i++) {
        rv_compiled_profile *profile = &engine->profiles[i];
        if (profile->proto != 0 && profile->proto != pkt->proto) {
            continue;
        }
        if (port_match(profile, pkt->dport)) {
            return profile;
        }
    }
    return NULL;
}

static rv_compiled_profile *find_profile_by_name(rv_engine *engine,
                                                 const char *name)
{
    size_t i;

    if (name == NULL || *name == '\0') {
        return NULL;
    }
    for (i = 0; i < engine->profile_count; i++) {
        if (strcmp(engine->profiles[i].name, name) == 0) {
            return &engine->profiles[i];
        }
    }
    return NULL;
}

static size_t tcp_max_payload(rv_engine *engine, const rv_packet *pkt)
{
    unsigned int mtu = rv_sender_mtu(engine->sender);
    size_t overhead = pkt->l3_hdr_len + pkt->l4_hdr_len;

    if (mtu <= overhead + 1) {
        return 1;
    }
    return (size_t)mtu - overhead;
}

static int send_tcp_chunks(rv_engine *engine, const uint8_t *frame,
                           size_t frame_len, const rv_packet *pkt,
                           uint32_t seq, uint32_t ack, uint8_t flags,
                           const uint8_t *payload, size_t payload_len,
                           uint8_t ttl_override)
{
    size_t max_payload = tcp_max_payload(engine, pkt);
    size_t offset = 0;

    if (max_payload > 60000) {
        max_payload = 60000;
    }
    if (payload_len == 0) {
        return tx_add_tcp(engine, frame, frame_len, pkt, seq, ack, flags,
                          payload, 0, ttl_override);
    }

    while (offset < payload_len) {
        size_t chunk = payload_len - offset;
        uint8_t chunk_flags = flags;

        if (chunk > max_payload) {
            chunk = max_payload;
        }
        if (offset + chunk < payload_len) {
            chunk_flags &= (uint8_t)~0x08u; /* clear PSH */
        }
        if (tx_add_tcp(engine, frame, frame_len, pkt,
                       seq + (uint32_t)offset, ack, chunk_flags,
                       payload + offset, chunk, ttl_override) < 0) {
            return -1;
        }
        offset += chunk;
    }
    return 0;
}

static int send_original_tcp(rv_engine *engine, const uint8_t *frame,
                             size_t frame_len, const rv_packet *pkt)
{
    if (send_tcp_chunks(engine, frame, frame_len, pkt,
                        pkt->tcp_seq, pkt->tcp_ack, pkt->tcp_flags,
                        frame + pkt->payload_off, pkt->payload_len, 0) < 0) {
        return -1;
    }
    engine->stats.resent_frames++;
    return 0;
}

static int send_original_udp(rv_engine *engine, const uint8_t *frame,
                             size_t frame_len, const rv_packet *pkt)
{
    if (tx_add_udp(engine, frame, frame_len, pkt,
                   frame + pkt->payload_off, pkt->payload_len, 0) < 0) {
        return -1;
    }
    engine->stats.resent_frames++;
    return 0;
}

static int send_tcp_fakes(rv_engine *engine,
                          const rv_compiled_profile *profile,
                          const uint8_t *frame, size_t frame_len,
                          const rv_packet *pkt)
{
    uint8_t fake_copy[RV_MAX_FAKE_PAYLOAD];
    const uint8_t *payload = frame + pkt->payload_off;
    size_t max_payload = tcp_max_payload(engine, pkt);
    size_t fake_len = pkt->payload_len;
    uint32_t ack = pkt->tcp_ack + (uint32_t)profile->tcp_ack_offset;
    int i;

    /*
     * A fake packet must not carry the blocked SNI.  If fake_sni is
     * configured and has the same length as the real host_name, replace the
     * SNI bytes in the fake copy.  The real split segments still carry the
     * original ClientHello and are handled separately.
     */
    if (profile->fake_sni[0] != '\0' &&
        pkt->payload_len <= sizeof(fake_copy)) {
        rv_tls_info tls;
        size_t fake_sni_len = strlen(profile->fake_sni);

        if (rv_tls_parse_client_hello(payload, pkt->payload_len, &tls) == 1 &&
            tls.has_sni && tls.sni_len == fake_sni_len &&
            tls.sni_offset + tls.sni_len <= pkt->payload_len) {
            memcpy(fake_copy, payload, pkt->payload_len);
            memcpy(fake_copy + tls.sni_offset, profile->fake_sni,
                   fake_sni_len);
            payload = fake_copy;
        } else {
            LOG_DEBUG("profile '%s': fake_sni '%s' does not match "
                      "ClientHello SNI length; fake keeps original SNI",
                      profile->name, profile->fake_sni);
        }
    }

    if (fake_len > max_payload) {
        fake_len = max_payload;
    }
    if (profile->fake_md5sig && fake_len + 20 > max_payload) {
        fake_len = max_payload > 20 ? max_payload - 20 : 1;
    }
    for (i = 0; i < profile->fake_count; i++) {
        /*
         * Zapret puts every fake at the same sequence as the original and
         * applies --dpi-desync-fooling=badseq to shift it out of the real
         * TCP window.  Do not subtract (i+1): that is a different packet
         * shape and is much easier for DPI to reject as a retransmission.
         */
        uint32_t seq = pkt->tcp_seq + (uint32_t)profile->fake_seq_offset;
        size_t built_len = frame_len;

        if (tx_add_tcp(engine, frame, frame_len, pkt, seq, ack,
                       pkt->tcp_flags, payload,
                       fake_len, (uint8_t)profile->fake_ttl) < 0) {
            return -1;
        }
        if (engine->tx_count > 0) {
            uint8_t *buf = engine->tx_bufs[engine->tx_count - 1];
            size_t len = engine->tx_frames[engine->tx_count - 1].len;

            if (profile->fake_md5sig &&
                rv_tcp_add_md5_option(buf, &len, RV_MAX_FRAME, pkt) == 0) {
                engine->tx_frames[engine->tx_count - 1].len = len;
                built_len = len;
            }
            if (profile->fake_bad_checksum) {
                /* Keep the IP checksum valid, but make the TCP checksum
                 * invalid: the server discards this packet, while DPI
                 * commonly still parses the payload. */
                buf[pkt->l4_off + 16] = 0;
                buf[pkt->l4_off + 17] = 0;
            }
            (void)built_len;
        }
    }
    return 0;
}

static int send_udp_fakes(rv_engine *engine,
                          const rv_compiled_profile *profile,
                          const uint8_t *frame, size_t frame_len,
                          const rv_packet *pkt)
{
    uint8_t fake_copy[RV_MAX_UDP_FAKE_PAYLOAD];
    size_t fake_len = profile->fake_payload_len;
    int i;

    if (fake_len > RV_MAX_UDP_FAKE_PAYLOAD) {
        fake_len = RV_MAX_UDP_FAKE_PAYLOAD;
    }
    if (fake_len == 0) {
        return -1;
    }
    memcpy(fake_copy, profile->fake_payload, fake_len);
    for (i = 0; i < profile->fake_count; i++) {
        /* Make fake datagrams distinguishable for middleboxes that dedupe
         * identical UDP payloads. QUIC/STUN parsers tolerate the last byte
         * change; a custom payload remains valid for DPI purposes. */
        fake_copy[fake_len - 1] ^= (uint8_t)(0x40u + (unsigned)i);
        if (tx_add_udp(engine, frame, frame_len, pkt,
                       fake_copy, fake_len,
                       (uint8_t)profile->fake_ttl) < 0) {
            return -1;
        }
    }
    return 0;
}

static const char *strategy_name_of(rv_strategy_kind kind)
{
    switch (kind) {
    case RV_STRATEGY_MULTISPLIT:
        return "multisplit";
    case RV_STRATEGY_FAKE:
        return "fake";
    case RV_STRATEGY_FAKEDSPLIT:
        return "fakedsplit";
    case RV_STRATEGY_FAKE_SESSION:
        return "fake_session";
    case RV_STRATEGY_FAKE_QUIC_INITIAL:
        return "fake_quic_initial";
    default:
        return "none";
    }
}

static void format_ip(int family, const uint8_t *addr,
                      char *buf, size_t buflen)
{
    if (inet_ntop(family, addr, buf, (socklen_t)buflen) == NULL) {
        rv_strlcpy(buf, buflen, "?");
    }
}

static int send_tcp_splits(rv_engine *engine,
                           const rv_compiled_profile *profile,
                           size_t split_pos,
                           const uint8_t *frame, size_t frame_len,
                           const rv_packet *pkt)
{
    size_t boundaries[RV_MAX_SEGMENTS + 1];
    size_t payload_len = pkt->payload_len;
    size_t segments = (size_t)profile->segments;
    size_t i;
    size_t step;

    if (payload_len < 2 || split_pos == 0 || split_pos >= payload_len) {
        return -1;
    }

    boundaries[0] = 0;

    if (profile->split_extra_one && segments == 2 && split_pos > 1) {
        /*
         * Zapret-style multidisorder: split at byte 1 and at the middle of
         * the SNI, then emit the three parts in reverse order:
         *   3 (tail), 2 (SNI tail), 1 (first byte).
         */
        segments = 3;
        boundaries[1] = 1;
        boundaries[2] = split_pos;
        boundaries[3] = payload_len;
    } else {
        boundaries[1] = split_pos;
        if (segments > 2) {
            for (i = 2; i < segments; i++) {
                size_t offset = ((payload_len - split_pos) * (i - 1)) /
                                (segments - 1);
                boundaries[i] = split_pos + offset;
                if (boundaries[i] <= boundaries[i - 1] ||
                    boundaries[i] >= payload_len) {
                    return -1;
                }
            }
        }
        boundaries[segments] = payload_len;
    }

    for (step = 0; step < segments; step++) {
        size_t start;
        size_t end;
        uint8_t flags = pkt->tcp_flags;

        /*
         * Normal order is 0,1,...; reverse order sends the tail before the
         * head.  A receiver's TCP stack reassembles both; a stateless DPI
         * that only inspects the first segment sees a non-TLS-looking tail
         * first and may skip the flow.
         */
        i = profile->split_reverse ? (segments - 1 - step) : step;
        start = boundaries[i];
        end = boundaries[i + 1];

        if (segments == 2 && i == 1 && profile->seqovl > 0) {
            size_t overlap = (size_t)profile->seqovl;
            start = overlap < split_pos ? split_pos - overlap : 0;
        }
        if (i + 1 < segments) {
            flags &= (uint8_t)~0x08u; /* clear PSH */
        }
        if (send_tcp_chunks(engine, frame, frame_len, pkt,
                            pkt->tcp_seq + (uint32_t)start,
                            pkt->tcp_ack, flags,
                            frame + pkt->payload_off + start,
                            end - start, 0) < 0) {
            return -1;
        }
    }
    return 0;
}

static int apply_tcp_strategy(rv_engine *engine, rv_compiled_profile *profile,
                              const rv_flow_key *key, rv_tracker_view *view,
                              const uint8_t *frame, size_t frame_len,
                              const rv_packet *pkt, int allow_fallback)
{
    const uint8_t *payload = frame + pkt->payload_off;
    rv_tls_info tls;
    int tls_rc;
    int is_tls;
    int target;
    int action = 0;
    size_t split_pos = (size_t)profile->split_pos;

    engine->tx_window = (uint16_t)profile->wssize;
    memset(&tls, 0, sizeof(tls));
    tls_rc = rv_tls_parse_client_hello(payload, pkt->payload_len, &tls);
    is_tls = tls_rc == 1 || rv_l7_tls_clienthello_start(payload,
                                                        pkt->payload_len);
    target = is_tls && (profile->l7_any ||
                        (profile->l7_mask & RV_L7_TLS) != 0);

    /*
     * Split in the middle of the SNI host_name instead of the fixed byte
     * offset.  This keeps the complete domain out of both TCP segments,
     * which defeats DPI that only parses the first segment but does not
     * reassemble the stream.
     */
    if (target && profile->split_sni && tls.has_sni && tls.sni_len > 0 &&
        tls.sni_offset < pkt->payload_len) {
        size_t candidate = tls.sni_offset + (tls.sni_len + 1) / 2;

        if (candidate > 0 && candidate < pkt->payload_len) {
            split_pos = candidate;
            LOG_DEBUG("profile '%s': SNI-aware split at %zu "
                      "(sni=%s offset=%zu len=%zu)",
                      profile->name, split_pos, tls.sni,
                      tls.sni_offset, tls.sni_len);
        }
    }

    /*
     * A retransmitted ClientHello must be split again.  Previously we fell
     * through to send_original_tcp() for an already handled flow, which
     * leaked the complete SNI on every retransmit and made flaky CDN IPs
     * fail permanently once the first replacement was lost.
     */
    if (target && view->handled && profile->replace_original &&
        (profile->strategy == RV_STRATEGY_MULTISPLIT ||
         profile->strategy == RV_STRATEGY_FAKEDSPLIT)) {
        if (send_tcp_splits(engine, profile, split_pos,
                            frame, frame_len, pkt) == 0) {
            LOG_DEBUG("profile '%s': re-split retransmitted ClientHello "
                      "(sni=%s)", profile->name,
                      tls.has_sni ? tls.sni : "?");
            return 1;
        }
        engine->tx_count = 0;
    }

    if (target && !view->handled) {
        switch (profile->strategy) {
        case RV_STRATEGY_MULTISPLIT:
            if (profile->replace_original) {
                action = send_tcp_splits(engine, profile, split_pos,
                                         frame, frame_len,
                                         pkt) == 0 ? 1 : -1;
            }
            break;
        case RV_STRATEGY_FAKE:
            action = 0;
            if (profile->fake_before) {
                action = send_tcp_fakes(engine, profile, frame, frame_len,
                                        pkt) == 0 ? 1 : -1;
            }
            if (action >= 0 && profile->replace_original) {
                action = send_original_tcp(engine, frame, frame_len,
                                           pkt) == 0 ? 1 : -1;
            }
            if (action >= 0 && !profile->fake_before) {
                action = send_tcp_fakes(engine, profile, frame, frame_len,
                                        pkt) == 0 ? 1 : -1;
            }
            break;
        case RV_STRATEGY_FAKEDSPLIT:
            action = 0;
            if (profile->fake_before) {
                action = send_tcp_fakes(engine, profile, frame, frame_len,
                                        pkt) == 0 ? 1 : -1;
            }
            if (action >= 0 && profile->replace_original) {
                action = send_tcp_splits(engine, profile, split_pos,
                                         frame, frame_len,
                                         pkt) == 0 ? 1 : -1;
            }
            if (action >= 0 && !profile->fake_before) {
                action = send_tcp_fakes(engine, profile, frame, frame_len,
                                        pkt) == 0 ? 1 : -1;
            }
            break;
        default:
            action = -1;
            break;
        }

        if (action < 0 && allow_fallback && profile->fallback[0] != '\0') {
            rv_compiled_profile *fallback =
                find_profile_by_name(engine, profile->fallback);
            if (fallback != NULL) {
                LOG_WARN("profile '%s' failed, trying fallback '%s'",
                         profile->name, fallback->name);
                engine->tx_count = 0;
                action = apply_tcp_strategy(engine, fallback, key, view,
                                            frame, frame_len, pkt, 0);
                if (action > 0) {
                    rv_tracker_set_flags(engine->tracker, key, 1, 0);
                    engine->stats.strategy_packets++;
                    LOG_INFO("strategy fallback %s profile=%s",
                             strategy_name_of(fallback->strategy),
                             fallback->name);
                    return 1;
                }
                engine->tx_count = 0;
            }
        }
        if (action < 0) {
            LOG_WARN("profile '%s': strategy build failed, resending original",
                     profile->name);
            engine->tx_count = 0;
            action = 0;
        }

        if (action > 0) {
            char src[INET6_ADDRSTRLEN];
            char dst[INET6_ADDRSTRLEN];

            format_ip(pkt->family, pkt->src, src, sizeof(src));
            format_ip(pkt->family, pkt->dst, dst, sizeof(dst));
            rv_tracker_set_flags(engine->tracker, key, 1, 0);
            engine->stats.strategy_packets++;
            if (tls.has_sni) {
                LOG_INFO("strategy %s profile=%s %s:%u -> %s:%u sni=%s",
                         strategy_name_of(profile->strategy), profile->name,
                         src, (unsigned)pkt->sport, dst,
                         (unsigned)pkt->dport, tls.sni);
            } else {
                LOG_INFO("strategy %s profile=%s %s:%u -> %s:%u "
                         "(SNI unavailable)",
                         strategy_name_of(profile->strategy), profile->name,
                         src, (unsigned)pkt->sport, dst,
                         (unsigned)pkt->dport);
            }
            return 1;
        }
    }

    /*
     * Zapret's cutoff analogue: desync only the first N outgoing packets of
     * the flow.  Unlike split_all this does not split every HTTP/2 data
     * packet forever, so TCP/HTTP2 remain stable.
     */
    if (profile->desync_data_packets > 0 && pkt->payload_len > 0 &&
        profile->replace_original &&
        view->packets_seen <= (uint64_t)profile->desync_data_packets) {
        if (send_tcp_splits(engine, profile, split_pos,
                            frame, frame_len, pkt) == 0) {
            return 1;
        }
        engine->tx_count = 0;
    }

    /*
     * Optional Zapret-style data desync: split every packet with TCP
     * payload, not only the first ClientHello.  This prevents DPI from
     * classifying the application-data phase by a complete TLS record.
     */
    if (profile->split_all && pkt->payload_len > 0 &&
        profile->replace_original) {
        if (send_tcp_splits(engine, profile, split_pos,
                            frame, frame_len, pkt) == 0) {
            return 1;
        }
        engine->tx_count = 0;
    }

    if (profile->replace_original) {
        if (send_original_tcp(engine, frame, frame_len, pkt) < 0) {
            return -1;
        }
        return 1;
    }
    return 0;
}

static int apply_udp_strategy(rv_engine *engine, rv_compiled_profile *profile,
                              const rv_flow_key *key, rv_tracker_view *view,
                              const uint8_t *frame, size_t frame_len,
                              const rv_packet *pkt)
{
    const uint8_t *payload = frame + pkt->payload_off;
    unsigned detected = rv_l7_detect_udp(payload, pkt->payload_len);
    int target = profile->l7_any ||
                 (detected & profile->l7_mask) != 0;
    int within_session = 0;
    int sent_original = 0;
    int action = 0;

    if (target && !view->frozen) {
        uint64_t freeze = (uint64_t)profile->session_freeze_after;

        within_session = freeze > 0 && view->packets_seen <= freeze;
        if (!within_session) {
            rv_tracker_set_flags(engine->tracker, key, 0, 1);
            view->frozen = 1;
        }
    }

    if (target && within_session &&
        (profile->strategy == RV_STRATEGY_FAKE_SESSION ||
         profile->strategy == RV_STRATEGY_FAKE_QUIC_INITIAL ||
         profile->strategy == RV_STRATEGY_FAKE)) {
        if (!profile->fake_before && profile->replace_original) {
            if (send_original_udp(engine, frame, frame_len, pkt) < 0) {
                action = -1;
            } else {
                sent_original = 1;
            }
        }
        if (action >= 0) {
            action = send_udp_fakes(engine, profile, frame, frame_len,
                                    pkt) == 0 ? 1 : -1;
        }
        if (action >= 0 && profile->fake_before &&
            profile->replace_original && !sent_original) {
            if (send_original_udp(engine, frame, frame_len, pkt) < 0) {
                action = -1;
            } else {
                sent_original = 1;
            }
        }
        if (action >= 0 && view->packets_seen >=
                          (uint64_t)profile->session_freeze_after) {
            rv_tracker_set_flags(engine->tracker, key, 0, 1);
            view->frozen = 1;
        }
        if (action > 0) {
            char src[INET6_ADDRSTRLEN];
            char dst[INET6_ADDRSTRLEN];

            format_ip(pkt->family, pkt->src, src, sizeof(src));
            format_ip(pkt->family, pkt->dst, dst, sizeof(dst));
            engine->stats.strategy_packets++;
            LOG_INFO("strategy %s profile=%s %s:%u -> %s:%u l7=0x%x "
                     "packet=%llu/%d",
                     strategy_name_of(profile->strategy), profile->name,
                     src, (unsigned)pkt->sport, dst,
                     (unsigned)pkt->dport, detected,
                     (unsigned long long)view->packets_seen,
                     profile->session_freeze_after);
        }
    }

    if (action < 0) {
        LOG_WARN("profile '%s': UDP fake build failed, resending original",
                 profile->name);
        engine->tx_count = 0;
        action = 0;
        sent_original = 0;
    }

    if (profile->replace_original && !sent_original) {
        if (send_original_udp(engine, frame, frame_len, pkt) < 0) {
            return -1;
        }
        sent_original = 1;
    }
    return (action > 0 || sent_original) ? 1 : 0;
}

static void fill_flow_key(rv_flow_key *key, const rv_packet *pkt)
{
    size_t alen = pkt->family == AF_INET ? 4u : 16u;

    memset(key, 0, sizeof(*key));
    key->family = pkt->family;
    key->proto = pkt->proto;
    memcpy(key->src, pkt->src, alen);
    memcpy(key->dst, pkt->dst, alen);
    key->sport = pkt->sport;
    key->dport = pkt->dport;
}

static int resend_original(rv_engine *engine, const uint8_t *frame,
                           size_t frame_len, const rv_packet *pkt)
{
    if (pkt->proto == IPPROTO_TCP) {
        return send_original_tcp(engine, frame, frame_len, pkt);
    }
    if (pkt->proto == IPPROTO_UDP) {
        return send_original_udp(engine, frame, frame_len, pkt);
    }
    return -1;
}

int rv_engine_handle(rv_engine *engine, const rv_packet *pkt,
                     const uint8_t *frame, size_t frame_len)
{
    rv_flow_key key;
    rv_tracker_view view;
    rv_compiled_profile *profile;
    int action;
    int track_rc;
    int result = 0;

    if (engine == NULL || pkt == NULL || frame == NULL) {
        return 0;
    }
    if (pkt->sent_by_us || pkt->family == 0 || !pkt->has_ports) {
        return 0;
    }
    if (pkt->proto != IPPROTO_TCP && pkt->proto != IPPROTO_UDP) {
        return 0;
    }
    if (pkt->truncated || pkt->ip_fragmented) {
        engine->stats.skipped_truncated++;
        LOG_DEBUG("strategy: skipping %s packet (truncated=%d fragmented=%d)",
                  pkt->proto == IPPROTO_TCP ? "TCP" : "UDP",
                  pkt->truncated, pkt->ip_fragmented);
        return 0;
    }

    profile = find_profile(engine, pkt);
    if (profile == NULL) {
        return 0;
    }
    engine->stats.matched_packets++;
    engine->tx_count = 0;
    fill_flow_key(&key, pkt);

    track_rc = rv_tracker_touch(engine->tracker, &key, time(NULL), &view);
    if (track_rc < 0) {
        LOG_WARN("connection tracker is full; resending original packet");
        if (profile->replace_original &&
            resend_original(engine, frame, frame_len, pkt) == 0) {
            (void)tx_flush(engine);
            return 1;
        }
        return 0;
    }

    if (pkt->proto == IPPROTO_TCP) {
        action = apply_tcp_strategy(engine, profile, &key, &view,
                                    frame, frame_len, pkt, 1);
    } else {
        action = apply_udp_strategy(engine, profile, &key, &view,
                                    frame, frame_len, pkt);
    }

    if (action < 0) {
        LOG_ERROR("profile '%s': cannot build replacement, packet skipped",
                  profile->name);
        engine->tx_count = 0;
        return 0;
    }
    if (engine->tx_count > 0) {
        if (tx_flush(engine) < 0) {
            return 0;
        }
        result = 1;
    } else {
        result = action > 0 ? 1 : 0;
    }
    return result;
}

void rv_engine_expire(rv_engine *engine, time_t now)
{
    if (engine != NULL) {
        rv_tracker_expire(engine->tracker, now);
    }
}

void rv_engine_get_stats(rv_engine *engine, rv_engine_stats *out)
{
    if (out == NULL) {
        return;
    }
    if (engine == NULL) {
        memset(out, 0, sizeof(*out));
        return;
    }
    *out = engine->stats;
}

size_t rv_engine_tracker_count(rv_engine *engine)
{
    return engine != NULL ? rv_tracker_count(engine->tracker) : 0;
}
