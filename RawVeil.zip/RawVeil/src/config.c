#include "config.h"

#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>

#define RV_CONFIG_LINE_MAX 8192
#define RV_DEFAULT_PROFILE_CAP 16

static int config_profile_set(rv_config *cfg, const char *name,
                              const char *key, const char *value);
static rv_profile *config_profile_find(const rv_config *cfg, const char *name);

void rv_config_defaults(rv_config *cfg)
{
    if (cfg == NULL) {
        return;
    }
    memset(cfg, 0, sizeof(*cfg));

    rv_strlcpy(cfg->global.interface, sizeof(cfg->global.interface), "eth0");
    cfg->global.send_interface[0] = '\0';
    cfg->global.capture_mode = RV_CAPTURE_REDIRECT;
    cfg->global.capture_incoming = 0;
    cfg->global.threads = 4;
    cfg->global.buffer_size = 65535;
    cfg->global.log_level = RV_LOG_INFO;
    rv_strlcpy(cfg->global.pid_file, sizeof(cfg->global.pid_file),
               RV_DEFAULT_PID_FILE);
    rv_strlcpy(cfg->global.stats_file, sizeof(cfg->global.stats_file),
               RV_DEFAULT_STATS_FILE);

    cfg->tracking.tcp_timeout = 300;
    cfg->tracking.udp_timeout = 30;
    cfg->tracking.max_entries = 65536;

    cfg->doh.enabled = 1;
    rv_strlcpy(cfg->doh.mode, sizeof(cfg->doh.mode), "system");
    rv_strlcpy(cfg->doh.endpoint, sizeof(cfg->doh.endpoint),
               "https://cloudflare-dns.com/dns-query");
    rv_strlcpy(cfg->doh.format, sizeof(cfg->doh.format), "json");
    cfg->doh.cache_ttl = 300;
    cfg->doh.negative_ttl = 60;
    cfg->doh.fallback_to_system = 0;
    rv_strlcpy(cfg->doh.bootstrap_ips, sizeof(cfg->doh.bootstrap_ips),
               "1.1.1.1, 1.0.0.1");
    rv_strlcpy(cfg->doh.listen, sizeof(cfg->doh.listen),
               "127.0.0.1:5353");
    rv_strlcpy(cfg->doh.servers, sizeof(cfg->doh.servers),
               "1.1.1.1#cloudflare-dns.com,9.9.9.9#dns.quad9.net");
    cfg->doh.strict = 1;
    cfg->doh.block_plain = 1;
    cfg->doh.block_other_dot = 0;

    cfg->warp.enabled = 1;
    rv_strlcpy(cfg->warp.interface, sizeof(cfg->warp.interface), "awg0");
    rv_strlcpy(cfg->warp.domain_list, sizeof(cfg->warp.domain_list),
               "/etc/rawveil/warp_lists.txt");
    rv_strlcpy(cfg->warp.ip_list, sizeof(cfg->warp.ip_list),
               "/etc/rawveil/warp_ips.txt");
    cfg->warp.mark = 0x1u;
    cfg->warp.bypass_strategies = 1;
    cfg->warp.awg_config[0] = '\0';
    cfg->warp.manage_routing = 1;
    cfg->warp.routing_mode = RV_ROUTING_ROUTE;
    cfg->warp.routing_table = 51821;
    cfg->warp.routing_priority = 1000;

    rv_strlcpy(cfg->security.drop_privileges_to,
               sizeof(cfg->security.drop_privileges_to), RV_PROGRAM_NAME);
    rv_strlcpy(cfg->security.required_caps,
               sizeof(cfg->security.required_caps),
               "CAP_NET_RAW,CAP_NET_ADMIN");
}

void rv_config_free(rv_config *cfg)
{
    size_t i;
    size_t j;

    if (cfg == NULL) {
        return;
    }
    for (i = 0; i < cfg->profile_count; i++) {
        rv_profile *prof = &cfg->profiles[i];
        for (j = 0; j < prof->kv_count; j++) {
            free(prof->kv[j].key);
            free(prof->kv[j].value);
        }
        free(prof->kv);
    }
    free(cfg->profiles);
    cfg->profiles = NULL;
    cfg->profile_count = 0;
    cfg->profile_cap = 0;
}

static int set_string(char *dst, size_t dstsz, const char *value)
{
    if (value == NULL || strlen(value) >= dstsz) {
        return -1;
    }
    rv_strlcpy(dst, dstsz, value);
    return 0;
}

static int parse_long_value(const char *s, int base, long min, long max,
                            long *out)
{
    char *end = NULL;
    long v;

    if (s == NULL || *s == '\0' || out == NULL) {
        return -1;
    }
    errno = 0;
    v = strtol(s, &end, base);
    if (errno != 0 || end == s || *end != '\0' || v < min || v > max) {
        return -1;
    }
    *out = v;
    return 0;
}

static int parse_bool_value(const char *s, int *out)
{
    if (s == NULL || out == NULL) {
        return -1;
    }
    if (strcasecmp(s, "true") == 0 || strcasecmp(s, "yes") == 0 ||
        strcasecmp(s, "on") == 0 || strcmp(s, "1") == 0) {
        *out = 1;
        return 0;
    }
    if (strcasecmp(s, "false") == 0 || strcasecmp(s, "no") == 0 ||
        strcasecmp(s, "off") == 0 || strcmp(s, "0") == 0) {
        *out = 0;
        return 0;
    }
    return -1;
}

static rv_profile *config_profile_find(const rv_config *cfg, const char *name)
{
    size_t i;

    if (cfg == NULL || name == NULL) {
        return NULL;
    }
    for (i = 0; i < cfg->profile_count; i++) {
        if (strcmp(cfg->profiles[i].name, name) == 0) {
            return &cfg->profiles[i];
        }
    }
    return NULL;
}

static rv_profile *config_profile_create(rv_config *cfg, const char *name)
{
    rv_profile *profiles;
    size_t new_cap;

    if (cfg->profile_count >= RV_MAX_PROFILES) {
        return NULL;
    }
    if (cfg->profile_count == cfg->profile_cap) {
        new_cap = cfg->profile_cap == 0 ? RV_DEFAULT_PROFILE_CAP
                                        : cfg->profile_cap * 2;
        if (new_cap > RV_MAX_PROFILES) {
            new_cap = RV_MAX_PROFILES;
        }
        profiles = realloc(cfg->profiles, new_cap * sizeof(*profiles));
        if (profiles == NULL) {
            return NULL;
        }
        cfg->profiles = profiles;
        cfg->profile_cap = new_cap;
    }
    memset(&cfg->profiles[cfg->profile_count], 0, sizeof(rv_profile));
    rv_strlcpy(cfg->profiles[cfg->profile_count].name,
               sizeof(cfg->profiles[cfg->profile_count].name), name);
    cfg->profile_count++;
    return &cfg->profiles[cfg->profile_count - 1];
}

static int profile_kv_set(rv_profile *prof, const char *key, const char *value)
{
    rv_kv *kv;
    size_t new_cap;
    size_t i;

    for (i = 0; i < prof->kv_count; i++) {
        if (strcmp(prof->kv[i].key, key) == 0) {
            char *copy = strdup(value);
            if (copy == NULL) {
                return -1;
            }
            free(prof->kv[i].value);
            prof->kv[i].value = copy;
            return 0;
        }
    }

    if (prof->kv_count == prof->kv_cap) {
        new_cap = prof->kv_cap == 0 ? 8 : prof->kv_cap * 2;
        kv = realloc(prof->kv, new_cap * sizeof(*kv));
        if (kv == NULL) {
            return -1;
        }
        prof->kv = kv;
        prof->kv_cap = new_cap;
    }

    prof->kv[prof->kv_count].key = strdup(key);
    prof->kv[prof->kv_count].value = strdup(value);
    if (prof->kv[prof->kv_count].key == NULL ||
        prof->kv[prof->kv_count].value == NULL) {
        free(prof->kv[prof->kv_count].key);
        free(prof->kv[prof->kv_count].value);
        prof->kv[prof->kv_count].key = NULL;
        prof->kv[prof->kv_count].value = NULL;
        return -1;
    }
    prof->kv_count++;
    return 0;
}

static int config_profile_set(rv_config *cfg, const char *name,
                              const char *key, const char *value)
{
    rv_profile *prof = config_profile_find(cfg, name);

    if (prof == NULL) {
        if (cfg->profile_count >= RV_MAX_PROFILES) {
            return -1;
        }
        prof = config_profile_create(cfg, name);
        if (prof == NULL) {
            return -1;
        }
    }
    return profile_kv_set(prof, key, value);
}

const char *rv_config_profile_get(const rv_config *cfg, const char *profile,
                                  const char *key)
{
    const rv_profile *prof = config_profile_find(cfg, profile);
    size_t i;

    if (prof == NULL || key == NULL) {
        return NULL;
    }
    for (i = 0; i < prof->kv_count; i++) {
        if (strcmp(prof->kv[i].key, key) == 0) {
            return prof->kv[i].value;
        }
    }
    return NULL;
}

int rv_config_profile_get_bool(const rv_config *cfg, const char *profile,
                               const char *key, int def)
{
    const char *value = rv_config_profile_get(cfg, profile, key);
    int out;

    if (value == NULL || parse_bool_value(value, &out) < 0) {
        return def;
    }
    return out;
}

int rv_config_profile_get_int(const rv_config *cfg, const char *profile,
                              const char *key, int def)
{
    const char *value = rv_config_profile_get(cfg, profile, key);
    long out;

    if (value == NULL ||
        parse_long_value(value, 0, INT_MIN, INT_MAX, &out) < 0) {
        return def;
    }
    return (int)out;
}

typedef enum config_section {
    SEC_NONE = 0,
    SEC_GLOBAL,
    SEC_TRACKING,
    SEC_DOH,
    SEC_DNS,
    SEC_WARP,
    SEC_SECURITY,
    SEC_PROFILE,
    SEC_UNKNOWN
} config_section;

static void strip_comment(char *s)
{
    int in_quote = 0;
    char quote = '\0';
    size_t i;

    for (i = 0; s[i] != '\0'; i++) {
        if (in_quote) {
            if (s[i] == '\\' && s[i + 1] != '\0') {
                i++;
            } else if (s[i] == quote) {
                in_quote = 0;
            }
        } else if (s[i] == '"' || s[i] == '\'') {
            in_quote = 1;
            quote = s[i];
        } else if ((s[i] == '#' || s[i] == ';') &&
                   (i == 0 || s[i - 1] == ' ' || s[i - 1] == '\t')) {
            s[i] = '\0';
            return;
        }
    }
}

static char *unquote_value(char *value)
{
    size_t len;

    if (value == NULL) {
        return NULL;
    }
    len = strlen(value);
    if (len >= 2 && (value[0] == '"' || value[0] == '\'') &&
        value[len - 1] == value[0]) {
        value[len - 1] = '\0';
        return value + 1;
    }
    return value;
}

static int valid_profile_name(const char *name)
{
    size_t i;
    size_t len;

    if (name == NULL || *name == '\0') {
        return 0;
    }
    len = strlen(name);
    if (len >= RV_MAX_NAME) {
        return 0;
    }
    for (i = 0; i < len; i++) {
        unsigned char c = (unsigned char)name[i];
        if (!(isalnum(c) || c == '_' || c == '-')) {
            return 0;
        }
    }
    return 1;
}

int rv_config_apply_profile_override(rv_config *cfg, const char *spec)
{
    char lhs[RV_MAX_NAME + RV_MAX_STR];
    const char *eq;
    const char *value;
    char *dot;
    size_t lhs_len;

    if (cfg == NULL || spec == NULL) {
        return -1;
    }
    eq = strchr(spec, '=');
    if (eq == NULL || eq == spec || eq[1] == '\0') {
        return -1;
    }
    lhs_len = (size_t)(eq - spec);
    if (lhs_len >= sizeof(lhs)) {
        return -1;
    }
    memcpy(lhs, spec, lhs_len);
    lhs[lhs_len] = '\0';

    dot = strrchr(lhs, '.');
    if (dot == NULL || dot == lhs || dot[1] == '\0') {
        return -1;
    }
    *dot = '\0';
    if (!valid_profile_name(lhs)) {
        return -1;
    }
    value = eq + 1;
    return config_profile_set(cfg, lhs, dot + 1, value);
}

static int parse_int_setting(const char *key, const char *value, int base,
                             long min, long max, int *dst)
{
    long parsed;

    if (parse_long_value(value, base, min, max, &parsed) < 0) {
        LOG_ERROR("config: invalid integer for '%s': '%s'", key, value);
        return -1;
    }
    *dst = (int)parsed;
    return 0;
}

static int parse_bool_setting(const char *key, const char *value, int *dst)
{
    if (parse_bool_value(value, dst) < 0) {
        LOG_ERROR("config: invalid boolean for '%s': '%s'", key, value);
        return -1;
    }
    return 0;
}

static int assign_global(rv_config *cfg, const char *key, const char *value)
{
    if (strcmp(key, "interface") == 0) {
        return set_string(cfg->global.interface,
                          sizeof(cfg->global.interface), value);
    }
    if (strcmp(key, "send_interface") == 0) {
        if (*value == '\0') {
            cfg->global.send_interface[0] = '\0';
            return 0;
        }
        return set_string(cfg->global.send_interface,
                          sizeof(cfg->global.send_interface), value);
    }
    if (strcmp(key, "capture_mode") == 0) {
        if (strcasecmp(value, "direct") == 0) {
            cfg->global.capture_mode = RV_CAPTURE_DIRECT;
            return 0;
        }
        if (strcasecmp(value, "redirect") == 0) {
            cfg->global.capture_mode = RV_CAPTURE_REDIRECT;
            return 0;
        }
        LOG_ERROR("config: capture_mode must be direct or redirect");
        return -1;
    }
    if (strcmp(key, "capture_incoming") == 0) {
        return parse_bool_setting(key, value, &cfg->global.capture_incoming);
    }
    if (strcmp(key, "threads") == 0) {
        return parse_int_setting(key, value, 10, 1, RV_MAX_THREADS,
                                 &cfg->global.threads);
    }
    if (strcmp(key, "buffer_size") == 0) {
        return parse_int_setting(key, value, 10, 1500, 65535,
                                 &cfg->global.buffer_size);
    }
    if (strcmp(key, "log_level") == 0) {
        if (rv_log_level_parse(value, &cfg->global.log_level) < 0) {
            LOG_ERROR("config: invalid log_level '%s'", value);
            return -1;
        }
        return 0;
    }
    if (strcmp(key, "pid_file") == 0) {
        return set_string(cfg->global.pid_file,
                          sizeof(cfg->global.pid_file), value);
    }
    if (strcmp(key, "stats_file") == 0) {
        return set_string(cfg->global.stats_file,
                          sizeof(cfg->global.stats_file), value);
    }
    LOG_WARN("config: unknown key [global] %s", key);
    return 0;
}

static int assign_tracking(rv_config *cfg, const char *key,
                           const char *value)
{
    if (strcmp(key, "tcp_timeout") == 0) {
        return parse_int_setting(key, value, 10, 1, 86400,
                                 &cfg->tracking.tcp_timeout);
    }
    if (strcmp(key, "udp_timeout") == 0) {
        return parse_int_setting(key, value, 10, 1, 86400,
                                 &cfg->tracking.udp_timeout);
    }
    if (strcmp(key, "max_entries") == 0) {
        return parse_int_setting(key, value, 10, 1, 10000000,
                                 &cfg->tracking.max_entries);
    }
    LOG_WARN("config: unknown key [tracking] %s", key);
    return 0;
}

static int assign_doh(rv_config *cfg, const char *key, const char *value)
{
    if (strcmp(key, "enabled") == 0) {
        return parse_bool_setting(key, value, &cfg->doh.enabled);
    }
    if (strcmp(key, "mode") == 0) {
        return set_string(cfg->doh.mode, sizeof(cfg->doh.mode), value);
    }
    if (strcmp(key, "endpoint") == 0) {
        return set_string(cfg->doh.endpoint, sizeof(cfg->doh.endpoint), value);
    }
    if (strcmp(key, "format") == 0) {
        return set_string(cfg->doh.format, sizeof(cfg->doh.format), value);
    }
    if (strcmp(key, "cache_ttl") == 0) {
        return parse_int_setting(key, value, 10, 0, 86400 * 30,
                                 &cfg->doh.cache_ttl);
    }
    if (strcmp(key, "negative_ttl") == 0) {
        return parse_int_setting(key, value, 10, 0, 86400,
                                 &cfg->doh.negative_ttl);
    }
    if (strcmp(key, "fallback_to_system") == 0) {
        return parse_bool_setting(key, value,
                                  &cfg->doh.fallback_to_system);
    }
    if (strcmp(key, "listen") == 0) {
        return set_string(cfg->doh.listen, sizeof(cfg->doh.listen), value);
    }
    if (strcmp(key, "servers") == 0) {
        return set_string(cfg->doh.servers, sizeof(cfg->doh.servers), value);
    }
    if (strcmp(key, "strict") == 0) {
        return parse_bool_setting(key, value, &cfg->doh.strict);
    }
    if (strcmp(key, "block_plain") == 0) {
        return parse_bool_setting(key, value, &cfg->doh.block_plain);
    }
    if (strcmp(key, "block_other_dot") == 0) {
        return parse_bool_setting(key, value, &cfg->doh.block_other_dot);
    }
    if (strcmp(key, "bootstrap_ips") == 0) {
        return set_string(cfg->doh.bootstrap_ips,
                          sizeof(cfg->doh.bootstrap_ips), value);
    }
    LOG_WARN("config: unknown key [doh] %s", key);
    return 0;
}

static int assign_warp(rv_config *cfg, const char *key, const char *value)
{
    long mark;

    if (strcmp(key, "enabled") == 0) {
        return parse_bool_setting(key, value, &cfg->warp.enabled);
    }
    if (strcmp(key, "interface") == 0) {
        return set_string(cfg->warp.interface,
                          sizeof(cfg->warp.interface), value);
    }
    if (strcmp(key, "domain_list") == 0) {
        return set_string(cfg->warp.domain_list,
                          sizeof(cfg->warp.domain_list), value);
    }
    if (strcmp(key, "ip_list") == 0) {
        return set_string(cfg->warp.ip_list,
                          sizeof(cfg->warp.ip_list), value);
    }
    if (strcmp(key, "mark") == 0) {
        if (parse_long_value(value, 0, 0, (long)UINT32_MAX, &mark) < 0) {
            LOG_ERROR("config: invalid warp mark '%s'", value);
            return -1;
        }
        cfg->warp.mark = (uint32_t)mark;
        return 0;
    }
    if (strcmp(key, "bypass_strategies") == 0) {
        return parse_bool_setting(key, value,
                                  &cfg->warp.bypass_strategies);
    }
    if (strcmp(key, "awg_config") == 0) {
        if (*value == '\0') {
            cfg->warp.awg_config[0] = '\0';
            return 0;
        }
        return set_string(cfg->warp.awg_config,
                          sizeof(cfg->warp.awg_config), value);
    }
    if (strcmp(key, "manage_routing") == 0) {
        return parse_bool_setting(key, value,
                                  &cfg->warp.manage_routing);
    }
    if (strcmp(key, "routing_mode") == 0) {
        if (strcasecmp(value, "route") == 0) {
            cfg->warp.routing_mode = RV_ROUTING_ROUTE;
            return 0;
        }
        if (strcasecmp(value, "nft") == 0 ||
            strcasecmp(value, "nftables") == 0) {
            cfg->warp.routing_mode = RV_ROUTING_NFT;
            return 0;
        }
        LOG_ERROR("config: invalid routing_mode '%s' (route|nft)", value);
        return -1;
    }
    if (strcmp(key, "routing_table") == 0) {
        return parse_int_setting(key, value, 10, 1, 2147483647,
                                 &cfg->warp.routing_table);
    }
    if (strcmp(key, "routing_priority") == 0) {
        return parse_int_setting(key, value, 10, 1, 32766,
                                 &cfg->warp.routing_priority);
    }
    LOG_WARN("config: unknown key [warp] %s", key);
    return 0;
}

static int assign_security(rv_config *cfg, const char *key,
                           const char *value)
{
    if (strcmp(key, "drop_privileges_to") == 0) {
        return set_string(cfg->security.drop_privileges_to,
                          sizeof(cfg->security.drop_privileges_to), value);
    }
    if (strcmp(key, "required_caps") == 0) {
        return set_string(cfg->security.required_caps,
                          sizeof(cfg->security.required_caps), value);
    }
    LOG_WARN("config: unknown key [security] %s", key);
    return 0;
}

static int apply_setting(rv_config *cfg, config_section sec,
                         const char *key, const char *value)
{
    switch (sec) {
    case SEC_GLOBAL:
        return assign_global(cfg, key, value);
    case SEC_TRACKING:
        return assign_tracking(cfg, key, value);
    case SEC_DOH:
    case SEC_DNS:
        return assign_doh(cfg, key, value);
    case SEC_WARP:
        return assign_warp(cfg, key, value);
    case SEC_SECURITY:
        return assign_security(cfg, key, value);
    default:
        return 0;
    }
}

int rv_config_load(rv_config *cfg, const char *path, int required)
{
    FILE *fp;
    char *line = NULL;
    size_t line_cap = 0;
    ssize_t nread;
    unsigned long lineno = 0;
    config_section sec = SEC_NONE;
    rv_profile *cur_profile = NULL;
    int ret = 0;

    if (cfg == NULL || path == NULL || *path == '\0') {
        return -1;
    }

    fp = fopen(path, "r");
    if (fp == NULL) {
        if (errno == ENOENT && !required) {
            return 1;
        }
        LOG_ERROR("cannot open config '%s': %s", path, strerror(errno));
        return -1;
    }

    while ((nread = getline(&line, &line_cap, fp)) >= 0) {
        char *p;
        char *eq;
        char *key;
        char *value;

        lineno++;
        if ((size_t)nread > RV_CONFIG_LINE_MAX) {
            LOG_ERROR("%s:%lu: line too long", path, lineno);
            ret = -1;
            break;
        }

        strip_comment(line);
        p = rv_trim(line);
        if (*p == '\0') {
            continue;
        }

        if (*p == '[') {
            char *end = strchr(p, ']');
            char *after;
            char *name;

            if (end == NULL) {
                LOG_ERROR("%s:%lu: unterminated section header", path,
                          lineno);
                ret = -1;
                break;
            }
            after = rv_trim(end + 1);
            if (*after != '\0') {
                LOG_ERROR("%s:%lu: trailing data after section header",
                          path, lineno);
                ret = -1;
                break;
            }
            *end = '\0';
            name = rv_trim(p + 1);
            cur_profile = NULL;

            if (strcmp(name, "global") == 0) {
                sec = SEC_GLOBAL;
            } else if (strcmp(name, "tracking") == 0) {
                sec = SEC_TRACKING;
            } else if (strcmp(name, "doh") == 0) {
                sec = SEC_DOH;
            } else if (strcmp(name, "dns") == 0) {
                sec = SEC_DNS;
            } else if (strcmp(name, "warp") == 0) {
                sec = SEC_WARP;
            } else if (strcmp(name, "security") == 0) {
                sec = SEC_SECURITY;
            } else if (strncmp(name, "profile.", 8) == 0) {
                const char *pname = name + 8;
                if (!valid_profile_name(pname)) {
                    LOG_ERROR("%s:%lu: invalid profile name '%s'", path,
                              lineno, pname);
                    ret = -1;
                    break;
                }
                cur_profile = config_profile_find(cfg, pname);
                if (cur_profile == NULL) {
                    cur_profile = config_profile_create(cfg, pname);
                }
                if (cur_profile == NULL) {
                    LOG_ERROR("%s:%lu: too many profiles", path, lineno);
                    ret = -1;
                    break;
                }
                sec = SEC_PROFILE;
            } else {
                LOG_WARN("%s:%lu: unknown section [%s], ignoring", path,
                         lineno, name);
                sec = SEC_UNKNOWN;
            }
            continue;
        }

        eq = strchr(p, '=');
        if (eq == NULL) {
            LOG_ERROR("%s:%lu: expected key=value", path, lineno);
            ret = -1;
            break;
        }
        *eq = '\0';
        key = rv_trim(p);
        value = unquote_value(rv_trim(eq + 1));
        if (*key == '\0' || strlen(key) >= RV_MAX_STR) {
            LOG_ERROR("%s:%lu: invalid key", path, lineno);
            ret = -1;
            break;
        }
        if (strlen(value) >= RV_CONFIG_LINE_MAX) {
            LOG_ERROR("%s:%lu: value too long", path, lineno);
            ret = -1;
            break;
        }

        if (sec == SEC_NONE) {
            LOG_ERROR("%s:%lu: key outside of a section", path, lineno);
            ret = -1;
            break;
        }
        if (sec == SEC_UNKNOWN) {
            continue;
        }
        if (sec == SEC_PROFILE) {
            if (cur_profile == NULL ||
                profile_kv_set(cur_profile, key, value) < 0) {
                LOG_ERROR("%s:%lu: cannot store profile value", path,
                          lineno);
                ret = -1;
                break;
            }
            continue;
        }
        if (apply_setting(cfg, sec, key, value) < 0) {
            LOG_ERROR("%s:%lu: invalid value for '%s'", path, lineno, key);
            ret = -1;
            break;
        }
    }

    if (ret == 0 && ferror(fp)) {
        LOG_ERROR("error reading config '%s': %s", path, strerror(errno));
        ret = -1;
    }

    free(line);
    fclose(fp);
    return ret;
}

int rv_config_validate(rv_config *cfg)
{
    int ok = 1;

    if (cfg == NULL) {
        return -1;
    }

    if (cfg->global.interface[0] == '\0' ||
        strlen(cfg->global.interface) >= RV_IFNAMSIZ) {
        LOG_ERROR("config: invalid interface name");
        ok = 0;
    }
    if (cfg->global.send_interface[0] != '\0' &&
        strlen(cfg->global.send_interface) >= RV_IFNAMSIZ) {
        LOG_ERROR("config: invalid send_interface name");
        ok = 0;
    }
    if (cfg->global.capture_mode != RV_CAPTURE_DIRECT &&
        cfg->global.capture_mode != RV_CAPTURE_REDIRECT) {
        LOG_ERROR("config: capture_mode must be direct or redirect");
        ok = 0;
    }
    if (cfg->global.threads < 1 || cfg->global.threads > RV_MAX_THREADS) {
        LOG_ERROR("config: threads must be in [1, %d]", RV_MAX_THREADS);
        ok = 0;
    }
    if (cfg->global.buffer_size < 1500 ||
        cfg->global.buffer_size > 65535) {
        LOG_ERROR("config: buffer_size must be in [1500, 65535]");
        ok = 0;
    }
    if (cfg->global.pid_file[0] == '\0') {
        LOG_ERROR("config: pid_file must not be empty");
        ok = 0;
    }
    if (cfg->global.stats_file[0] == '\0') {
        LOG_ERROR("config: stats_file must not be empty");
        ok = 0;
    }

    if (cfg->doh.enabled &&
        strcasecmp(cfg->doh.mode, "system") != 0 &&
        strcasecmp(cfg->doh.mode, "off") != 0 &&
        strcasecmp(cfg->doh.mode, "dot") != 0 &&
        strcasecmp(cfg->doh.mode, "doh") != 0) {
        LOG_ERROR("config: dns mode '%s' is invalid (off|system|dot|doh)",
                  cfg->doh.mode);
        ok = 0;
    }
    if (cfg->doh.enabled &&
        (strcasecmp(cfg->doh.mode, "dot") == 0 ||
         strcasecmp(cfg->doh.mode, "doh") == 0)) {
        if (cfg->doh.listen[0] == '\0' || cfg->doh.servers[0] == '\0') {
            LOG_ERROR("config: dns.listen and dns.servers must not be empty");
            ok = 0;
        }
    }

    if (cfg->warp.enabled && cfg->warp.interface[0] == '\0') {
        LOG_WARN("config: warp.enabled is true but warp.interface is empty");
    }
    if (cfg->warp.enabled && cfg->warp.manage_routing &&
        cfg->warp.awg_config[0] != '\0' &&
        cfg->warp.routing_mode == RV_ROUTING_NFT &&
        cfg->warp.mark == 0) {
        LOG_ERROR("config: nft WARP routing requires a non-zero mark");
        ok = 0;
    }
    if (cfg->warp.enabled && cfg->warp.manage_routing &&
        cfg->warp.awg_config[0] != '\0' &&
        (cfg->warp.routing_table < 1 ||
         cfg->warp.routing_priority < 1)) {
        LOG_ERROR("config: invalid WARP routing_table/routing_priority");
        ok = 0;
    }
    if (cfg->warp.enabled && cfg->warp.manage_routing &&
        cfg->warp.awg_config[0] != '\0' &&
        cfg->security.drop_privileges_to[0] != '\0' &&
        strstr(cfg->security.required_caps, "CAP_NET_ADMIN") == NULL) {
        LOG_ERROR("config: AWG routing needs CAP_NET_ADMIN in required_caps");
        ok = 0;
    }
    if (cfg->security.drop_privileges_to[0] != '\0' &&
        strstr(cfg->security.required_caps, "CAP_NET_RAW") == NULL) {
        LOG_ERROR("config: drop_privileges_to is set, but required_caps does "
                  "not include CAP_NET_RAW; AF_PACKET TX would fail after "
                  "drop");
        ok = 0;
    }

    return ok ? 0 : -1;
}

