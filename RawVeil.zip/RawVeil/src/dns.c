#include "dns.h"

#include "common.h"
#include "log.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <curl/curl.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/x509v3.h>
#include <poll.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#define RV_DNS_MAX_MSG 65535
#define RV_DNS_CACHE_MAX 2048
#define RV_DNS_MAX_SERVERS 4
#define RV_DNS_KEY_MAX 300
#define RV_DNS_TIMEOUT_MS 3000

typedef struct dns_server {
    struct sockaddr_storage addr;
    socklen_t addrlen;
    char hostname[256];
    char ip[INET6_ADDRSTRLEN];
} dns_server;

typedef struct dns_cache_entry {
    char key[RV_DNS_KEY_MAX];
    uint8_t *response;
    size_t response_len;
    time_t expires;
    struct dns_cache_entry *next;
} dns_cache_entry;

struct rv_dns {
    int udp_fd;
    int tcp_fd;
    pthread_t thread;
    int thread_started;
    volatile int stop;
    int mode_doh;
    int strict;
    int cache_ttl;
    int negative_ttl;
    char endpoint[RV_MAX_PATH];
    char bootstrap[RV_MAX_STR];
    dns_server servers[RV_DNS_MAX_SERVERS];
    size_t server_count;
    size_t next_server;
    SSL_CTX *ssl_ctx;
    SSL *dot_ssl;
    int dot_fd;
    pthread_mutex_t dot_lock;
    pthread_mutex_t cache_lock;
    dns_cache_entry *cache;
    size_t cache_count;
    rv_dns_stats stats;
};

static int dns_read_u16(const uint8_t *p)
{
    return ((int)p[0] << 8) | p[1];
}

static void dns_write_u16(uint8_t *p, unsigned value)
{
    p[0] = (uint8_t)((value >> 8) & 0xffu);
    p[1] = (uint8_t)(value & 0xffu);
}

static int dns_question_end(const uint8_t *msg, size_t len, size_t *end,
                            char *name, size_t namesz, unsigned *qtype,
                            unsigned *qclass)
{
    size_t pos = 12;
    size_t out = 0;
    int qdcount;

    if (msg == NULL || len < 12 || end == NULL) {
        return -1;
    }
    qdcount = dns_read_u16(msg + 4);
    if (qdcount < 1) {
        return -1;
    }
    while (pos < len) {
        uint8_t label = msg[pos++];
        if (label == 0) {
            break;
        }
        if ((label & 0xc0u) != 0 || pos + label > len) {
            return -1;
        }
        if (out != 0 && out + 1 < namesz) {
            name[out++] = '.';
        }
        for (size_t i = 0; i < label; i++) {
            if (out + 1 < namesz) {
                name[out++] = (char)tolower(msg[pos + i]);
            }
        }
        pos += label;
    }
    if (pos + 4 > len) {
        return -1;
    }
    if (name != NULL && namesz > 0) {
        name[out] = '\0';
    }
    if (qtype != NULL) {
        *qtype = (unsigned)dns_read_u16(msg + pos);
    }
    if (qclass != NULL) {
        *qclass = (unsigned)dns_read_u16(msg + pos + 2);
    }
    pos += 4;
    *end = pos;
    return 0;
}

static int dns_make_servfail(const uint8_t *query, size_t query_len,
                             size_t question_end, uint8_t *out, size_t outsz,
                             size_t *out_len)
{
    size_t len;

    if (query == NULL || query_len < 12 || question_end < 12 ||
        question_end > query_len) {
        return -1;
    }
    len = question_end;
    if (len > outsz) {
        return -1;
    }
    memcpy(out, query, len);
    out[2] = (uint8_t)((out[2] & 0x01u) | 0x80u); /* QR=1 */
    out[3] = (uint8_t)((out[3] & 0xf0u) | 2u);    /* SERVFAIL */
    dns_write_u16(out + 6, 0);
    dns_write_u16(out + 8, 0);
    dns_write_u16(out + 10, 0);
    *out_len = len;
    return 0;
}
static int dns_server_parse(rv_dns *dns, const char *text)
{
    char buf[RV_MAX_STR];
    char *save = NULL;
    char *token;

    if (dns == NULL || text == NULL) {
        return -1;
    }
    rv_strlcpy(buf, sizeof(buf), text);
    for (token = strtok_r(buf, ",", &save); token != NULL;
         token = strtok_r(NULL, ",", &save)) {
        char *hash;
        const char *host = NULL;
        const char *ip;
        dns_server *server;
        struct sockaddr_in *sin;
        struct sockaddr_in6 *sin6;

        token = rv_trim(token);
        if (*token == '\0') {
            continue;
        }
        if (dns->server_count >= RV_DNS_MAX_SERVERS) {
            return -1;
        }
        hash = strchr(token, '#');
        if (hash != NULL) {
            *hash = '\0';
            host = rv_trim(hash + 1);
        }
        ip = rv_trim(token);
        server = &dns->servers[dns->server_count];
        memset(server, 0, sizeof(*server));
        sin = (struct sockaddr_in *)&server->addr;
        sin6 = (struct sockaddr_in6 *)&server->addr;
        if (inet_pton(AF_INET, ip, &sin->sin_addr) == 1) {
            sin->sin_family = AF_INET;
            sin->sin_port = htons(853);
            server->addrlen = sizeof(*sin);
        } else if (inet_pton(AF_INET6, ip, &sin6->sin6_addr) == 1) {
            sin6->sin6_family = AF_INET6;
            sin6->sin6_port = htons(853);
            server->addrlen = sizeof(*sin6);
        } else {
            return -1;
        }
        rv_strlcpy(server->ip, sizeof(server->ip), ip);
        if (host != NULL && *host != '\0') {
            rv_strlcpy(server->hostname, sizeof(server->hostname), host);
        }
        dns->server_count++;
    }
    return dns->server_count > 0 ? 0 : -1;
}

static void dns_cache_remove_expired(rv_dns *dns, time_t now)
{
    dns_cache_entry **link = &dns->cache;

    while (*link != NULL) {
        dns_cache_entry *entry = *link;
        if (entry->expires <= now) {
            *link = entry->next;
            free(entry->response);
            free(entry);
            if (dns->cache_count > 0) {
                dns->cache_count--;
            }
        } else {
            link = &entry->next;
        }
    }
}

static int dns_cache_get(rv_dns *dns, const char *key, uint8_t *out,
                         size_t outsz, size_t *out_len)
{
    dns_cache_entry *entry;
    int rc = -1;

    pthread_mutex_lock(&dns->cache_lock);
    dns_cache_remove_expired(dns, time(NULL));
    for (entry = dns->cache; entry != NULL; entry = entry->next) {
        if (strcmp(entry->key, key) == 0 &&
            entry->response_len <= outsz) {
            memcpy(out, entry->response, entry->response_len);
            *out_len = entry->response_len;
            __atomic_add_fetch(&dns->stats.cache_hits, 1, __ATOMIC_RELAXED);
            rc = 0;
            break;
        }
    }
    pthread_mutex_unlock(&dns->cache_lock);
    return rc;
}

static void dns_cache_put(rv_dns *dns, const char *key,
                          const uint8_t *response, size_t response_len)
{
    dns_cache_entry *entry;
    time_t now = time(NULL);

    if (dns->cache_ttl <= 0 || response_len > RV_DNS_MAX_MSG) {
        return;
    }
    entry = calloc(1, sizeof(*entry));
    if (entry == NULL) {
        return;
    }
    entry->response = malloc(response_len);
    if (entry->response == NULL) {
        free(entry);
        return;
    }
    memcpy(entry->response, response, response_len);
    entry->response_len = response_len;
    entry->expires = now + dns->cache_ttl;
    rv_strlcpy(entry->key, sizeof(entry->key), key);

    pthread_mutex_lock(&dns->cache_lock);
    dns_cache_remove_expired(dns, now);
    while (dns->cache_count >= RV_DNS_CACHE_MAX && dns->cache != NULL) {
        dns_cache_entry *victim = dns->cache;
        dns->cache = victim->next;
        free(victim->response);
        free(victim);
        dns->cache_count--;
    }
    entry->next = dns->cache;
    dns->cache = entry;
    dns->cache_count++;
    pthread_mutex_unlock(&dns->cache_lock);
}


static int connect_timeout(int fd, const struct sockaddr *addr,
                           socklen_t addrlen, int timeout_ms)
{
    int flags;
    int rc;
    struct pollfd pfd;

    flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) {
        return -1;
    }
    rc = connect(fd, addr, addrlen);
    if (rc < 0 && errno != EINPROGRESS) {
        return -1;
    }
    if (rc < 0) {
        pfd.fd = fd;
        pfd.events = POLLOUT;
        pfd.revents = 0;
        rc = poll(&pfd, 1, timeout_ms);
        if (rc <= 0) {
            errno = ETIMEDOUT;
            return -1;
        }
        {
            int err = 0;
            socklen_t errlen = sizeof(err);
            if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &errlen) < 0 ||
                err != 0) {
                errno = err != 0 ? err : errno;
                return -1;
            }
        }
    }
    if (fcntl(fd, F_SETFL, flags) < 0) {
        return -1;
    }
    return 0;
}

static int ssl_write_all(SSL *ssl, const uint8_t *data, size_t len)
{
    size_t off = 0;

    while (off < len) {
        int n = SSL_write(ssl, data + off, (int)(len - off));
        if (n <= 0) {
            return -1;
        }
        off += (size_t)n;
    }
    return 0;
}

static int ssl_read_all(SSL *ssl, uint8_t *data, size_t len)
{
    size_t off = 0;

    while (off < len) {
        int n = SSL_read(ssl, data + off, (int)(len - off));
        if (n <= 0) {
            return -1;
        }
        off += (size_t)n;
    }
    return 0;
}

static void dot_close(rv_dns *dns)
{
    if (dns->dot_ssl != NULL) {
        SSL_free(dns->dot_ssl);
        dns->dot_ssl = NULL;
    }
    if (dns->dot_fd >= 0) {
        close(dns->dot_fd);
        dns->dot_fd = -1;
    }
}

static int dot_connect_next(rv_dns *dns)
{
    size_t attempt;

    if (dns->ssl_ctx == NULL || dns->server_count == 0) {
        return -1;
    }
    for (attempt = 0; attempt < dns->server_count; attempt++) {
        size_t i = (dns->next_server + attempt) % dns->server_count;
        dns_server *server = &dns->servers[i];
        struct timeval tv;
        uint8_t frame[2];
        SSL *ssl;
        int fd;

        fd = socket(server->addr.ss_family, SOCK_STREAM | SOCK_CLOEXEC, 0);
        if (fd < 0) {
            continue;
        }
        if (connect_timeout(fd, (struct sockaddr *)&server->addr,
                            server->addrlen, RV_DNS_TIMEOUT_MS) < 0) {
            close(fd);
            continue;
        }
        tv.tv_sec = RV_DNS_TIMEOUT_MS / 1000;
        tv.tv_usec = (RV_DNS_TIMEOUT_MS % 1000) * 1000;
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

        ssl = SSL_new(dns->ssl_ctx);
        if (ssl == NULL) {
            close(fd);
            continue;
        }
        SSL_set_fd(ssl, fd);
        if (server->hostname[0] != '\0') {
            SSL_set_tlsext_host_name(ssl, server->hostname);
            SSL_set1_host(ssl, server->hostname);
        } else {
            X509_VERIFY_PARAM_set1_ip_asc(SSL_get0_param(ssl), server->ip);
        }
        if (SSL_connect(ssl) != 1 ||
            SSL_get_verify_result(ssl) != X509_V_OK) {
            SSL_free(ssl);
            close(fd);
            continue;
        }
        /* Wait for the server's two-byte DNS length only once per query;
         * no data is expected before the first client query. */
        (void)frame;
        dns->dot_ssl = ssl;
        dns->dot_fd = fd;
        dns->next_server = (i + 1) % dns->server_count;
        return 0;
    }
    return -1;
}

static int dot_exchange(rv_dns *dns, const uint8_t *query, size_t query_len,
                        uint8_t *out, size_t outsz, size_t *out_len)
{
    uint8_t frame[2];
    uint16_t response_len;
    int attempt;
    int rc = -1;

    pthread_mutex_lock(&dns->dot_lock);
    for (attempt = 0; attempt < 2; attempt++) {
        if (dns->dot_ssl == NULL && dot_connect_next(dns) < 0) {
            break;
        }
        frame[0] = (uint8_t)((query_len >> 8) & 0xffu);
        frame[1] = (uint8_t)(query_len & 0xffu);
        if (ssl_write_all(dns->dot_ssl, frame, sizeof(frame)) == 0 &&
            ssl_write_all(dns->dot_ssl, query, query_len) == 0 &&
            ssl_read_all(dns->dot_ssl, frame, sizeof(frame)) == 0) {
            response_len = (uint16_t)(((uint16_t)frame[0] << 8) | frame[1]);
            if (response_len >= 12 && response_len <= outsz &&
                ssl_read_all(dns->dot_ssl, out, response_len) == 0) {
                *out_len = response_len;
                rc = 0;
                break;
            }
        }
        /* The persistent connection may have been closed by the server. */
        dot_close(dns);
    }
    pthread_mutex_unlock(&dns->dot_lock);
    return rc;
}
struct doh_buffer {
    uint8_t *data;
    size_t len;
    size_t cap;
};

static size_t doh_write_cb(char *ptr, size_t size, size_t nmemb, void *userdata)
{
    struct doh_buffer *buf = userdata;
    size_t n = size * nmemb;
    uint8_t *next;

    if (buf->len + n > RV_DNS_MAX_MSG) {
        return 0;
    }
    if (buf->len + n > buf->cap) {
        size_t cap = buf->cap == 0 ? 4096 : buf->cap;
        while (cap < buf->len + n) {
            cap *= 2;
        }
        next = realloc(buf->data, cap);
        if (next == NULL) {
            return 0;
        }
        buf->data = next;
        buf->cap = cap;
    }
    memcpy(buf->data + buf->len, ptr, n);
    buf->len += n;
    return n;
}

static void url_host(const char *url, char *host, size_t hostsz)
{
    const char *p = strstr(url, "://");
    const char *end;
    const char *at;

    host[0] = '\0';
    if (p == NULL) {
        return;
    }
    p += 3;
    at = strchr(p, '@');
    if (at != NULL) {
        p = at + 1;
    }
    end = p;
    while (*end != '\0' && *end != ':' && *end != '/' && *end != '?') {
        end++;
    }
    if ((size_t)(end - p) < hostsz) {
        memcpy(host, p, (size_t)(end - p));
        host[end - p] = '\0';
    }
}

static int doh_exchange(rv_dns *dns, const uint8_t *query, size_t query_len,
                        uint8_t *out, size_t outsz, size_t *out_len)
{
    CURL *curl;
    CURLcode rc;
    struct curl_slist *headers = NULL;
    struct curl_slist *resolve = NULL;
    struct doh_buffer buf;
    char host[256];
    char resolve_entry[1024];
    char ipbuf[RV_MAX_STR];
    const char *first_ip;

    memset(&buf, 0, sizeof(buf));
    url_host(dns->endpoint, host, sizeof(host));
    if (host[0] == '\0') {
        return -1;
    }
    first_ip = dns->bootstrap;
    while (*first_ip == ' ' || *first_ip == '\t') {
        first_ip++;
    }
    if (*first_ip == '\0') {
        return -1;
    }
    rv_strlcpy(ipbuf, sizeof(ipbuf), first_ip);
    {
        char *sep = strchr(ipbuf, ',');
        if (sep != NULL) {
            *sep = '\0';
        }
        sep = strchr(ipbuf, ' ');
        if (sep != NULL) {
            *sep = '\0';
        }
    }
    snprintf(resolve_entry, sizeof(resolve_entry), "%s:443:%s", host, ipbuf);

    curl = curl_easy_init();
    if (curl == NULL) {
        return -1;
    }
    headers = curl_slist_append(headers,
                                "Content-Type: application/dns-message");
    headers = curl_slist_append(headers,
                                "Accept: application/dns-message");
    resolve = curl_slist_append(resolve, resolve_entry);
    curl_easy_setopt(curl, CURLOPT_URL, dns->endpoint);
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, query);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, (long)query_len);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_RESOLVE, resolve);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, doh_write_cb);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &buf);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT_MS,
                     (long)RV_DNS_TIMEOUT_MS);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, (long)RV_DNS_TIMEOUT_MS);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    curl_easy_setopt(curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2TLS);
    rc = curl_easy_perform(curl);
    if (rc == CURLE_OK && buf.len >= 12 && buf.len <= outsz) {
        memcpy(out, buf.data, buf.len);
        *out_len = buf.len;
    } else {
        rc = CURLE_RECV_ERROR;
    }
    curl_slist_free_all(headers);
    curl_slist_free_all(resolve);
    curl_easy_cleanup(curl);
    free(buf.data);
    return rc == CURLE_OK ? 0 : -1;
}

static int dns_resolve(rv_dns *dns, const uint8_t *query, size_t query_len,
                       uint8_t *out, size_t outsz, size_t *out_len)
{
    char name[RV_DNS_KEY_MAX];
    char key[RV_DNS_KEY_MAX + 32];
    unsigned qtype = 0;
    unsigned qclass = 0;
    size_t question_end = 0;
    int rc;

    __atomic_add_fetch(&dns->stats.queries, 1, __ATOMIC_RELAXED);
    if (dns_question_end(query, query_len, &question_end, name, sizeof(name),
                         &qtype, &qclass) < 0) {
        __atomic_add_fetch(&dns->stats.malformed, 1, __ATOMIC_RELAXED);
        return -1;
    }
    snprintf(key, sizeof(key), "%s|%u|%u", name, qtype, qclass);
    if (dns_cache_get(dns, key, out, outsz, out_len) == 0) {
        dns_write_u16(out, (unsigned)dns_read_u16(query));
        return 0;
    }

    if (dns->mode_doh) {
        rc = doh_exchange(dns, query, query_len, out, outsz, out_len);
    } else {
        rc = dot_exchange(dns, query, query_len, out, outsz, out_len);
    }
    if (rc < 0) {
        __atomic_add_fetch(&dns->stats.upstream_fail, 1, __ATOMIC_RELAXED);
        if (dns_make_servfail(query, query_len, question_end,
                              out, outsz, out_len) < 0) {
            return -1;
        }
        __atomic_add_fetch(&dns->stats.servfail, 1, __ATOMIC_RELAXED);
        return 0;
    }
    if (*out_len < 12 || (out[2] & 0x80u) == 0) {
        __atomic_add_fetch(&dns->stats.upstream_fail, 1, __ATOMIC_RELAXED);
        return -1;
    }
    __atomic_add_fetch(&dns->stats.upstream_ok, 1, __ATOMIC_RELAXED);
    dns_write_u16(out, (unsigned)dns_read_u16(query));
    dns_cache_put(dns, key, out, *out_len);
    return 0;
}

static void dns_handle_udp(rv_dns *dns)
{
    uint8_t query[RV_DNS_MAX_MSG];
    uint8_t response[RV_DNS_MAX_MSG];
    struct sockaddr_storage peer;
    socklen_t peerlen = sizeof(peer);
    ssize_t n;
    size_t response_len = 0;

    n = recvfrom(dns->udp_fd, query, sizeof(query), 0,
                 (struct sockaddr *)&peer, &peerlen);
    if (n <= 0) {
        return;
    }
    if (dns_resolve(dns, query, (size_t)n, response, sizeof(response),
                    &response_len) == 0) {
        (void)sendto(dns->udp_fd, response, response_len, 0,
                     (struct sockaddr *)&peer, peerlen);
    }
}

static int read_all_fd(int fd, uint8_t *buf, size_t len)
{
    size_t off = 0;

    while (off < len) {
        ssize_t n = read(fd, buf + off, len - off);
        if (n <= 0) {
            return -1;
        }
        off += (size_t)n;
    }
    return 0;
}

static int write_all_fd(int fd, const uint8_t *buf, size_t len)
{
    size_t off = 0;

    while (off < len) {
        ssize_t n = write(fd, buf + off, len - off);
        if (n <= 0) {
            return -1;
        }
        off += (size_t)n;
    }
    return 0;
}

static void dns_handle_tcp(rv_dns *dns)
{
    uint8_t query[RV_DNS_MAX_MSG];
    uint8_t response[RV_DNS_MAX_MSG];
    uint8_t frame[2];
    struct sockaddr_storage peer;
    socklen_t peerlen = sizeof(peer);
    struct timeval tv;
    size_t query_len;
    size_t response_len = 0;
    int fd = accept(dns->tcp_fd, (struct sockaddr *)&peer, &peerlen);

    if (fd < 0) {
        return;
    }
    tv.tv_sec = 5;
    tv.tv_usec = 0;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    if (read_all_fd(fd, frame, sizeof(frame)) < 0) {
        close(fd);
        return;
    }
    query_len = ((size_t)frame[0] << 8) | frame[1];
    if (query_len < 12 || query_len > sizeof(query)) {
        close(fd);
        return;
    }
    if (read_all_fd(fd, query, query_len) < 0) {
        close(fd);
        return;
    }
    if (dns_resolve(dns, query, query_len, response, sizeof(response),
                    &response_len) == 0 && response_len <= 65535) {
        frame[0] = (uint8_t)((response_len >> 8) & 0xffu);
        frame[1] = (uint8_t)(response_len & 0xffu);
        if (write_all_fd(fd, frame, sizeof(frame)) == 0) {
            (void)write_all_fd(fd, response, response_len);
        }
    }
    close(fd);
}

static void *dns_thread(void *arg)
{
    rv_dns *dns = arg;

    while (!dns->stop) {
        struct pollfd pfd[2];
        int rc;

        pfd[0].fd = dns->udp_fd;
        pfd[0].events = POLLIN;
        pfd[0].revents = 0;
        pfd[1].fd = dns->tcp_fd;
        pfd[1].events = POLLIN;
        pfd[1].revents = 0;
        rc = poll(pfd, 2, 500);
        if (rc <= 0) {
            continue;
        }
        if ((pfd[0].revents & POLLIN) != 0) {
            dns_handle_udp(dns);
        }
        if ((pfd[1].revents & POLLIN) != 0) {
            dns_handle_tcp(dns);
        }
    }
    return NULL;
}

static int parse_listen(const char *text, char *host, size_t hostsz,
                        char *port, size_t portsz)
{
    const char *colon;
    size_t len;

    if (text == NULL || *text == '\0') {
        return -1;
    }
    if (text[0] == '[') {
        const char *close = strchr(text, ']');
        if (close == NULL || close[1] != ':') {
            return -1;
        }
        len = (size_t)(close - text - 1);
        if (len >= hostsz) {
            return -1;
        }
        memcpy(host, text + 1, len);
        host[len] = '\0';
        rv_strlcpy(port, portsz, close + 2);
        return 0;
    }
    colon = strrchr(text, ':');
    if (colon == NULL) {
        rv_strlcpy(host, hostsz, text);
        rv_strlcpy(port, portsz, "5353");
        return 0;
    }
    len = (size_t)(colon - text);
    if (len >= hostsz) {
        return -1;
    }
    memcpy(host, text, len);
    host[len] = '\0';
    rv_strlcpy(port, portsz, colon + 1);
    return 0;
}

static int bind_socket(const char *host, const char *port, int type,
                       char *err, size_t errlen)
{
    struct addrinfo hints;
    struct addrinfo *result = NULL;
    struct addrinfo *ai;
    int fd = -1;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = type;
    hints.ai_flags = AI_NUMERICHOST | AI_PASSIVE;
    if (getaddrinfo(host, port, &hints, &result) != 0) {
        (void)snprintf(err, errlen, "cannot parse DNS listen address %s:%s",
                       host, port);
        return -1;
    }
    for (ai = result; ai != NULL; ai = ai->ai_next) {
        int one = 1;
        fd = socket(ai->ai_family, ai->ai_socktype | SOCK_CLOEXEC, 0);
        if (fd < 0) {
            continue;
        }
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
        if (bind(fd, ai->ai_addr, ai->ai_addrlen) == 0) {
            if (type == SOCK_STREAM && listen(fd, 8) < 0) {
                close(fd);
                fd = -1;
                continue;
            }
            break;
        }
        close(fd);
        fd = -1;
    }
    freeaddrinfo(result);
    if (fd < 0) {
        (void)snprintf(err, errlen, "cannot bind DNS proxy to %s:%s: %s",
                       host, port, strerror(errno));
    }
    return fd;
}

int rv_dns_enabled(const rv_config *cfg)
{
    if (cfg == NULL || !cfg->doh.enabled) {
        return 0;
    }
    return strcasecmp(cfg->doh.mode, "dot") == 0 ||
           strcasecmp(cfg->doh.mode, "doh") == 0;
}

rv_dns *rv_dns_start(const rv_config *cfg, char *err, size_t errlen)
{
    rv_dns *dns;
    char host[256];
    char port[16];

    if (err != NULL && errlen > 0) {
        err[0] = '\0';
    }
    if (!rv_dns_enabled(cfg)) {
        return NULL;
    }
    dns = calloc(1, sizeof(*dns));
    if (dns == NULL) {
        (void)snprintf(err, errlen, "out of memory");
        return NULL;
    }
    dns->udp_fd = -1;
    dns->tcp_fd = -1;
    dns->dot_fd = -1;
    dns->strict = cfg->doh.strict;
    dns->cache_ttl = cfg->doh.cache_ttl;
    dns->negative_ttl = cfg->doh.negative_ttl;
    dns->mode_doh = strcasecmp(cfg->doh.mode, "doh") == 0;
    rv_strlcpy(dns->endpoint, sizeof(dns->endpoint), cfg->doh.endpoint);
    rv_strlcpy(dns->bootstrap, sizeof(dns->bootstrap), cfg->doh.bootstrap_ips);
    if (pthread_mutex_init(&dns->cache_lock, NULL) != 0) {
        free(dns);
        (void)snprintf(err, errlen, "cannot init DNS cache mutex");
        return NULL;
    }
    if (pthread_mutex_init(&dns->dot_lock, NULL) != 0) {
        pthread_mutex_destroy(&dns->cache_lock);
        free(dns);
        (void)snprintf(err, errlen, "cannot init DNS connection mutex");
        return NULL;
    }
    if (parse_listen(cfg->doh.listen, host, sizeof(host),
                     port, sizeof(port)) < 0) {
        (void)snprintf(err, errlen, "invalid dns.listen");
        goto fail;
    }
    dns->udp_fd = bind_socket(host, port, SOCK_DGRAM, err, errlen);
    if (dns->udp_fd < 0) {
        goto fail;
    }
    dns->tcp_fd = bind_socket(host, port, SOCK_STREAM, err, errlen);
    if (dns->tcp_fd < 0) {
        goto fail;
    }
    if (dns->mode_doh) {
        if (curl_global_init(CURL_GLOBAL_DEFAULT) != 0) {
            (void)snprintf(err, errlen, "curl_global_init failed");
            goto fail;
        }
    } else {
        if (dns_server_parse(dns, cfg->doh.servers) < 0) {
            (void)snprintf(err, errlen, "invalid DNS servers list");
            goto fail;
        }
        dns->ssl_ctx = SSL_CTX_new(TLS_client_method());
        if (dns->ssl_ctx == NULL) {
            (void)snprintf(err, errlen, "cannot create TLS context");
            goto fail;
        }
        SSL_CTX_set_min_proto_version(dns->ssl_ctx, TLS1_2_VERSION);
        SSL_CTX_set_verify(dns->ssl_ctx, SSL_VERIFY_PEER, NULL);
        if (SSL_CTX_set_default_verify_paths(dns->ssl_ctx) != 1) {
            (void)snprintf(err, errlen, "cannot load CA certificates");
            goto fail;
        }
    }
    if (pthread_create(&dns->thread, NULL, dns_thread, dns) != 0) {
        (void)snprintf(err, errlen, "cannot create DNS thread");
        goto fail;
    }
    dns->thread_started = 1;
    LOG_INFO("dns: %s proxy on %s:%s, strict=%d, cache_ttl=%d",
             dns->mode_doh ? "DoH" : "DoT", host, port, dns->strict,
             dns->cache_ttl);
    return dns;

fail:
    rv_dns_stop(dns);
    return NULL;
}

void rv_dns_stop(rv_dns *dns)
{
    dns_cache_entry *entry;

    if (dns == NULL) {
        return;
    }
    dns->stop = 1;
    if (dns->udp_fd >= 0) {
        shutdown(dns->udp_fd, SHUT_RDWR);
    }
    if (dns->tcp_fd >= 0) {
        shutdown(dns->tcp_fd, SHUT_RDWR);
    }
    if (dns->thread_started) {
        pthread_join(dns->thread, NULL);
    }
    pthread_mutex_lock(&dns->dot_lock);
    dot_close(dns);
    pthread_mutex_unlock(&dns->dot_lock);
    if (dns->udp_fd >= 0) {
        close(dns->udp_fd);
    }
    if (dns->tcp_fd >= 0) {
        close(dns->tcp_fd);
    }
    entry = dns->cache;
    while (entry != NULL) {
        dns_cache_entry *next = entry->next;
        free(entry->response);
        free(entry);
        entry = next;
    }
    if (dns->ssl_ctx != NULL) {
        SSL_CTX_free(dns->ssl_ctx);
    }
    if (dns->mode_doh) {
        curl_global_cleanup();
    }
    pthread_mutex_destroy(&dns->dot_lock);
    pthread_mutex_destroy(&dns->cache_lock);
    free(dns);
}

void rv_dns_get_stats(rv_dns *dns, rv_dns_stats *out)
{
    if (out == NULL) {
        return;
    }
    if (dns == NULL) {
        memset(out, 0, sizeof(*out));
        return;
    }
    *out = dns->stats;
}

