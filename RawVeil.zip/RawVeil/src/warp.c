#include "warp.h"

#include "log.h"

#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>

#define RV_WARP_MAX_IPS 262144u
#define RV_WARP_MAX_DOMAINS 16384u
#define RV_WARP_HASH_INIT 256u

typedef struct rv_ip_slot {
    uint8_t family; /* 0 = empty, AF_INET / AF_INET6 otherwise */
    uint8_t addr[16];
} rv_ip_slot;

typedef struct rv_ipset {
    rv_ip_slot *slots;
    size_t cap;
    size_t count;
} rv_ipset;

typedef struct rv_cidr {
    uint8_t family;
    uint8_t prefix;
    uint8_t addr[16];
} rv_cidr;

typedef struct rv_cidr_list {
    rv_cidr *items;
    size_t count;
    size_t cap;
} rv_cidr_list;

typedef struct rv_warp_data {
    rv_ipset exact;
    rv_cidr_list cidrs;
    char **domains;
    size_t domain_count;
    size_t domain_cap;
} rv_warp_data;

struct rv_warp {
    pthread_rwlock_t lock;
    rv_warp_config cfg;
    rv_warp_data data;
};

static size_t addr_len(int family)
{
    return family == AF_INET ? 4u : 16u;
}

static uint64_t hash_addr(int family, const uint8_t *addr)
{
    uint64_t hash = 1469598103934665603ULL;
    size_t len = addr_len(family);
    size_t i;

    hash ^= (uint64_t)(unsigned)family;
    hash *= 1099511628211ULL;
    for (i = 0; i < len; i++) {
        hash ^= addr[i];
        hash *= 1099511628211ULL;
    }
    return hash;
}

static int ipset_lookup(const rv_ipset *set, int family, const uint8_t *addr)
{
    size_t mask;
    size_t idx;
    size_t len;

    if (set == NULL || set->cap == 0 || set->slots == NULL) {
        return 0;
    }
    len = addr_len(family);
    mask = set->cap - 1;
    idx = (size_t)hash_addr(family, addr) & mask;
    for (;;) {
        const rv_ip_slot *slot = &set->slots[idx];
        if (slot->family == 0) {
            return 0;
        }
        if (slot->family == (uint8_t)family &&
            memcmp(slot->addr, addr, len) == 0) {
            return 1;
        }
        idx = (idx + 1) & mask;
    }
}

static int ipset_grow(rv_ipset *set, size_t new_cap)
{
    rv_ip_slot *slots;
    size_t i;

    slots = calloc(new_cap, sizeof(*slots));
    if (slots == NULL) {
        return -1;
    }
    for (i = 0; i < set->cap; i++) {
        const rv_ip_slot *old = &set->slots[i];
        size_t mask;
        size_t idx;

        if (old->family == 0) {
            continue;
        }
        mask = new_cap - 1;
        idx = (size_t)hash_addr(old->family, old->addr) & mask;
        while (slots[idx].family != 0) {
            idx = (idx + 1) & mask;
        }
        slots[idx] = *old;
    }
    free(set->slots);
    set->slots = slots;
    set->cap = new_cap;
    return 0;
}

static int ipset_insert(rv_ipset *set, int family, const uint8_t *addr)
{
    size_t mask;
    size_t idx;
    size_t len;

    if (set->cap == 0) {
        if (ipset_grow(set, RV_WARP_HASH_INIT) < 0) {
            return -1;
        }
    }
    if (ipset_lookup(set, family, addr)) {
        return 0;
    }
    if ((set->count + 1) * 10 >= set->cap * 7) {
        if (ipset_grow(set, set->cap * 2) < 0) {
            return -1;
        }
    }

    len = addr_len(family);
    mask = set->cap - 1;
    idx = (size_t)hash_addr(family, addr) & mask;
    while (set->slots[idx].family != 0) {
        idx = (idx + 1) & mask;
    }
    set->slots[idx].family = (uint8_t)family;
    memcpy(set->slots[idx].addr, addr, len);
    set->count++;
    return 1;
}

static int cidr_list_add(rv_cidr_list *list, int family, unsigned prefix,
                         const uint8_t *addr)
{
    rv_cidr *items;
    size_t new_cap;
    size_t len = addr_len(family);

    if (list->count == list->cap) {
        new_cap = list->cap == 0 ? 64 : list->cap * 2;
        items = realloc(list->items, new_cap * sizeof(*items));
        if (items == NULL) {
            return -1;
        }
        list->items = items;
        list->cap = new_cap;
    }
    memset(&list->items[list->count], 0, sizeof(list->items[list->count]));
    list->items[list->count].family = (uint8_t)family;
    list->items[list->count].prefix = (uint8_t)prefix;
    memcpy(list->items[list->count].addr, addr, len);
    list->count++;
    return 0;
}

static int cidr_match(const rv_cidr *cidr, int family, const uint8_t *addr)
{
    size_t full;
    unsigned rem;
    uint8_t mask;

    if (cidr->family != (uint8_t)family) {
        return 0;
    }
    full = (size_t)cidr->prefix / 8u;
    rem = (unsigned)cidr->prefix % 8u;
    if (full > 0 && memcmp(cidr->addr, addr, full) != 0) {
        return 0;
    }
    if (rem != 0) {
        mask = (uint8_t)(0xffu << (8u - rem));
        if ((cidr->addr[full] & mask) != (addr[full] & mask)) {
            return 0;
        }
    }
    return 1;
}

static void strip_list_comment(char *s)
{
    size_t i;

    for (i = 0; s[i] != '\0'; i++) {
        if ((s[i] == '#' || s[i] == ';') &&
            (i == 0 || s[i - 1] == ' ' || s[i - 1] == '\t')) {
            s[i] = '\0';
            return;
        }
    }
}

static void data_free(rv_warp_data *data)
{
    size_t i;

    if (data == NULL) {
        return;
    }
    free(data->exact.slots);
    free(data->cidrs.items);
    for (i = 0; i < data->domain_count; i++) {
        free(data->domains[i]);
    }
    free(data->domains);
    memset(data, 0, sizeof(*data));
}

static int data_add_domain_name(rv_warp_data *data, const char *domain)
{
    char **names;
    size_t new_cap;
    char *copy;

    if (data->domain_count >= RV_WARP_MAX_DOMAINS) {
        return 0;
    }
    if (data->domain_count == data->domain_cap) {
        new_cap = data->domain_cap == 0 ? 64 : data->domain_cap * 2;
        names = realloc(data->domains, new_cap * sizeof(*names));
        if (names == NULL) {
            return -1;
        }
        data->domains = names;
        data->domain_cap = new_cap;
    }
    copy = strdup(domain);
    if (copy == NULL) {
        return -1;
    }
    data->domains[data->domain_count++] = copy;
    return 0;
}

static int data_total_ips(const rv_warp_data *data)
{
    return data->exact.count + data->cidrs.count >= RV_WARP_MAX_IPS;
}

static int add_literal_ip(rv_warp_data *data, int family, const uint8_t *addr,
                          unsigned prefix, unsigned max_prefix)
{
    if (family != AF_INET && family != AF_INET6) {
        return -1;
    }
    if (prefix > max_prefix) {
        return -1;
    }
    /* RawVeil uses split routing; a /0 WARP entry would replace the host
     * default route.  Never let a list take the machine offline. */
    if (prefix == 0) {
        LOG_WARN("warp: ignoring %s/0 default route; split routing only",
                 family == AF_INET ? "IPv4" : "IPv6");
        return 0;
    }
    if (data_total_ips(data)) {
        return 0;
    }
    if (prefix == max_prefix) {
        return ipset_insert(&data->exact, family, addr);
    }
    return cidr_list_add(&data->cidrs, family, prefix, addr);
}

static int parse_ip_list_line(rv_warp_data *data, char *line)
{
    char *slash;
    char *addr_text;
    uint8_t addr[16];
    int family;
    unsigned bits;
    unsigned prefix;
    long parsed;
    char *end = NULL;

    addr_text = line;
    slash = strchr(line, '/');
    if (slash != NULL) {
        if (strchr(slash + 1, '/') != NULL) {
            return -1;
        }
        *slash = '\0';
        errno = 0;
        parsed = strtol(slash + 1, &end, 10);
        if (errno != 0 || end == slash + 1 || *end != '\0' ||
            parsed < 0 || parsed > 128) {
            return -1;
        }
        prefix = (unsigned)parsed;
    } else {
        prefix = 0;
    }

    family = AF_INET;
    bits = 32;
    if (inet_pton(AF_INET, addr_text, addr) != 1) {
        family = AF_INET6;
        bits = 128;
        if (inet_pton(AF_INET6, addr_text, addr) != 1) {
            return -1;
        }
    }
    if (slash == NULL) {
        prefix = bits;
    }
    return add_literal_ip(data, family, addr, prefix, bits);
}


static void resolve_domain(rv_warp_data *data, const char *domain)
{
    struct addrinfo hints;
    struct addrinfo *result = NULL;
    struct addrinfo *ai;
    int rc;
    int added = 0;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_NUMERICSERV;

    rc = getaddrinfo(domain, NULL, &hints, &result);
    if (rc != 0) {
        LOG_DEBUG("warp: cannot resolve '%s': %s", domain,
                  gai_strerror(rc));
        return;
    }

    for (ai = result; ai != NULL; ai = ai->ai_next) {
        const uint8_t *addr = NULL;

        if (data_total_ips(data)) {
            LOG_WARN("warp: IP list limit (%u) reached", RV_WARP_MAX_IPS);
            break;
        }
        if (ai->ai_family == AF_INET &&
            ai->ai_addrlen >= sizeof(struct sockaddr_in)) {
            addr = (const uint8_t *)&((const struct sockaddr_in *)
                                      ai->ai_addr)->sin_addr;
        } else if (ai->ai_family == AF_INET6 &&
                   ai->ai_addrlen >= sizeof(struct sockaddr_in6)) {
            addr = (const uint8_t *)&((const struct sockaddr_in6 *)
                                      ai->ai_addr)->sin6_addr;
        }
        if (addr != NULL &&
            ipset_insert(&data->exact, ai->ai_family, addr) >= 0) {
            added++;
        }
    }
    freeaddrinfo(result);

    if (added > 0) {
        LOG_DEBUG("warp: resolved %s -> %d address(es)", domain, added);
    }
}

static void load_ip_list(rv_warp_data *data, const char *path)
{
    FILE *fp;
    char *line = NULL;
    size_t cap = 0;
    ssize_t nread;
    unsigned long lineno = 0;
    size_t added = 0;

    if (path == NULL || *path == '\0') {
        return;
    }
    fp = fopen(path, "r");
    if (fp == NULL) {
        LOG_WARN("warp: cannot open IP list '%s': %s", path,
                 strerror(errno));
        return;
    }

    while ((nread = getline(&line, &cap, fp)) >= 0) {
        char *p;

        (void)nread;
        lineno++;
        strip_list_comment(line);
        p = rv_trim(line);
        if (*p == '\0') {
            continue;
        }
        if (data_total_ips(data)) {
            LOG_WARN("warp: IP list limit (%u) reached, ignoring the rest "
                     "of %s", RV_WARP_MAX_IPS, path);
            break;
        }
        if (parse_ip_list_line(data, p) < 0) {
            LOG_WARN("warp: %s:%lu: invalid IP/CIDR '%s'", path, lineno, p);
            continue;
        }
        added++;
    }
    if (ferror(fp)) {
        LOG_WARN("warp: error reading IP list '%s'", path);
    }
    free(line);
    fclose(fp);
    LOG_INFO("warp: loaded %zu entries from %s", added, path);
}

static void load_domain_list(rv_warp_data *data, const char *path)
{
    FILE *fp;
    char *line = NULL;
    size_t cap = 0;
    ssize_t nread;
    unsigned long lineno = 0;
    size_t domains = 0;

    if (path == NULL || *path == '\0') {
        return;
    }
    fp = fopen(path, "r");
    if (fp == NULL) {
        LOG_WARN("warp: cannot open domain list '%s': %s", path,
                 strerror(errno));
        return;
    }

    while ((nread = getline(&line, &cap, fp)) >= 0) {
        char *p;

        (void)nread;
        lineno++;
        strip_list_comment(line);
        p = rv_trim(line);
        if (*p == '\0') {
            continue;
        }
        if (strlen(p) > 253) {
            LOG_WARN("warp: %s:%lu: domain name too long, ignored", path,
                     lineno);
            continue;
        }
        if (strchr(p, '*') != NULL) {
            LOG_WARN("warp: %s:%lu: wildcard '%s' is not supported, ignored",
                     path, lineno, p);
            continue;
        }
        if (data->domain_count >= RV_WARP_MAX_DOMAINS) {
            LOG_WARN("warp: domain limit (%u) reached, ignoring the rest "
                     "of %s", RV_WARP_MAX_DOMAINS, path);
            break;
        }
        if (data_add_domain_name(data, p) < 0) {
            LOG_WARN("warp: out of memory while storing domain names");
            break;
        }
        resolve_domain(data, p);
        domains++;
    }
    if (ferror(fp)) {
        LOG_WARN("warp: error reading domain list '%s'", path);
    }
    free(line);
    fclose(fp);
    LOG_INFO("warp: resolved %zu domains from %s", domains, path);
}

static int data_build(const rv_warp_config *cfg, rv_warp_data *data,
                      char *err, size_t errlen)
{
    memset(data, 0, sizeof(*data));

    if (!cfg->enabled) {
        LOG_INFO("warp: disabled");
        return 0;
    }

    load_ip_list(data, cfg->ip_list);
    load_domain_list(data, cfg->domain_list);

    if (data->exact.count == 0 && data->cidrs.count == 0) {
        LOG_WARN("warp: enabled, but the destination set is empty");
    } else {
        LOG_INFO("warp: destination set: %zu exact IPs, %zu CIDRs, "
                 "%zu domains; mark=0x%x, interface=%s",
                 data->exact.count, data->cidrs.count, data->domain_count,
                 cfg->mark, cfg->interface);
    }
    (void)err;
    (void)errlen;
    return 0;
}

rv_warp *rv_warp_create(const rv_warp_config *cfg, char *err, size_t errlen)
{
    rv_warp *warp;

    if (cfg == NULL) {
        (void)snprintf(err, errlen, "invalid WARP configuration");
        return NULL;
    }
    warp = calloc(1, sizeof(*warp));
    if (warp == NULL) {
        (void)snprintf(err, errlen, "out of memory");
        return NULL;
    }
    if (pthread_rwlock_init(&warp->lock, NULL) != 0) {
        (void)snprintf(err, errlen, "pthread_rwlock_init failed");
        free(warp);
        return NULL;
    }
    warp->cfg = *cfg;
    if (data_build(cfg, &warp->data, err, errlen) < 0) {
        data_free(&warp->data);
        pthread_rwlock_destroy(&warp->lock);
        free(warp);
        return NULL;
    }
    return warp;
}

int rv_warp_reload(rv_warp *warp, const rv_warp_config *cfg,
                   char *err, size_t errlen)
{
    rv_warp_data new_data;
    rv_warp_data old_data;
    rv_warp_config new_cfg;
    size_t exact_count;
    size_t cidr_count;
    size_t domain_count;

    if (warp == NULL || cfg == NULL) {
        (void)snprintf(err, errlen, "invalid WARP reload arguments");
        return -1;
    }

    new_cfg = *cfg;
    if (data_build(&new_cfg, &new_data, err, errlen) < 0) {
        return -1;
    }

    exact_count = new_data.exact.count;
    cidr_count = new_data.cidrs.count;
    domain_count = new_data.domain_count;

    pthread_rwlock_wrlock(&warp->lock);
    old_data = warp->data;
    warp->data = new_data;
    warp->cfg = new_cfg;
    pthread_rwlock_unlock(&warp->lock);

    data_free(&old_data);
    LOG_INFO("warp: reloaded (%zu exact IPs, %zu CIDRs, %zu domains)",
             exact_count, cidr_count, domain_count);
    return 0;
}

void rv_warp_destroy(rv_warp *warp)
{
    if (warp == NULL) {
        return;
    }
    data_free(&warp->data);
    pthread_rwlock_destroy(&warp->lock);
    free(warp);
}

int rv_warp_should_mark(rv_warp *warp, int family, const void *addr)
{
    int found = 0;
    size_t i;

    if (warp == NULL || addr == NULL) {
        return 0;
    }
    if (family != AF_INET && family != AF_INET6) {
        return 0;
    }

    pthread_rwlock_rdlock(&warp->lock);
    if (warp->cfg.enabled) {
        found = ipset_lookup(&warp->data.exact, family,
                             (const uint8_t *)addr);
        if (!found) {
            for (i = 0; i < warp->data.cidrs.count; i++) {
                if (cidr_match(&warp->data.cidrs.items[i], family,
                               (const uint8_t *)addr)) {
                    found = 1;
                    break;
                }
            }
        }
    }
    pthread_rwlock_unlock(&warp->lock);
    return found;
}

size_t rv_warp_ip_count(rv_warp *warp)
{
    size_t count = 0;

    if (warp == NULL) {
        return 0;
    }
    pthread_rwlock_rdlock(&warp->lock);
    count = warp->data.exact.count + warp->data.cidrs.count;
    pthread_rwlock_unlock(&warp->lock);
    return count;
}

size_t rv_warp_domain_count(rv_warp *warp)
{
    size_t count = 0;

    if (warp == NULL) {
        return 0;
    }
    pthread_rwlock_rdlock(&warp->lock);
    count = warp->data.domain_count;
    pthread_rwlock_unlock(&warp->lock);
    return count;
}

int rv_warp_enabled(rv_warp *warp)
{
    int enabled = 0;

    if (warp == NULL) {
        return 0;
    }
    pthread_rwlock_rdlock(&warp->lock);
    enabled = warp->cfg.enabled;
    pthread_rwlock_unlock(&warp->lock);
    return enabled;
}

int rv_warp_copy_entries(rv_warp *warp, rv_warp_entry **out, size_t *count)
{
    rv_warp_entry *entries;
    size_t total;
    size_t pos = 0;
    size_t i;

    if (out == NULL || count == NULL) {
        return -1;
    }
    *out = NULL;
    *count = 0;
    if (warp == NULL) {
        return 0;
    }

    pthread_rwlock_rdlock(&warp->lock);
    total = warp->data.exact.count + warp->data.cidrs.count;
    if (total == 0) {
        pthread_rwlock_unlock(&warp->lock);
        return 0;
    }
    entries = calloc(total, sizeof(*entries));
    if (entries == NULL) {
        pthread_rwlock_unlock(&warp->lock);
        return -1;
    }
    for (i = 0; i < warp->data.exact.cap; i++) {
        const rv_ip_slot *slot = &warp->data.exact.slots[i];
        if (slot->family == 0) {
            continue;
        }
        if (pos >= total) {
            break;
        }
        entries[pos].family = slot->family;
        entries[pos].prefix = slot->family == AF_INET ? 32 : 128;
        memcpy(entries[pos].addr, slot->addr, addr_len(slot->family));
        pos++;
    }
    for (i = 0; i < warp->data.cidrs.count && pos < total; i++) {
        entries[pos].family = warp->data.cidrs.items[i].family;
        entries[pos].prefix = warp->data.cidrs.items[i].prefix;
        memcpy(entries[pos].addr, warp->data.cidrs.items[i].addr,
               addr_len(entries[pos].family));
        pos++;
    }
    pthread_rwlock_unlock(&warp->lock);

    *out = entries;
    *count = pos;
    return 0;
}


