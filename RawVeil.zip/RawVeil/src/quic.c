#include "quic.h"

#include <string.h>

static int read_varint(const uint8_t *data, size_t len, size_t *pos,
                       uint64_t *value)
{
    size_t prefix;
    size_t need;
    uint64_t v;

    if (data == NULL || pos == NULL || value == NULL || *pos >= len) {
        return -1;
    }
    prefix = (size_t)(data[*pos] >> 6);
    need = (size_t)1u << prefix;
    if (*pos + need > len) {
        return -1;
    }
    v = (uint64_t)(data[*pos] & 0x3fu);
    for (size_t i = 1; i < need; i++) {
        v = (v << 8) | data[*pos + i];
    }
    *pos += need;
    *value = v;
    return 0;
}

static int read_cid(const uint8_t *data, size_t len, size_t *pos,
                    uint8_t *dst, size_t *dst_len)
{
    size_t n;

    if (*pos >= len) {
        return -1;
    }
    n = data[*pos];
    (*pos)++;
    if (n > RV_QUIC_MAX_CID || *pos + n > len) {
        return -1;
    }
    memcpy(dst, data + *pos, n);
    *dst_len = n;
    *pos += n;
    return 0;
}

static int parse_initial_layout(const uint8_t *data, size_t len, size_t pos,
                                uint32_t version, rv_quic_info *info)
{
    uint64_t token_len;
    uint64_t packet_len;
    size_t after_token;
    size_t before_length;
    size_t pn_len;

    before_length = pos;
    if (read_varint(data, len, &pos, &token_len) < 0) {
        return -1;
    }
    if (token_len > len - pos) {
        return -1;
    }
    pos += (size_t)token_len;
    after_token = pos;
    if (read_varint(data, len, &pos, &packet_len) < 0) {
        return -1;
    }
    if (packet_len == 0 || packet_len > len - pos) {
        return -1;
    }
    pn_len = (size_t)(data[0] & 0x03u) + 1u;
    if (packet_len < pn_len) {
        return -1;
    }

    info->version = version;
    info->token_len = token_len;
    info->header_len = pos + pn_len;
    info->packet_len = pos + (size_t)packet_len;
    info->payload_len = (size_t)packet_len - pn_len;
    info->is_initial = 1;
    (void)after_token;
    (void)before_length;
    return 0;
}

int rv_quic_parse(const uint8_t *data, size_t len, rv_quic_info *info)
{
    size_t pos;
    uint32_t version;

    if (info == NULL) {
        return -1;
    }
    memset(info, 0, sizeof(*info));
    if (data == NULL || len < 1) {
        return 0;
    }

    if ((data[0] & 0x80u) == 0) {
        /* Short header: the fixed bit must be set. DCID length is not
         * signalled on the wire; callers that need it must use flow state. */
        if ((data[0] & 0x40u) == 0) {
            return 0;
        }
        info->is_short = 1;
        info->header_len = 1;
        info->packet_len = len;
        info->payload_len = len - 1;
        return 1;
    }

    if ((data[0] & 0x40u) == 0 || len < 7) {
        return 0;
    }
    version = ((uint32_t)data[1] << 24) | ((uint32_t)data[2] << 16) |
              ((uint32_t)data[3] << 8) | (uint32_t)data[4];
    info->is_long = 1;
    info->version = version;
    pos = 5;
    if (read_cid(data, len, &pos, info->dcid, &info->dcid_len) < 0 ||
        read_cid(data, len, &pos, info->scid, &info->scid_len) < 0) {
        return -1;
    }

    if (version == 0) {
        info->is_version_negotiation = 1;
        info->header_len = pos;
        info->packet_len = len;
        info->payload_len = len - pos;
        return 1;
    }

    if (parse_initial_layout(data, len, pos, version, info) == 0 &&
        (len >= 1200u || info->token_len > 0)) {
        return 1;
    }

    /* Handshake / 0-RTT / Retry, or an Initial whose header protection
     * prevents an exact length parse. Keep the long-header classification. */
    memset(info, 0, sizeof(*info));
    info->is_long = 1;
    info->version = version;
    pos = 5;
    if (read_cid(data, len, &pos, info->dcid, &info->dcid_len) < 0 ||
        read_cid(data, len, &pos, info->scid, &info->scid_len) < 0) {
        return -1;
    }
    info->header_len = pos;
    info->packet_len = len;
    info->payload_len = len - pos;
    return 1;
}
