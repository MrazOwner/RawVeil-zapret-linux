#include "sender.h"

#include <arpa/inet.h>
#include <errno.h>
#include <linux/if_ether.h>
#include <linux/if_packet.h>
#include <net/if.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <unistd.h>

#include "common.h"
#include "log.h"

#define RV_SENDER_BATCH_MAX 64

struct rv_sender {
    int fd;
    unsigned int ifindex;
    unsigned int mtu;
    char ifname[16];
};

rv_sender *rv_sender_create(const char *ifname, char *err, size_t errlen)
{
    rv_sender *sender;
    struct sockaddr_ll sll;

    if (err != NULL && errlen > 0) {
        err[0] = '\0';
    }
    if (ifname == NULL || *ifname == '\0' || strlen(ifname) >= 16) {
        (void)snprintf(err, errlen, "invalid interface name");
        return NULL;
    }

    sender = calloc(1, sizeof(*sender));
    if (sender == NULL) {
        (void)snprintf(err, errlen, "out of memory");
        return NULL;
    }
    sender->fd = -1;
    sender->mtu = 1500;
    rv_strlcpy(sender->ifname, sizeof(sender->ifname), ifname);

    sender->ifindex = if_nametoindex(ifname);
    if (sender->ifindex == 0) {
        (void)snprintf(err, errlen, "unknown interface '%s': %s",
                       ifname, strerror(errno));
        free(sender);
        return NULL;
    }

    sender->fd = socket(AF_PACKET, SOCK_RAW | SOCK_CLOEXEC,
                        htons(ETH_P_ALL));
    if (sender->fd < 0) {
        (void)snprintf(err, errlen,
                       "socket(AF_PACKET, TX) failed: %s "
                       "(CAP_NET_RAW or root is required)", strerror(errno));
        free(sender);
        return NULL;
    }

    memset(&sll, 0, sizeof(sll));
    sll.sll_family = AF_PACKET;
    sll.sll_protocol = htons(ETH_P_ALL);
    sll.sll_ifindex = (int)sender->ifindex;
    if (bind(sender->fd, (struct sockaddr *)&sll, sizeof(sll)) < 0) {
        (void)snprintf(err, errlen, "bind(AF_PACKET TX, %s): %s",
                       ifname, strerror(errno));
        rv_sender_destroy(sender);
        return NULL;
    }

    {
        struct ifreq ifr;

        memset(&ifr, 0, sizeof(ifr));
        rv_strlcpy(ifr.ifr_name, sizeof(ifr.ifr_name), ifname);
        if (ioctl(sender->fd, SIOCGIFMTU, &ifr) == 0 && ifr.ifr_mtu > 0) {
            sender->mtu = (unsigned int)ifr.ifr_mtu;
        } else {
            LOG_WARN("cannot read MTU for %s, assuming 1500", ifname);
        }
    }
    return sender;
}

unsigned int rv_sender_mtu(const rv_sender *sender)
{
    if (sender == NULL || sender->mtu < 576) {
        return 1500;
    }
    return sender->mtu;
}

void rv_sender_destroy(rv_sender *sender)
{
    if (sender == NULL) {
        return;
    }
    if (sender->fd >= 0) {
        close(sender->fd);
    }
    free(sender);
}

int rv_sender_send_batch(rv_sender *sender, const rv_tx_frame *frames,
                         size_t count)
{
    struct mmsghdr msgs[RV_SENDER_BATCH_MAX];
    struct iovec iov[RV_SENDER_BATCH_MAX];
    struct sockaddr_ll addrs[RV_SENDER_BATCH_MAX];
    size_t i;
    int sent;

    if (sender == NULL || frames == NULL || count == 0) {
        return -1;
    }
    if (count > RV_SENDER_BATCH_MAX) {
        count = RV_SENDER_BATCH_MAX;
    }

    memset(msgs, 0, sizeof(msgs));
    memset(iov, 0, sizeof(iov));
    memset(addrs, 0, sizeof(addrs));

    for (i = 0; i < count; i++) {
        if (frames[i].data == NULL || frames[i].len < ETH_HLEN) {
            return -1;
        }
        iov[i].iov_base = (void *)frames[i].data;
        iov[i].iov_len = frames[i].len;

        addrs[i].sll_family = AF_PACKET;
        /*
         * packet_snd() copies sll_protocol into skb->protocol.  ETH_P_ALL
         * is a socket reception filter value, not a valid on-wire protocol;
         * use the EtherType carried by the frame itself so the peer stack
         * (veth, bridge, physical NIC) sees IPv4/IPv6/VLAN correctly.
         */
        addrs[i].sll_protocol =
            htons((uint16_t)(((uint16_t)frames[i].data[12] << 8) |
                             frames[i].data[13]));
        addrs[i].sll_ifindex = (int)sender->ifindex;
        addrs[i].sll_halen = ETH_ALEN;
        memcpy(addrs[i].sll_addr, frames[i].data, ETH_ALEN);

        msgs[i].msg_hdr.msg_name = &addrs[i];
        msgs[i].msg_hdr.msg_namelen = sizeof(addrs[i]);
        msgs[i].msg_hdr.msg_iov = &iov[i];
        msgs[i].msg_hdr.msg_iovlen = 1;
    }

    sent = sendmmsg(sender->fd, msgs, (unsigned int)count, 0);
    if (sent < 0) {
        if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK) {
            return 0;
        }
        return -1;
    }
    return sent;
}
