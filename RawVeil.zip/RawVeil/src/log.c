#include "log.h"

#include "common.h"

#include <errno.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <syslog.h>
#include <time.h>

#define RV_LOG_BUF 2048

static pthread_mutex_t g_log_mutex = PTHREAD_MUTEX_INITIALIZER;
static rv_log_level g_log_level = RV_LOG_INFO;
static int g_use_syslog = 0;
static int g_syslog_open = 0;

int rv_log_level_parse(const char *name, rv_log_level *out)
{
    if (name == NULL || out == NULL) {
        return -1;
    }
    if (strcasecmp(name, "debug") == 0) {
        *out = RV_LOG_DEBUG;
    } else if (strcasecmp(name, "info") == 0) {
        *out = RV_LOG_INFO;
    } else if (strcasecmp(name, "warn") == 0 ||
               strcasecmp(name, "warning") == 0) {
        *out = RV_LOG_WARN;
    } else if (strcasecmp(name, "error") == 0 ||
               strcasecmp(name, "err") == 0) {
        *out = RV_LOG_ERROR;
    } else {
        return -1;
    }
    return 0;
}

const char *rv_log_level_name(rv_log_level level)
{
    switch (level) {
    case RV_LOG_DEBUG:
        return "debug";
    case RV_LOG_INFO:
        return "info";
    case RV_LOG_WARN:
        return "warn";
    case RV_LOG_ERROR:
        return "error";
    default:
        return "unknown";
    }
}

int rv_log_init(rv_log_level level, int use_syslog, const char *ident)
{
    pthread_mutex_lock(&g_log_mutex);
    g_log_level = level;
    if (use_syslog) {
        if (!g_syslog_open) {
            openlog(ident != NULL ? ident : RV_PROGRAM_NAME,
                    LOG_PID | LOG_NDELAY, LOG_DAEMON);
            g_syslog_open = 1;
        }
    } else if (g_syslog_open) {
        closelog();
        g_syslog_open = 0;
    }
    g_use_syslog = use_syslog ? 1 : 0;
    pthread_mutex_unlock(&g_log_mutex);
    return 0;
}

void rv_log_shutdown(void)
{
    pthread_mutex_lock(&g_log_mutex);
    if (g_syslog_open) {
        closelog();
        g_syslog_open = 0;
    }
    g_use_syslog = 0;
    pthread_mutex_unlock(&g_log_mutex);
}

void rv_log_set_level(rv_log_level level)
{
    pthread_mutex_lock(&g_log_mutex);
    g_log_level = level;
    pthread_mutex_unlock(&g_log_mutex);
}

rv_log_level rv_log_get_level(void)
{
    rv_log_level level;

    pthread_mutex_lock(&g_log_mutex);
    level = g_log_level;
    pthread_mutex_unlock(&g_log_mutex);
    return level;
}

static int syslog_priority(rv_log_level level)
{
    switch (level) {
    case RV_LOG_DEBUG:
        return LOG_DEBUG;
    case RV_LOG_INFO:
        return LOG_INFO;
    case RV_LOG_WARN:
        return LOG_WARNING;
    case RV_LOG_ERROR:
        return LOG_ERR;
    default:
        return LOG_INFO;
    }
}

void rv_log(rv_log_level level, const char *fmt, ...)
{
    char msg[RV_LOG_BUF];
    char stamp[64];
    struct timespec ts = {0, 0};
    struct tm tm_now;
    va_list ap;
    int saved_errno = errno;

    if (fmt == NULL) {
        return;
    }

    pthread_mutex_lock(&g_log_mutex);
    if (level < g_log_level) {
        pthread_mutex_unlock(&g_log_mutex);
        return;
    }

    va_start(ap, fmt);
    (void)vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);

    if (g_use_syslog) {
        syslog(syslog_priority(level), "%s", msg);
        pthread_mutex_unlock(&g_log_mutex);
        errno = saved_errno;
        return;
    }

    stamp[0] = '\0';
    if (clock_gettime(CLOCK_REALTIME, &ts) == 0 &&
        localtime_r(&ts.tv_sec, &tm_now) != NULL) {
        (void)strftime(stamp, sizeof(stamp), "%Y-%m-%d %H:%M:%S", &tm_now);
    }
    fprintf(stderr, "%s.%03ld [%s] %s\n",
            stamp[0] != '\0' ? stamp : "-",
            ts.tv_nsec / 1000000L,
            rv_log_level_name(level), msg);
    fflush(stderr);

    pthread_mutex_unlock(&g_log_mutex);
    errno = saved_errno;
}
