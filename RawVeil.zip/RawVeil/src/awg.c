#include "awg.h"

#include "log.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <net/if.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

static void set_err(char *err, size_t errlen, const char *fmt, ...)
    __attribute__((format(printf, 3, 4)));

static void set_err(char *err, size_t errlen, const char *fmt, ...)
{
    va_list ap;

    if (err == NULL || errlen == 0) {
        return;
    }
    va_start(ap, fmt);
    (void)vsnprintf(err, errlen, fmt, ap);
    va_end(ap);
}

static void strip_comment(char *s)
{
    size_t i;

    for (i = 0; s[i] != '\0'; i++) {
        if ((s[i] == '#' || s[i] == ';') &&
            (i == 0 || s[i - 1] == ' ' || s[i - 1] == '\t')) {
            s[i] = '\0';
            return;
        }
    }
}

static void derive_interface(const char *path, char *out, size_t outsz)
{
    const char *base = strrchr(path, '/');
    const char *dot;
    size_t len;

    base = base != NULL ? base + 1 : path;
    dot = strrchr(base, '.');
    if (dot != NULL && strcasecmp(dot, ".conf") == 0) {
        len = (size_t)(dot - base);
    } else {
        len = strlen(base);
    }
    if (len >= outsz) {
        len = outsz - 1;
    }
    memcpy(out, base, len);
    out[len] = '\0';
}

static int parse_address_list(const char *value, rv_awg_config *out)
{
    char buf[RV_MAX_STR * 2];
    char *save = NULL;
    char *token;

    if (strlen(value) >= sizeof(buf)) {
        return -1;
    }
    rv_strlcpy(buf, sizeof(buf), value);
    for (token = strtok_r(buf, ",", &save); token != NULL;
         token = strtok_r(NULL, ",", &save)) {
        char *slash;
        unsigned char addr[16];
        int family;

        token = rv_trim(token);
        if (*token == '\0') {
            continue;
        }
        slash = strchr(token, '/');
        if (slash != NULL) {
            *slash = '\0';
        }
        family = strchr(token, ':') != NULL ? AF_INET6 : AF_INET;
        if (inet_pton(family, token, addr) == 1) {
            if (family == AF_INET) {
                out->has_ipv4 = 1;
            } else {
                out->has_ipv6 = 1;
            }
        }
    }
    return 0;
}

static int parse_allowed_ips(const char *value, rv_awg_config *out)
{
    char buf[RV_MAX_STR * 2];
    char *save = NULL;
    char *token;

    if (strlen(value) >= sizeof(buf)) {
        return -1;
    }
    rv_strlcpy(buf, sizeof(buf), value);
    for (token = strtok_r(buf, ",", &save); token != NULL;
         token = strtok_r(NULL, ",", &save)) {
        token = rv_trim(token);
        if (strcasecmp(token, "0.0.0.0/0") == 0 ||
            strcmp(token, "0.0.0.0") == 0) {
            out->default_route_v4 = 1;
        } else if (strcasecmp(token, "::/0") == 0 ||
                   strcmp(token, "::") == 0) {
            out->default_route_v6 = 1;
        }
    }
    return 0;
}

int rv_awg_load(const char *path, rv_awg_config *out,
                char *err, size_t errlen)
{
    FILE *fp;
    char *line = NULL;
    size_t cap = 0;
    ssize_t nread;
    unsigned long lineno = 0;
    int in_interface = 0;
    int in_peer = 0;
    int ret = 0;

    if (out == NULL || path == NULL || *path == '\0') {
        set_err(err, errlen, "invalid AWG config path");
        return -1;
    }
    memset(out, 0, sizeof(*out));
    out->fwmark = -1;
    rv_strlcpy(out->path, sizeof(out->path), path);
    derive_interface(path, out->interface, sizeof(out->interface));
    if (out->interface[0] == '\0' || strlen(out->interface) >= RV_IFNAMSIZ) {
        set_err(err, errlen, "cannot derive AWG interface from '%s'", path);
        return -1;
    }

    fp = fopen(path, "r");
    if (fp == NULL) {
        set_err(err, errlen, "cannot open AWG config '%s': %s",
                path, strerror(errno));
        return -1;
    }

    while ((nread = getline(&line, &cap, fp)) >= 0) {
        char *p;
        char *eq;
        char *key;
        char *value;
        long parsed;
        char *end = NULL;

        (void)nread;
        lineno++;
        strip_comment(line);
        p = rv_trim(line);
        if (*p == '\0') {
            continue;
        }
        if (*p == '[') {
            char *close = strchr(p, ']');
            if (close == NULL) {
                set_err(err, errlen, "%s:%lu: unterminated section",
                        path, lineno);
                ret = -1;
                break;
            }
            *close = '\0';
            p = rv_trim(p + 1);
            in_interface = strcasecmp(p, "Interface") == 0;
            in_peer = strcasecmp(p, "Peer") == 0;
            continue;
        }
        eq = strchr(p, '=');
        if (eq == NULL) {
            continue;
        }
        *eq = '\0';
        key = rv_trim(p);
        value = rv_trim(eq + 1);
        if (!in_interface && !in_peer) {
            continue;
        }

        if (in_interface && strcasecmp(key, "Address") == 0) {
            if (strlen(value) >= sizeof(out->address) ||
                parse_address_list(value, out) < 0) {
                set_err(err, errlen, "%s:%lu: invalid Address",
                        path, lineno);
                ret = -1;
                break;
            }
            rv_strlcpy(out->address, sizeof(out->address), value);
        } else if (in_interface && strcasecmp(key, "MTU") == 0) {
            errno = 0;
            parsed = strtol(value, &end, 10);
            if (errno != 0 || end == value || *end != '\0' ||
                parsed < 576 || parsed > 65535) {
                set_err(err, errlen, "%s:%lu: invalid MTU", path, lineno);
                ret = -1;
                break;
            }
            out->mtu = (int)parsed;
        } else if (in_interface && strcasecmp(key, "Table") == 0) {
            rv_strlcpy(out->table, sizeof(out->table), value);
        } else if (in_interface && strcasecmp(key, "FwMark") == 0) {
            errno = 0;
            parsed = strtol(value, &end, 0);
            if (errno != 0 || end == value || *end != '\0' ||
                parsed < 0) {
                set_err(err, errlen, "%s:%lu: invalid FwMark", path, lineno);
                ret = -1;
                break;
            }
            out->fwmark = (int)parsed;
        } else if (in_peer && strcasecmp(key, "AllowedIPs") == 0) {
            if (strlen(value) >= sizeof(out->allowed_ips) ||
                parse_allowed_ips(value, out) < 0) {
                set_err(err, errlen, "%s:%lu: invalid AllowedIPs",
                        path, lineno);
                ret = -1;
                break;
            }
            rv_strlcpy(out->allowed_ips, sizeof(out->allowed_ips), value);
        }
    }
    free(line);
    if (ferror(fp)) {
        set_err(err, errlen, "error reading AWG config '%s'", path);
        ret = -1;
    }
    fclose(fp);
    if (ret == 0) {
        if (!out->has_ipv4 && !out->has_ipv6) {
            LOG_WARN("AWG config '%s': no usable [Interface] Address", path);
        }
        if (out->allowed_ips[0] == '\0') {
            LOG_WARN("AWG config '%s': no [Peer] AllowedIPs", path);
        }
    }
    return ret;
}

int rv_awg_interface_index(const rv_awg_config *cfg)
{
    if (cfg == NULL) {
        return 0;
    }
    return (int)if_nametoindex(cfg->interface);
}
