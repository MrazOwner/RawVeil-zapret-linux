#include "l7.h"

#include <string.h>

int rv_l7_tls_clienthello(const uint8_t *data, size_t len,
                          rv_tls_info *tls)
{
    rv_tls_info local;
    int rc;

    if (tls == NULL) {
        tls = &local;
    }
    rc = rv_tls_parse_client_hello(data, len, tls);
    return rc == 1;
}

int rv_l7_tls_clienthello_start(const uint8_t *data, size_t len)
{
    if (data == NULL || len < 6) {
        return 0;
    }
    return data[0] == 0x16 && data[1] == 0x03 && data[5] == 0x01;
}

int rv_l7_is_quic_initial(const uint8_t *data, size_t len)
{
    uint32_t version;

    if (data == NULL || len < 7) {
        return 0;
    }
    /* Long header form + fixed bit. Header protection masks the packet type
     * bits, so Initial/Handshake cannot be distinguished reliably without
     * QUIC keys; a non-zero long-header version on UDP/443 is the useful DPI
     * signal here. */
    if ((data[0] & 0x80u) == 0 || (data[0] & 0x40u) == 0) {
        return 0;
    }
    version = ((uint32_t)data[1] << 24) | ((uint32_t)data[2] << 16) |
              ((uint32_t)data[3] << 8) | (uint32_t)data[4];
    return version != 0;
}

int rv_l7_is_stun(const uint8_t *data, size_t len)
{
    if (data == NULL || len < 20) {
        return 0;
    }
    /* Top two bits of a STUN message are zero; magic cookie follows the
     * 20-bit transaction ID prefix. */
    if ((data[0] & 0xc0u) != 0) {
        return 0;
    }
    return data[4] == 0x21 && data[5] == 0x12 &&
           data[6] == 0xa4 && data[7] == 0x42;
}

int rv_l7_is_rtp(const uint8_t *data, size_t len)
{
    if (data == NULL || len < 12) {
        return 0;
    }
    return (data[0] & 0xc0u) == 0x80u;
}

unsigned rv_l7_detect_udp(const uint8_t *data, size_t len)
{
    unsigned mask = 0;

    if (data == NULL) {
        return 0;
    }
    if (rv_l7_is_quic_initial(data, len)) {
        mask |= RV_L7_QUIC;
    }
    if (rv_l7_is_stun(data, len)) {
        mask |= RV_L7_STUN;
    }
    if (rv_l7_is_rtp(data, len)) {
        mask |= RV_L7_RTP;
    }
    (void)len;
    return mask;
}
