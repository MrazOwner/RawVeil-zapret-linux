#include "l7.h"
#include "quic.h"

#include <string.h>

int rv_l7_tls_clienthello(const uint8_t *data, size_t len,
                          rv_tls_info *tls)
{
    rv_tls_info local;
    int rc;

    if (tls == NULL) {
        tls = &local;
    }
    rc = rv_tls_parse_client_hello(data, len, tls);
    return rc == 1;
}

int rv_l7_tls_clienthello_start(const uint8_t *data, size_t len)
{
    if (data == NULL || len < 6) {
        return 0;
    }
    return data[0] == 0x16 && data[1] == 0x03 && data[5] == 0x01;
}

int rv_l7_is_quic_initial(const uint8_t *data, size_t len)
{
    rv_quic_info info;

    if (rv_quic_parse(data, len, &info) != 1) {
        return 0;
    }
    return info.is_initial;
}

int rv_l7_is_stun(const uint8_t *data, size_t len)
{
    if (data == NULL || len < 20) {
        return 0;
    }
    /* Top two bits of a STUN message are zero; magic cookie follows the
     * 20-bit transaction ID prefix. */
    if ((data[0] & 0xc0u) != 0) {
        return 0;
    }
    return data[4] == 0x21 && data[5] == 0x12 &&
           data[6] == 0xa4 && data[7] == 0x42;
}

int rv_l7_is_rtp(const uint8_t *data, size_t len)
{
    if (data == NULL || len < 12) {
        return 0;
    }
    return (data[0] & 0xc0u) == 0x80u;
}

unsigned rv_l7_detect_udp(const uint8_t *data, size_t len)
{
    unsigned mask = 0;
    rv_quic_info quic;

    if (data == NULL) {
        return 0;
    }
    if (rv_quic_parse(data, len, &quic) == 1) {
        mask |= RV_L7_QUIC;
        if (quic.is_initial) {
            mask |= RV_L7_QUIC_INITIAL;
        }
    }
    if (rv_l7_is_stun(data, len)) {
        mask |= RV_L7_STUN;
    }
    if (rv_l7_is_rtp(data, len)) {
        mask |= RV_L7_RTP;
    }
    (void)len;
    return mask;
}
