#include "packet.h"

#include <linux/if_ether.h>
#include <netinet/in.h>
#include <string.h>

#define ETH_TYPE_IPV4_ 0x0800u
#define ETH_TYPE_IPV6_ 0x86ddu
#define ETH_VLAN_ 0x8100u
#define ETH_QINQ_ 0x88a8u

static uint16_t read_be16(const uint8_t *p)
{
    return (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
}

static int parse_l4(rv_packet *pkt, const uint8_t *buf, size_t len)
{
    size_t l4_avail;

    if (pkt->l4_off > pkt->l2_len + pkt->l3_len) {
        return -1;
    }
    l4_avail = pkt->l2_len + pkt->l3_len - pkt->l4_off;

    if (pkt->proto == IPPROTO_TCP) {
        size_t hdr_len;

        if (l4_avail < 20) {
            return -1;
        }
        hdr_len = (size_t)(buf[pkt->l4_off + 12] >> 4) * 4u;
        if (hdr_len < 20 || hdr_len > l4_avail) {
            return -1;
        }
        pkt->l4_hdr_len = hdr_len;
        pkt->sport = read_be16(buf + pkt->l4_off);
        pkt->dport = read_be16(buf + pkt->l4_off + 2);
        pkt->tcp_seq = ((uint32_t)buf[pkt->l4_off + 4] << 24) |
                       ((uint32_t)buf[pkt->l4_off + 5] << 16) |
                       ((uint32_t)buf[pkt->l4_off + 6] << 8) |
                       (uint32_t)buf[pkt->l4_off + 7];
        pkt->tcp_ack = ((uint32_t)buf[pkt->l4_off + 8] << 24) |
                       ((uint32_t)buf[pkt->l4_off + 9] << 16) |
                       ((uint32_t)buf[pkt->l4_off + 10] << 8) |
                       (uint32_t)buf[pkt->l4_off + 11];
        pkt->tcp_flags = buf[pkt->l4_off + 13];
        pkt->has_ports = 1;
    } else if (pkt->proto == IPPROTO_UDP) {
        if (l4_avail < 8) {
            return -1;
        }
        pkt->l4_hdr_len = 8;
        pkt->sport = read_be16(buf + pkt->l4_off);
        pkt->dport = read_be16(buf + pkt->l4_off + 2);
        pkt->has_ports = 1;
    } else {
        pkt->l4_hdr_len = 0;
        pkt->has_ports = 0;
        pkt->payload_off = pkt->l4_off;
        pkt->payload_len = l4_avail;
        return 0;
    }

    pkt->payload_off = pkt->l4_off + pkt->l4_hdr_len;
    pkt->payload_len = l4_avail - pkt->l4_hdr_len;
    (void)len;
    return 0;
}

int rv_packet_parse(rv_packet *pkt, const uint8_t *buf, size_t len)
{
    uint16_t ethertype;
    size_t off = ETH_HLEN;
    int tags = 0;
    size_t ihl;
    size_t total;
    size_t captured;
    uint16_t frag;

    if (pkt == NULL || buf == NULL) {
        return -1;
    }
    memset(pkt, 0, sizeof(*pkt));
    if (len < ETH_HLEN) {
        return -1;
    }
    ethertype = read_be16(buf + 12);

    while ((ethertype == ETH_VLAN_ || ethertype == ETH_QINQ_) && tags < 2) {
        if (len < off + 4) {
            return -1;
        }
        ethertype = read_be16(buf + off + 2);
        off += 4;
        tags++;
    }
    pkt->l2_len = off;

    if (ethertype == ETH_TYPE_IPV4_) {
        if (len < off + 20) {
            return -1;
        }
        if ((buf[off] >> 4) != 4) {
            return -1;
        }
        ihl = (size_t)(buf[off] & 0x0fu) * 4u;
        if (ihl < 20 || len < off + ihl) {
            return -1;
        }
        total = read_be16(buf + off + 2);
        if (total < ihl) {
            return -1;
        }
        captured = len - off;
        pkt->truncated = total > captured;
        pkt->l3_len = total > captured ? captured : total;
        pkt->l3_hdr_len = ihl;
        pkt->l4_off = off + ihl;
        pkt->family = AF_INET;
        pkt->proto = buf[off + 9];
        pkt->ttl = buf[off + 8];
        pkt->ip_id = read_be16(buf + off + 4);
        memcpy(pkt->src, buf + off + 12, 4);
        memcpy(pkt->dst, buf + off + 16, 4);

        frag = read_be16(buf + off + 6);
        /* MF must count too: the first fragment has offset 0 but is still
         * incomplete. */
        pkt->ip_fragmented = (frag & 0x3fffu) != 0 ||
                             (frag & 0x2000u) != 0;
        pkt->sent_by_us = pkt->ip_id == RV_SENT_MARKER;

        return parse_l4(pkt, buf, len) == 0 ? 1 : -1;
    }

    if (ethertype == ETH_TYPE_IPV6_) {
        uint32_t first_word;
        size_t payload_len;
        size_t total6;

        if (len < off + 40) {
            return -1;
        }
        if ((buf[off] >> 4) != 6) {
            return -1;
        }
        payload_len = read_be16(buf + off + 4);
        total6 = 40u + payload_len;
        captured = len - off;
        pkt->truncated = total6 > captured;
        pkt->l3_len = total6 > captured ? captured : total6;
        pkt->l3_hdr_len = 40;
        pkt->l4_off = off + 40;
        pkt->family = AF_INET6;
        pkt->proto = buf[off + 6];
        pkt->ttl = buf[off + 7];
        memcpy(pkt->src, buf + off + 8, 16);
        memcpy(pkt->dst, buf + off + 24, 16);

        first_word = ((uint32_t)buf[off] << 24) |
                     ((uint32_t)buf[off + 1] << 16) |
                     ((uint32_t)buf[off + 2] << 8) |
                     (uint32_t)buf[off + 3];
        pkt->flow_label = first_word & 0xFFFFFu;
        pkt->sent_by_us = pkt->flow_label == RV_SENT_MARKER;

        return parse_l4(pkt, buf, len) == 0 ? 1 : -1;
    }

    return 0;
}
