#include "tracker.h"

#include <netinet/in.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

#define RV_TRACKER_MIN_BUCKETS 256u
#define RV_TRACKER_MAX_BUCKETS 65536u
#define RV_TRACKER_ENTRIES_PER_BUCKET 16u

typedef struct tracker_entry {
    rv_flow_key key;
    rv_tracker_view view;
    struct tracker_entry *next;
} tracker_entry;

typedef struct tracker_bucket {
    tracker_entry *head;
    pthread_mutex_t lock;
} tracker_bucket;

struct rv_tracker {
    tracker_bucket *buckets;
    size_t bucket_count;
    size_t max_entries;
    int tcp_timeout;
    int udp_timeout;
    pthread_mutex_t meta;
    size_t count;
};

static size_t addr_len(int family)
{
    return family == AF_INET ? 4u : 16u;
}

static uint64_t hash_key(const rv_flow_key *key)
{
    uint64_t hash = 1469598103934665603ULL;
    size_t len = addr_len(key->family);
    size_t i;

    hash ^= (uint64_t)(unsigned)key->family;
    hash *= 1099511628211ULL;
    hash ^= (uint64_t)(unsigned)key->proto;
    hash *= 1099511628211ULL;
    for (i = 0; i < len; i++) {
        hash ^= key->src[i];
        hash *= 1099511628211ULL;
        hash ^= key->dst[i];
        hash *= 1099511628211ULL;
    }
    hash ^= (uint64_t)key->sport;
    hash *= 1099511628211ULL;
    hash ^= (uint64_t)key->dport;
    hash *= 1099511628211ULL;
    return hash;
}

static int key_equal(const rv_flow_key *a, const rv_flow_key *b)
{
    return a->family == b->family && a->proto == b->proto &&
           a->sport == b->sport && a->dport == b->dport &&
           memcmp(a->src, b->src, addr_len(a->family)) == 0 &&
           memcmp(a->dst, b->dst, addr_len(a->family)) == 0;
}

static size_t next_power_of_two(size_t value)
{
    size_t result = RV_TRACKER_MIN_BUCKETS;

    while (result < value && result < RV_TRACKER_MAX_BUCKETS) {
        result <<= 1;
    }
    return result;
}

rv_tracker *rv_tracker_create(int max_entries, int tcp_timeout,
                              int udp_timeout)
{
    rv_tracker *tracker;
    size_t i;
    size_t wanted;

    if (max_entries < 1) {
        return NULL;
    }
    tracker = calloc(1, sizeof(*tracker));
    if (tracker == NULL) {
        return NULL;
    }
    wanted = (size_t)max_entries / RV_TRACKER_ENTRIES_PER_BUCKET + 1u;
    tracker->bucket_count = next_power_of_two(wanted);
    tracker->max_entries = (size_t)max_entries;
    tracker->tcp_timeout = tcp_timeout;
    tracker->udp_timeout = udp_timeout;
    tracker->buckets = calloc(tracker->bucket_count,
                              sizeof(*tracker->buckets));
    if (tracker->buckets == NULL) {
        free(tracker);
        return NULL;
    }
    for (i = 0; i < tracker->bucket_count; i++) {
        if (pthread_mutex_init(&tracker->buckets[i].lock, NULL) != 0) {
            while (i > 0) {
                i--;
                pthread_mutex_destroy(&tracker->buckets[i].lock);
            }
            free(tracker->buckets);
            free(tracker);
            return NULL;
        }
    }
    if (pthread_mutex_init(&tracker->meta, NULL) != 0) {
        for (i = 0; i < tracker->bucket_count; i++) {
            pthread_mutex_destroy(&tracker->buckets[i].lock);
        }
        free(tracker->buckets);
        free(tracker);
        return NULL;
    }
    return tracker;
}

void rv_tracker_destroy(rv_tracker *tracker)
{
    size_t i;

    if (tracker == NULL) {
        return;
    }
    for (i = 0; i < tracker->bucket_count; i++) {
        tracker_entry *entry = tracker->buckets[i].head;
        while (entry != NULL) {
            tracker_entry *next = entry->next;
            free(entry);
            entry = next;
        }
        pthread_mutex_destroy(&tracker->buckets[i].lock);
    }
    pthread_mutex_destroy(&tracker->meta);
    free(tracker->buckets);
    free(tracker);
}

void rv_tracker_clear(rv_tracker *tracker)
{
    size_t i;

    if (tracker == NULL) {
        return;
    }
    for (i = 0; i < tracker->bucket_count; i++) {
        tracker_entry *entry;
        pthread_mutex_lock(&tracker->buckets[i].lock);
        entry = tracker->buckets[i].head;
        tracker->buckets[i].head = NULL;
        pthread_mutex_unlock(&tracker->buckets[i].lock);
        while (entry != NULL) {
            tracker_entry *next = entry->next;
            free(entry);
            entry = next;
        }
    }
    pthread_mutex_lock(&tracker->meta);
    tracker->count = 0;
    pthread_mutex_unlock(&tracker->meta);
}

static int entry_expired(const rv_tracker *tracker,
                         const tracker_entry *entry, time_t now)
{
    int timeout = entry->key.proto == IPPROTO_TCP
                      ? tracker->tcp_timeout : tracker->udp_timeout;
    return timeout > 0 && now - entry->view.last_seen > timeout;
}

int rv_tracker_touch(rv_tracker *tracker, const rv_flow_key *key,
                     time_t now, rv_tracker_view *out)
{
    size_t idx;
    tracker_bucket *bucket;
    tracker_entry *entry;
    int is_new = 0;

    if (tracker == NULL || key == NULL || out == NULL) {
        return -1;
    }
    idx = (size_t)hash_key(key) & (tracker->bucket_count - 1);
    bucket = &tracker->buckets[idx];

    pthread_mutex_lock(&bucket->lock);
    for (entry = bucket->head; entry != NULL; entry = entry->next) {
        if (key_equal(&entry->key, key)) {
            if (entry_expired(tracker, entry, now)) {
                memset(&entry->view, 0, sizeof(entry->view));
                entry->view.first_seen = now;
                is_new = 1;
            }
            entry->view.packets_seen++;
            entry->view.last_seen = now;
            *out = entry->view;
            pthread_mutex_unlock(&bucket->lock);
            return is_new;
        }
    }

    pthread_mutex_lock(&tracker->meta);
    if (tracker->count >= tracker->max_entries) {
        tracker_entry *oldest = NULL;
        tracker_entry *prev = NULL;
        tracker_entry *oldest_prev = NULL;
        tracker_entry *cursor = bucket->head;

        while (cursor != NULL) {
            if (oldest == NULL ||
                cursor->view.last_seen < oldest->view.last_seen) {
                oldest = cursor;
                oldest_prev = prev;
            }
            prev = cursor;
            cursor = cursor->next;
        }
        if (oldest == NULL) {
            pthread_mutex_unlock(&tracker->meta);
            pthread_mutex_unlock(&bucket->lock);
            return -1;
        }
        if (oldest_prev == NULL) {
            bucket->head = oldest->next;
        } else {
            oldest_prev->next = oldest->next;
        }
        tracker->count--;
        free(oldest);
    }

    entry = calloc(1, sizeof(*entry));
    if (entry == NULL) {
        pthread_mutex_unlock(&tracker->meta);
        pthread_mutex_unlock(&bucket->lock);
        return -1;
    }
    entry->key = *key;
    entry->view.packets_seen = 1;
    entry->view.first_seen = now;
    entry->view.last_seen = now;
    entry->next = bucket->head;
    bucket->head = entry;
    tracker->count++;
    *out = entry->view;
    pthread_mutex_unlock(&tracker->meta);
    pthread_mutex_unlock(&bucket->lock);
    return 1;
}

void rv_tracker_set_flags(rv_tracker *tracker, const rv_flow_key *key,
                          int handled, int frozen)
{
    size_t idx;
    tracker_bucket *bucket;
    tracker_entry *entry;

    if (tracker == NULL || key == NULL) {
        return;
    }
    idx = (size_t)hash_key(key) & (tracker->bucket_count - 1);
    bucket = &tracker->buckets[idx];

    pthread_mutex_lock(&bucket->lock);
    for (entry = bucket->head; entry != NULL; entry = entry->next) {
        if (key_equal(&entry->key, key)) {
            entry->view.handled = handled;
            entry->view.frozen = frozen;
            break;
        }
    }
    pthread_mutex_unlock(&bucket->lock);
}

void rv_tracker_expire(rv_tracker *tracker, time_t now)
{
    size_t i;
    size_t removed_total = 0;

    if (tracker == NULL) {
        return;
    }
    for (i = 0; i < tracker->bucket_count; i++) {
        tracker_bucket *bucket = &tracker->buckets[i];
        tracker_entry *prev = NULL;
        tracker_entry *entry;
        size_t removed = 0;

        pthread_mutex_lock(&bucket->lock);
        entry = bucket->head;
        while (entry != NULL) {
            tracker_entry *next = entry->next;
            if (entry_expired(tracker, entry, now)) {
                if (prev == NULL) {
                    bucket->head = next;
                } else {
                    prev->next = next;
                }
                free(entry);
                removed++;
            } else {
                prev = entry;
            }
            entry = next;
        }
        pthread_mutex_unlock(&bucket->lock);
        removed_total += removed;
    }

    if (removed_total > 0) {
        pthread_mutex_lock(&tracker->meta);
        if (tracker->count >= removed_total) {
            tracker->count -= removed_total;
        } else {
            tracker->count = 0;
        }
        pthread_mutex_unlock(&tracker->meta);
    }
}

size_t rv_tracker_count(rv_tracker *tracker)
{
    size_t count;

    if (tracker == NULL) {
        return 0;
    }
    pthread_mutex_lock(&tracker->meta);
    count = tracker->count;
    pthread_mutex_unlock(&tracker->meta);
    return count;
}
