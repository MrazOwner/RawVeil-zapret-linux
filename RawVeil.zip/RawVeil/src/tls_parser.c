#include "tls_parser.h"

#include <stdint.h>
#include <string.h>

static uint16_t read_be16(const uint8_t *p)
{
    return (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
}

static int parse_sni_extension(const uint8_t *data, size_t len,
                               size_t abs_off, rv_tls_info *info)
{
    size_t list_len;
    size_t pos;
    size_t end;

    if (len < 2) {
        return -1;
    }
    list_len = read_be16(data);
    if (list_len + 2 > len) {
        /* A truncated extension can still contain the SNI length fields. */
        if (len >= 5 && data[2] == 0) {
            size_t name_len = read_be16(data + 3);
            if (name_len > 0 && name_len < RV_TLS_SNI_MAX) {
                info->has_sni = 1;
                info->sni_offset = abs_off + 5;
                info->sni_len = name_len;
            }
        }
        return 0;
    }
    pos = 2;
    end = 2 + list_len;

    while (pos + 3 <= end) {
        uint8_t name_type = data[pos];
        size_t name_len = read_be16(data + pos + 1);

        pos += 3;
        if (pos + name_len > end) {
            if (name_type == 0 && name_len > 0 &&
                name_len < RV_TLS_SNI_MAX) {
                info->has_sni = 1;
                info->sni_offset = abs_off + pos;
                info->sni_len = name_len;
            }
            return 0;
        }
        if (name_type == 0 && name_len > 0 && name_len < RV_TLS_SNI_MAX) {
            memcpy(info->sni, data + pos, name_len);
            info->sni[name_len] = '\0';
            info->has_sni = 1;
            info->sni_offset = abs_off + pos;
            info->sni_len = name_len;
            return 0;
        }
        pos += name_len;
    }
    return 0;
}

static void put_be16(uint8_t *p, size_t value)
{
    p[0] = (uint8_t)((value >> 8) & 0xffu);
    p[1] = (uint8_t)(value & 0xffu);
}

static void put_be24(uint8_t *p, size_t value)
{
    p[0] = (uint8_t)((value >> 16) & 0xffu);
    p[1] = (uint8_t)((value >> 8) & 0xffu);
    p[2] = (uint8_t)(value & 0xffu);
}

int rv_tls_replace_sni(const uint8_t *data, size_t len,
                       const char *new_sni,
                       uint8_t *out, size_t outsz)
{
    size_t record_len;
    size_t end;
    size_t pos;
    size_t session_len;
    size_t cipher_len;
    size_t comp_len;
    size_t ext_len_off;
    size_t ext_end;
    size_t sni_ext_len_off = 0;
    size_t sni_list_len_off = 0;
    size_t sni_name_len_off = 0;
    size_t sni_name_off = 0;
    size_t old_sni_len = 0;
    size_t new_sni_len;
    size_t new_len;
    size_t suffix_off;
    int delta;

    if (data == NULL || new_sni == NULL || out == NULL || len < 9 ||
        data[0] != 0x16 || data[1] != 0x03 || data[5] != 0x01) {
        return -1;
    }
    record_len = read_be16(data + 3);
    if (record_len + 5 > len) {
        return -1;
    }
    end = 5 + record_len;
    pos = 9;

    if (pos + 34 > end) {
        return -1;
    }
    pos += 2 + 32;
    session_len = data[pos++];
    if (pos + session_len + 2 > end) {
        return -1;
    }
    pos += session_len;
    cipher_len = read_be16(data + pos);
    pos += 2;
    if (pos + cipher_len + 1 > end) {
        return -1;
    }
    pos += cipher_len;
    comp_len = data[pos++];
    if (pos + comp_len + 2 > end) {
        return -1;
    }
    pos += comp_len;
    ext_len_off = pos;
    pos += 2;
    ext_end = pos + read_be16(data + ext_len_off);
    if (ext_end > end) {
        return -1;
    }

    while (pos + 4 <= ext_end) {
        uint16_t type = read_be16(data + pos);
        size_t elen = read_be16(data + pos + 2);
        size_t eoff = pos + 4;

        if (eoff + elen > ext_end) {
            return -1;
        }
        if (type == 0x0000 && elen >= 5) {
            size_t list_len = read_be16(data + eoff);
            size_t npos = eoff + 2;
            size_t nend = npos + list_len;

            if (nend > eoff + elen) {
                return -1;
            }
            while (npos + 3 <= nend) {
                uint8_t ntype = data[npos];
                size_t nlen = read_be16(data + npos + 1);

                if (npos + 3 + nlen > nend) {
                    return -1;
                }
                if (ntype == 0) {
                    sni_ext_len_off = pos + 2;
                    sni_list_len_off = eoff;
                    sni_name_len_off = npos + 1;
                    sni_name_off = npos + 3;
                    old_sni_len = nlen;
                    break;
                }
                npos += 3 + nlen;
            }
        }
        pos = eoff + elen;
    }
    if (sni_name_off == 0 || old_sni_len == 0) {
        return -1;
    }

    new_sni_len = strlen(new_sni);
    if (new_sni_len == 0 || new_sni_len > 255) {
        return -1;
    }
    delta = (int)new_sni_len - (int)old_sni_len;
    new_len = (size_t)((int)len + delta);
    if (new_len > outsz) {
        return -1;
    }
    suffix_off = sni_name_off + old_sni_len;
    memcpy(out, data, sni_name_off);
    memcpy(out + sni_name_off, new_sni, new_sni_len);
    memcpy(out + sni_name_off + new_sni_len, data + suffix_off,
           len - suffix_off);

    put_be16(out + 3, record_len + delta);
    put_be24(out + 6, (((size_t)data[6] << 16) |
                       ((size_t)data[7] << 8) | data[8]) + delta);
    put_be16(out + ext_len_off,
             read_be16(data + ext_len_off) + delta);
    put_be16(out + sni_ext_len_off,
             read_be16(data + sni_ext_len_off) + delta);
    put_be16(out + sni_list_len_off,
             read_be16(data + sni_list_len_off) + delta);
    put_be16(out + sni_name_len_off, new_sni_len);
    return (int)new_len;
}

int rv_tls_parse_client_hello(const uint8_t *data, size_t len,
                              rv_tls_info *info)
{
    size_t record_len;
    size_t handshake_len;
    size_t pos;
    size_t end;
    size_t session_len;
    size_t cipher_len;
    size_t comp_len;
    size_t ext_len;
    size_t ext_end;
    int complete;

    if (info == NULL) {
        return -1;
    }
    memset(info, 0, sizeof(*info));
    if (data == NULL || len < 5) {
        return 0;
    }
    if (data[0] != 0x16 || data[1] != 0x03) {
        return 0;
    }
    record_len = read_be16(data + 3);
    if (record_len == 0) {
        return 0;
    }
    complete = record_len + 5 <= len;
    info->record_len = record_len;

    pos = 5;
    end = complete ? 5 + record_len : len;
    if (pos + 4 > end || data[pos] != 0x01) {
        return 0;
    }
    handshake_len = ((size_t)data[pos + 1] << 16) |
                    ((size_t)data[pos + 2] << 8) |
                    (size_t)data[pos + 3];
    pos += 4;
    if (pos + handshake_len <= end) {
        end = pos + handshake_len;
    }
    info->is_client_hello = 1;

    if (pos + 34 > end) {
        return complete ? -1 : 0;
    }
    pos += 2 + 32; /* legacy_version + random */

    session_len = data[pos];
    pos++;
    if (pos + session_len > end) {
        return complete ? -1 : 0;
    }
    pos += session_len;

    if (pos + 2 > end) {
        return complete ? -1 : 0;
    }
    cipher_len = read_be16(data + pos);
    pos += 2;
    if (pos + cipher_len > end) {
        return complete ? -1 : 0;
    }
    pos += cipher_len;

    if (pos + 1 > end) {
        return complete ? -1 : 0;
    }
    comp_len = data[pos];
    pos++;
    if (pos + comp_len > end) {
        return complete ? -1 : 0;
    }
    pos += comp_len;

    if (pos + 2 > end) {
        return 1; /* no extensions */
    }
    ext_len = read_be16(data + pos);
    pos += 2;
    ext_end = pos + ext_len;
    if (ext_end > end) {
        if (complete) {
            return -1;
        }
        ext_end = end;
    }

    while (pos + 4 <= ext_end) {
        uint16_t ext_type = read_be16(data + pos);
        size_t elen = read_be16(data + pos + 2);

        pos += 4;
        if (pos + elen > ext_end) {
            if (complete) {
                return -1;
            }
            if (ext_type == 0x0000 && pos < ext_end) {
                (void)parse_sni_extension(data + pos, ext_end - pos, pos,
                                          info);
            }
            break;
        }
        if (ext_type == 0x0000) {
            if (parse_sni_extension(data + pos, elen, pos, info) < 0) {
                if (complete) {
                    return -1;
                }
                break;
            }
        }
        pos += elen;
    }
    return 1;
}
