#include "tls_parser.h"

#include <stdint.h>
#include <string.h>

static uint16_t read_be16(const uint8_t *p)
{
    return (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
}

static int parse_sni_extension(const uint8_t *data, size_t len,
                               size_t abs_off, rv_tls_info *info)
{
    size_t list_len;
    size_t pos;
    size_t end;

    if (len < 2) {
        return -1;
    }
    list_len = read_be16(data);
    if (list_len + 2 > len) {
        return -1;
    }
    pos = 2;
    end = 2 + list_len;

    while (pos + 3 <= end) {
        uint8_t name_type = data[pos];
        size_t name_len = read_be16(data + pos + 1);

        pos += 3;
        if (pos + name_len > end) {
            return -1;
        }
        if (name_type == 0 && name_len > 0 && name_len < RV_TLS_SNI_MAX) {
            memcpy(info->sni, data + pos, name_len);
            info->sni[name_len] = '\0';
            info->has_sni = 1;
            info->sni_offset = abs_off + pos;
            info->sni_len = name_len;
            return 0;
        }
        pos += name_len;
    }
    return 0;
}

int rv_tls_parse_client_hello(const uint8_t *data, size_t len,
                              rv_tls_info *info)
{
    size_t record_len;
    size_t handshake_len;
    size_t pos;
    size_t end;
    size_t session_len;
    size_t cipher_len;
    size_t comp_len;
    size_t ext_len;
    size_t ext_end;

    if (info == NULL) {
        return -1;
    }
    memset(info, 0, sizeof(*info));
    if (data == NULL || len < 5) {
        return 0;
    }
    if (data[0] != 0x16 || data[1] != 0x03) {
        return 0;
    }
    record_len = read_be16(data + 3);
    if (record_len == 0) {
        return 0;
    }
    if (record_len + 5 > len) {
        /* The record is split across TCP segments; the current packet does
         * not contain a complete ClientHello. */
        return 0;
    }
    info->record_len = record_len;

    pos = 5;
    end = 5 + record_len;
    if (pos + 4 > end || data[pos] != 0x01) {
        return 0;
    }
    handshake_len = ((size_t)data[pos + 1] << 16) |
                    ((size_t)data[pos + 2] << 8) |
                    (size_t)data[pos + 3];
    pos += 4;
    if (pos + handshake_len > end) {
        return -1;
    }
    end = pos + handshake_len;
    info->is_client_hello = 1;

    if (pos + 34 > end) {
        return -1;
    }
    pos += 2 + 32; /* legacy_version + random */

    session_len = data[pos];
    pos++;
    if (pos + session_len > end) {
        return -1;
    }
    pos += session_len;

    if (pos + 2 > end) {
        return -1;
    }
    cipher_len = read_be16(data + pos);
    pos += 2;
    if (pos + cipher_len > end) {
        return -1;
    }
    pos += cipher_len;

    if (pos + 1 > end) {
        return -1;
    }
    comp_len = data[pos];
    pos++;
    if (pos + comp_len > end) {
        return -1;
    }
    pos += comp_len;

    if (pos + 2 > end) {
        return 1; /* no extensions */
    }
    ext_len = read_be16(data + pos);
    pos += 2;
    if (pos + ext_len > end) {
        return -1;
    }
    ext_end = pos + ext_len;

    while (pos + 4 <= ext_end) {
        uint16_t ext_type = read_be16(data + pos);
        size_t elen = read_be16(data + pos + 2);

        pos += 4;
        if (pos + elen > ext_end) {
            return -1;
        }
        if (ext_type == 0x0000) {
            if (parse_sni_extension(data + pos, elen, pos, info) < 0) {
                return -1;
            }
        }
        pos += elen;
    }
    return 1;
}
