#include "routing.h"

#include "log.h"

#include <arpa/inet.h>
#include <errno.h>
#include <net/if.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define RV_NFT_TABLE "rawveil"
#define RV_NFT_CHAIN "warp_out"

static void set_err(char *err, size_t errlen, const char *fmt, ...)
    __attribute__((format(printf, 3, 4)));

static void set_err(char *err, size_t errlen, const char *fmt, ...)
{
    va_list ap;

    if (err == NULL || errlen == 0) {
        return;
    }
    va_start(ap, fmt);
    (void)vsnprintf(err, errlen, fmt, ap);
    va_end(ap);
}

static const char *find_tool(const char *name)
{
    static const char *nft_candidates[] = {
        "/usr/sbin/nft", "/sbin/nft", "/usr/bin/nft", "/bin/nft",
        "/usr/local/sbin/nft", "/usr/local/bin/nft", NULL
    };
    static const char *ip_candidates[] = {
        "/usr/sbin/ip", "/sbin/ip", "/usr/bin/ip", "/bin/ip",
        "/usr/local/sbin/ip", "/usr/local/bin/ip", NULL
    };
    const char **candidates;
#ifdef RV_TESTING
    const char *override;
#endif
    size_t i;

#ifdef RV_TESTING
    override = getenv(strcmp(name, "nft") == 0
                          ? "RAWVEIL_NFT_TOOL" : "RAWVEIL_IP_TOOL");
    if (override != NULL && *override != '\0') {
        return override;
    }
#endif

    if (strcmp(name, "nft") == 0) {
        candidates = nft_candidates;
    } else if (strcmp(name, "ip") == 0) {
        candidates = ip_candidates;
    } else {
        return NULL;
    }
    for (i = 0; candidates[i] != NULL; i++) {
        if (access(candidates[i], X_OK) == 0) {
            return candidates[i];
        }
    }
    return NULL;
}

static int run_argv(const char *path, char *const argv[],
                    int stdin_fd, int ignore_failure,
                    char *err, size_t errlen)
{
    pid_t pid;
    int status;

    pid = fork();
    if (pid < 0) {
        set_err(err, errlen, "fork(%s): %s", argv[0], strerror(errno));
        return -1;
    }
    if (pid == 0) {
        if (stdin_fd >= 0 && dup2(stdin_fd, STDIN_FILENO) < 0) {
            _exit(126);
        }
        if (stdin_fd >= 0) {
            close(stdin_fd);
        }
        if (strchr(path, '/') != NULL) {
            execv(path, argv);
        } else {
            execvp(path, argv);
        }
        _exit(127);
    }

    for (;;) {
        if (waitpid(pid, &status, 0) >= 0) {
            break;
        }
        if (errno != EINTR) {
            set_err(err, errlen, "waitpid(%s): %s", argv[0],
                    strerror(errno));
            return -1;
        }
    }

    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        if (!ignore_failure) {
            set_err(err, errlen, "%s failed (status=%d)", argv[0],
                    WIFEXITED(status) ? WEXITSTATUS(status) : -1);
            return -1;
        }
        return -1;
    }
    return 0;
}

static int run_nft_script(const char *tool, const char *script,
                          char *err, size_t errlen)
{
    char *argv[4];
    int fds[2];
    size_t offset = 0;
    size_t len = strlen(script);
    pid_t pid;
    int status;
    int write_failed = 0;

    argv[0] = (char *)tool;
    argv[1] = (char *)"-f";
    argv[2] = (char *)"-";
    argv[3] = NULL;

    if (pipe(fds) < 0) {
        set_err(err, errlen, "pipe: %s", strerror(errno));
        return -1;
    }
    pid = fork();
    if (pid < 0) {
        set_err(err, errlen, "fork(nft): %s", strerror(errno));
        close(fds[0]);
        close(fds[1]);
        return -1;
    }
    if (pid == 0) {
        close(fds[1]);
        if (dup2(fds[0], STDIN_FILENO) < 0) {
            _exit(126);
        }
        close(fds[0]);
        if (strchr(tool, '/') != NULL) {
            execv(tool, argv);
        } else {
            execvp(tool, argv);
        }
        _exit(127);
    }

    close(fds[0]);
    while (offset < len) {
        ssize_t n = write(fds[1], script + offset, len - offset);
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            write_failed = 1;
            break;
        }
        offset += (size_t)n;
    }
    close(fds[1]);

    for (;;) {
        if (waitpid(pid, &status, 0) >= 0) {
            break;
        }
        if (errno != EINTR) {
            set_err(err, errlen, "waitpid(nft): %s", strerror(errno));
            return -1;
        }
    }
    if (write_failed) {
        set_err(err, errlen, "cannot write nftables script");
        return -1;
    }
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        set_err(err, errlen, "nft failed (status=%d)",
                WIFEXITED(status) ? WEXITSTATUS(status) : -1);
        return -1;
    }
    return 0;
}

static int entry_compare(const void *a, const void *b)
{
    const rv_warp_entry *ea = a;
    const rv_warp_entry *eb = b;
    int rc;

    if (ea->family != eb->family) {
        return ea->family < eb->family ? -1 : 1;
    }
    if (ea->prefix != eb->prefix) {
        return ea->prefix < eb->prefix ? -1 : 1;
    }
    rc = memcmp(ea->addr, eb->addr, sizeof(ea->addr));
    return rc < 0 ? -1 : (rc > 0 ? 1 : 0);
}

static size_t sort_unique_entries(rv_warp_entry *entries, size_t count)
{
    size_t i;
    size_t out = 0;

    if (count == 0) {
        return 0;
    }
    qsort(entries, count, sizeof(*entries), entry_compare);
    out = 1;
    for (i = 1; i < count; i++) {
        if (entry_compare(&entries[i], &entries[out - 1]) != 0) {
            entries[out++] = entries[i];
        }
    }
    return out;
}

static size_t filter_entries_family(rv_warp_entry *entries, size_t count,
                                    int has_ipv4, int has_ipv6)
{
    size_t i;
    size_t out = 0;

    for (i = 0; i < count; i++) {
        if (entries[i].family == AF_INET && !has_ipv4) {
            continue;
        }
        if (entries[i].family == AF_INET6 && !has_ipv6) {
            continue;
        }
        entries[out++] = entries[i];
    }
    return out;
}

static int build_nft_script(const rv_warp_entry *entries, size_t count,
                            uint32_t mark, int full_table,
                            char **out, size_t *out_len,
                            char *err, size_t errlen)
{
    FILE *stream;
    char *script = NULL;
    size_t script_len = 0;
    size_t i;
    int failed = 0;

    stream = open_memstream(&script, &script_len);
    if (stream == NULL) {
        set_err(err, errlen, "open_memstream: %s", strerror(errno));
        return -1;
    }

    if (full_table) {
        if (fprintf(stream,
                    "table inet %s {\n"
                    "  set warp4 { type ipv4_addr; flags interval; }\n"
                    "  set warp6 { type ipv6_addr; flags interval; }\n"
                    "  chain %s {\n"
                    "    type filter hook output priority mangle; "
                    "policy accept;\n"
                    "    ip daddr @warp4 meta mark set 0x%x\n"
                    "    ip6 daddr @warp6 meta mark set 0x%x\n"
                    "  }\n"
                    "}\n",
                    RV_NFT_TABLE, RV_NFT_CHAIN, mark, mark) < 0) {
            failed = 1;
        }
    } else {
        if (fprintf(stream,
                    "flush set inet %s warp4\n"
                    "flush set inet %s warp6\n",
                    RV_NFT_TABLE, RV_NFT_TABLE) < 0) {
            failed = 1;
        }
    }

    for (i = 0; i < count && !failed; i++) {
        char addr[INET6_ADDRSTRLEN];
        const char *family_set;
        int family = entries[i].family;

        if (inet_ntop(family, entries[i].addr, addr, sizeof(addr)) == NULL) {
            continue;
        }
        family_set = family == AF_INET ? "warp4" : "warp6";
        if (fprintf(stream, "add element inet %s %s { %s/%u }\n",
                    RV_NFT_TABLE, family_set, addr,
                    (unsigned)entries[i].prefix) < 0) {
            failed = 1;
        }
    }

    if (fclose(stream) != 0) {
        failed = 1;
    }
    if (failed) {
        free(script);
        set_err(err, errlen, "cannot build nftables script");
        return -1;
    }
    *out = script;
    *out_len = script_len;
    return 0;
}

static void ip_rule_del(const char *ip, const char *mark, const char *table,
                        const char *priority, int ipv6)
{
    char *argv6[] = {"ip", "-6", "rule", "del", "fwmark", (char *)mark,
                     "table", (char *)table, "priority", (char *)priority,
                     NULL};
    char *argv4[] = {"ip", "rule", "del", "fwmark", (char *)mark,
                     "table", (char *)table, "priority", (char *)priority,
                     NULL};

    (void)run_argv(ip, ipv6 ? argv6 : argv4, -1, 1, NULL, 0);
}

static void ip_route_flush(const char *ip, const char *table, int ipv6)
{
    char *argv6[] = {"ip", "-6", "route", "flush", "table", (char *)table,
                     NULL};
    char *argv4[] = {"ip", "route", "flush", "table", (char *)table, NULL};

    (void)run_argv(ip, ipv6 ? argv6 : argv4, -1, 1, NULL, 0);
}

static int ip_route_add(const char *ip, const char *iface, const char *table,
                        int ipv6, int ignore_failure,
                        char *err, size_t errlen)
{
    char *argv6[] = {"ip", "-6", "route", "replace", "default", "dev",
                     (char *)iface, "table", (char *)table, NULL};
    char *argv4[] = {"ip", "route", "replace", "default", "dev",
                     (char *)iface, "table", (char *)table, NULL};

    return run_argv(ip, ipv6 ? argv6 : argv4, -1, ignore_failure,
                    err, errlen);
}

static int ip_rule_add(const char *ip, const char *mark, const char *table,
                       const char *priority, int ipv6,
                       int ignore_failure, char *err, size_t errlen)
{
    char *argv6[] = {"ip", "-6", "rule", "add", "fwmark", (char *)mark,
                     "table", (char *)table, "priority", (char *)priority,
                     NULL};
    char *argv4[] = {"ip", "rule", "add", "fwmark", (char *)mark,
                     "table", (char *)table, "priority", (char *)priority,
                     NULL};

    return run_argv(ip, ipv6 ? argv6 : argv4, -1, ignore_failure,
                    err, errlen);
}

/* Non-standard route protocol used to tag/cleanup RawVeil routes. */
#define RV_ROUTE_PROTO "247"

static void route_flush_proto(const char *ip, int ipv6)
{
    char *argv6[] = {"ip", "-6", "route", "flush", "proto", RV_ROUTE_PROTO,
                     NULL};
    char *argv4[] = {"ip", "route", "flush", "proto", RV_ROUTE_PROTO, NULL};

    (void)run_argv(ip, ipv6 ? argv6 : argv4, -1, 1, NULL, 0);
}

static int route_add_entry(const char *ip, const char *iface,
                           const rv_warp_entry *entry,
                           char *err, size_t errlen)
{
    char addr[INET6_ADDRSTRLEN];
    char prefix[INET6_ADDRSTRLEN + 8];
    int ipv6 = entry->family == AF_INET6;

    /* A /0 entry would replace the host default route and take the machine
     * offline.  WARP routing is split routing by design; refuse it. */
    if (entry->prefix == 0) {
        return -1;
    }
    if (inet_ntop(entry->family, entry->addr, addr, sizeof(addr)) == NULL) {
        return -1;
    }
    snprintf(prefix, sizeof(prefix), "%s/%u", addr,
             (unsigned)entry->prefix);
    if (ipv6) {
        char *argv[] = {"ip", "-6", "route", "replace", prefix, "dev",
                        (char *)iface, "proto", RV_ROUTE_PROTO, NULL};
        return run_argv(ip, argv, -1, 0, err, errlen);
    } else {
        char *argv[] = {"ip", "route", "replace", prefix, "dev",
                        (char *)iface, "proto", RV_ROUTE_PROTO, NULL};
        return run_argv(ip, argv, -1, 0, err, errlen);
    }
}

static int route_apply_entries(const char *ip, const char *iface,
                               const rv_warp_entry *entries, size_t count,
                               size_t *added, char *err, size_t errlen)
{
    size_t i;
    size_t ok = 0;

    for (i = 0; i < count; i++) {
        if (route_add_entry(ip, iface, &entries[i], err, errlen) < 0) {
            char addr[INET6_ADDRSTRLEN];
            if (inet_ntop(entries[i].family, entries[i].addr,
                          addr, sizeof(addr)) != NULL) {
                LOG_WARN("routing: cannot add route %s/%u via %s: %s",
                         addr, (unsigned)entries[i].prefix, iface, err);
            }
            continue;
        }
        ok++;
    }
    *added = ok;
    return 0;
}

void rv_routing_cleanup(rv_routing *routing)
{
    const char *nft;
    const char *ip;
    char mark_s[16];
    char table_s[16];
    char prio_s[16];

    if (routing == NULL || !routing->active) {
        return;
    }
    nft = find_tool("nft");
    ip = find_tool("ip");
    snprintf(mark_s, sizeof(mark_s), "0x%x", routing->mark);
    snprintf(table_s, sizeof(table_s), "%d", routing->table);
    snprintf(prio_s, sizeof(prio_s), "%d", routing->priority);

    if (routing->mode == RV_ROUTING_ROUTE) {
        if (ip != NULL) {
            route_flush_proto(ip, 0);
            route_flush_proto(ip, 1);
        }
    } else {
        if (nft != NULL) {
            char *argv[] = {"nft", "delete", "table", "inet",
                            RV_NFT_TABLE, NULL};
            (void)run_argv(nft, argv, -1, 1, NULL, 0);
        }
        if (ip != NULL) {
            ip_rule_del(ip, mark_s, table_s, prio_s, 0);
            ip_rule_del(ip, mark_s, table_s, prio_s, 1);
            ip_route_flush(ip, table_s, 0);
            ip_route_flush(ip, table_s, 1);
        }
    }
    routing->active = 0;
    LOG_DEBUG("routing: removed %s routing state for %s",
              routing->mode == RV_ROUTING_ROUTE ? "route" : "nftables",
              routing->interface);
}

int rv_routing_setup(rv_routing *routing, const rv_warp_config *cfg,
                     const rv_awg_config *awg, rv_warp *warp,
                     char *err, size_t errlen)
{
    const char *nft;
    const char *ip;
    rv_warp_entry *entries = NULL;
    size_t count = 0;
    char *script = NULL;
    size_t script_len = 0;
    char mark_s[16];
    char table_s[16];
    char prio_s[16];
    char iface[RV_IFNAMSIZ];
    int has_ipv4;
    int has_ipv6;

    if (routing == NULL || cfg == NULL || awg == NULL || warp == NULL) {
        set_err(err, errlen, "invalid routing arguments");
        return -1;
    }
    if (!cfg->manage_routing || cfg->awg_config[0] == '\0') {
        memset(routing, 0, sizeof(*routing));
        return 0;
    }
    rv_routing_cleanup(routing);
    memset(routing, 0, sizeof(*routing));

    rv_strlcpy(iface, sizeof(iface), awg->interface);
    if (if_nametoindex(iface) == 0) {
        set_err(err, errlen, "AWG interface '%s' is not up", iface);
        return -1;
    }
    nft = find_tool("nft");
    ip = find_tool("ip");
    if (nft == NULL || ip == NULL) {
        set_err(err, errlen, "nft/ip tools are not available");
        return -1;
    }

    rv_strlcpy(routing->interface, sizeof(routing->interface), iface);
    routing->mode = cfg->routing_mode;
    routing->mark = cfg->mark;
    routing->table = cfg->routing_table;
    routing->priority = cfg->routing_priority;
    has_ipv4 = awg->has_ipv4 || !awg->has_ipv6;
    has_ipv6 = awg->has_ipv6;

    if (awg->allowed_ips[0] != '\0' &&
        !awg->default_route_v4 && !awg->default_route_v6) {
        LOG_WARN("routing: AWG AllowedIPs has no 0.0.0.0/0 or ::/0; "
                 "some WARP destinations may be dropped by AWG");
    }

    if (routing->mode == RV_ROUTING_ROUTE) {
        size_t added = 0;

        ip = find_tool("ip");
        if (ip == NULL) {
            set_err(err, errlen, "ip tool is not available");
            return -1;
        }
        if (rv_warp_copy_entries(warp, &entries, &count) < 0) {
            set_err(err, errlen, "cannot snapshot WARP destinations");
            return -1;
        }
        count = sort_unique_entries(entries, count);
        count = filter_entries_family(entries, count, has_ipv4, has_ipv6);
        route_flush_proto(ip, 0);
        route_flush_proto(ip, 1);
        route_apply_entries(ip, iface, entries, count, &added, err, errlen);
        free(entries);
        if (count > 0 && added == 0) {
            set_err(err, errlen, "cannot add any WARP route via %s", iface);
            return -1;
        }
        routing->active = 1;
        routing->has_ipv4 = has_ipv4;
        routing->has_ipv6 = has_ipv6;
        LOG_INFO("routing: route mode: dev=%s ipv4=%d ipv6=%d "
                 "routes=%zu/%zu", iface, routing->has_ipv4,
                 routing->has_ipv6, added, count);
        return 0;
    }

    if (rv_warp_copy_entries(warp, &entries, &count) < 0) {
        set_err(err, errlen, "cannot snapshot WARP destinations");
        return -1;
    }
    count = sort_unique_entries(entries, count);
    if (build_nft_script(entries, count, routing->mark, 1,
                         &script, &script_len, err, errlen) < 0) {
        free(entries);
        return -1;
    }
    free(entries);

    snprintf(mark_s, sizeof(mark_s), "0x%x", routing->mark);
    snprintf(table_s, sizeof(table_s), "%d", routing->table);
    snprintf(prio_s, sizeof(prio_s), "%d", routing->priority);

    /* Remove stale state from a previous crash. */
    {
        char *argv[] = {"nft", "delete", "table", "inet", RV_NFT_TABLE, NULL};
        (void)run_argv(nft, argv, -1, 1, NULL, 0);
    }
    ip_rule_del(ip, mark_s, table_s, prio_s, 0);
    ip_rule_del(ip, mark_s, table_s, prio_s, 1);
    ip_route_flush(ip, table_s, 0);
    ip_route_flush(ip, table_s, 1);

    if (run_nft_script(nft, script, err, errlen) < 0) {
        free(script);
        return -1;
    }
    free(script);
    routing->active = 1;
    routing->has_ipv4 = has_ipv4;
    routing->has_ipv6 = has_ipv6;

    if (has_ipv4) {
        if (ip_route_add(ip, iface, table_s, 0, 0, err, errlen) < 0) {
            LOG_ERROR("routing: cannot add IPv4 default route via %s: %s",
                      iface, err);
            rv_routing_cleanup(routing);
            return -1;
        }
        if (ip_rule_add(ip, mark_s, table_s, prio_s, 0, 0,
                        err, errlen) < 0) {
            LOG_ERROR("routing: cannot add IPv4 ip rule: %s", err);
            rv_routing_cleanup(routing);
            return -1;
        }
    }
    if (has_ipv6) {
        if (ip_route_add(ip, iface, table_s, 1, 1, err, errlen) < 0) {
            LOG_WARN("routing: IPv6 default route via %s failed, "
                     "IPv6 WARP disabled", iface);
            routing->has_ipv6 = 0;
        } else if (ip_rule_add(ip, mark_s, table_s, prio_s, 1, 1,
                               err, errlen) < 0) {
            LOG_WARN("routing: IPv6 ip rule failed, IPv6 WARP disabled");
            routing->has_ipv6 = 0;
        }
    }

    LOG_INFO("routing: mark=0x%x table=%d priority=%d dev=%s "
             "ipv4=%d ipv6=%d entries=%zu",
             routing->mark, routing->table, routing->priority, iface,
             routing->has_ipv4, routing->has_ipv6, count);
    return 0;
}

int rv_routing_refresh(rv_routing *routing, rv_warp *warp,
                       char *err, size_t errlen)
{
    const char *nft;
    rv_warp_entry *entries = NULL;
    size_t count = 0;
    char *script = NULL;
    size_t script_len = 0;

    if (routing == NULL || warp == NULL) {
        set_err(err, errlen, "invalid routing refresh arguments");
        return -1;
    }
    if (!routing->active) {
        return 0;
    }
    if (routing->mode == RV_ROUTING_ROUTE) {
        const char *ip = find_tool("ip");
        size_t added = 0;

        if (ip == NULL) {
            set_err(err, errlen, "ip tool is not available");
            return -1;
        }
        if (rv_warp_copy_entries(warp, &entries, &count) < 0) {
            set_err(err, errlen, "cannot snapshot WARP destinations");
            return -1;
        }
        count = sort_unique_entries(entries, count);
        count = filter_entries_family(entries, count,
                                      routing->has_ipv4,
                                      routing->has_ipv6);
        route_flush_proto(ip, 0);
        route_flush_proto(ip, 1);
        route_apply_entries(ip, routing->interface, entries, count,
                            &added, err, errlen);
        free(entries);
        if (count > 0 && added == 0) {
            set_err(err, errlen, "cannot refresh WARP routes via %s",
                    routing->interface);
            return -1;
        }
        LOG_INFO("routing: refreshed route-mode WARP routes (%zu/%zu)",
                 added, count);
        return 0;
    }
    nft = find_tool("nft");
    if (nft == NULL) {
        set_err(err, errlen, "nft tool is not available");
        return -1;
    }
    if (rv_warp_copy_entries(warp, &entries, &count) < 0) {
        set_err(err, errlen, "cannot snapshot WARP destinations");
        return -1;
    }
    count = sort_unique_entries(entries, count);
    if (build_nft_script(entries, count, routing->mark, 0,
                         &script, &script_len, err, errlen) < 0) {
        free(entries);
        return -1;
    }
    free(entries);
    if (run_nft_script(nft, script, err, errlen) < 0) {
        free(script);
        return -1;
    }
    free(script);
    LOG_INFO("routing: refreshed nftables WARP set (%zu entries)", count);
    return 0;
}
