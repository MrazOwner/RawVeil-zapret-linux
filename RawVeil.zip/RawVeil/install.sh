#!/bin/bash
#
# RawVeil host installer / service wrapper.
#
#   sudo ./install.sh install
#   sudo ./install.sh start
#   sudo ./install.sh stop
#   sudo ./install.sh status
#   sudo ./install.sh uninstall
#
# install does not start RawVeil and does not enable it at boot.  The host
# capture rules are temporary: stop/crash/shutdown removes the nft table and
# dummy interface, so normal networking comes back automatically.
#
set -euo pipefail

ROOT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PREFIX=${PREFIX:-/usr/local}
BIN_DIR=$PREFIX/bin
SBIN_DIR=$PREFIX/sbin
CONF_DIR=/etc/rawveil
CONF=$CONF_DIR/rawveil.conf
STATE_DIR=/var/lib/rawveil
BACKUP_DIR=$STATE_DIR/backups
STATE_FILE=$STATE_DIR/install.state
UNIT=/etc/systemd/system/rawveil-host.service
ENV_FILE=/etc/default/rawveil-host
HOST_HELPER=$SBIN_DIR/rawveil-host
AWG_DIR=$CONF_DIR/awg
AWG_DEFAULT=$AWG_DIR/default_awg.conf

log() { printf 'rawveil-install: %s\n' "$*" >&2; }
die() { log "ERROR: $*"; exit 1; }
need_root() { [ "$(id -u)" -eq 0 ] || die "run as root"; }

check_deps() {
    command -v make >/dev/null 2>&1 || die "make is required"
    command -v cc >/dev/null 2>&1 || die "C compiler is required"
    command -v ip >/dev/null 2>&1 || die "iproute2 is required"
    command -v nft >/dev/null 2>&1 || die "nftables is required"
}

install_awg_from_source() {
    local tmp
    command -v git >/dev/null 2>&1 || return 0
    command -v make >/dev/null 2>&1 || return 0
    command -v cc >/dev/null 2>&1 || return 0

    tmp=$(mktemp -d "${TMPDIR:-/tmp}/rawveil-awg.XXXXXX") || return 0
    log "building amneziawg-tools from source"
    if git clone --depth 1 \
        https://github.com/amnezia-vpn/amneziawg-tools.git \
        "$tmp/tools" >/dev/null 2>&1; then
        if make -C "$tmp/tools/src" >/dev/null 2>&1 &&
           make -C "$tmp/tools/src" install >/dev/null 2>&1; then
            log "amneziawg-tools built and installed"
        else
            log "WARNING: amneziawg-tools source build failed"
        fi
    fi
    if command -v go >/dev/null 2>&1 &&
       git clone --depth 1 \
           https://github.com/amnezia-vpn/amneziawg-go.git \
           "$tmp/go" >/dev/null 2>&1; then
        if make -C "$tmp/go" >/dev/null 2>&1 &&
           make -C "$tmp/go" install >/dev/null 2>&1; then
            log "amneziawg-go userspace transport built and installed"
        else
            log "WARNING: amneziawg-go source build failed"
        fi
    fi
    rm -rf "$tmp"
}

install_awg_tools() {
    local pkg
    if command -v awg-quick >/dev/null 2>&1; then
        log "AmneziaWG tools already installed"
        return 0
    fi
    log "AmneziaWG tools not found; trying to install"

    if command -v pacman >/dev/null 2>&1; then
        # amneziawg-tools is in AUR on Arch.  Try the official repo first,
        # then common AUR helpers.  dkms/go are optional transports.
        for pkg in amneziawg-tools amneziawg-dkms; do
            pacman -S --needed --noconfirm "$pkg" 2>/dev/null || true
        done
        if ! command -v awg-quick >/dev/null 2>&1; then
            if command -v yay >/dev/null 2>&1; then
                yay -S --needed --noconfirm amneziawg-tools 2>/dev/null || true
                yay -S --needed --noconfirm amneziawg-dkms 2>/dev/null || true
            elif command -v paru >/dev/null 2>&1; then
                paru -S --needed --noconfirm amneziawg-tools 2>/dev/null || true
                paru -S --needed --noconfirm amneziawg-dkms 2>/dev/null || true
            fi
        fi
    elif command -v apt-get >/dev/null 2>&1; then
        DEBIAN_FRONTEND=noninteractive apt-get update -qq 2>/dev/null || true
        DEBIAN_FRONTEND=noninteractive apt-get install -y amneziawg \
            2>/dev/null || \
        DEBIAN_FRONTEND=noninteractive apt-get install -y amneziawg-tools \
            2>/dev/null || true
    elif command -v dnf >/dev/null 2>&1; then
        dnf install -y amneziawg-tools 2>/dev/null || true
    elif command -v zypper >/dev/null 2>&1; then
        zypper --non-interactive install amneziawg-tools 2>/dev/null || true
    fi

    if ! command -v awg-quick >/dev/null 2>&1; then
        install_awg_from_source
    fi

    if command -v awg-quick >/dev/null 2>&1; then
        log "AmneziaWG tools installed"
    else
        log "WARNING: awg-quick is not available; install amneziawg-tools/"
        log "         amneziawg-dkms or amneziawg-go manually."
        log "         RawVeil will run without AWG."
    fi
}

backup_config_once() {
    mkdir -p "$STATE_DIR" "$BACKUP_DIR"
    if [ -f "$STATE_FILE" ]; then
        return
    fi
    if [ -e "$CONF" ]; then
        backup=$BACKUP_DIR/rawveil.conf.$(date +%Y%m%d-%H%M%S)
        cp -a "$CONF" "$backup"
        printf 'original=%s\n' "$backup" > "$STATE_FILE"
        log "backed up existing config to $backup"
    else
        install -Dm644 "$ROOT_DIR/etc/rawveil.conf" "$CONF"
        printf 'original=\n' > "$STATE_FILE"
        log "installed default config $CONF"
    fi
}

install_unit() {
    install -Dm644 /dev/stdin "$UNIT" <<EOF
[Unit]
Description=RawVeil host DPI bypass
After=network-online.target
Wants=network-online.target
StartLimitBurst=3
StartLimitIntervalSec=60

[Service]
Type=simple
EnvironmentFile=-$ENV_FILE
ExecStart=$HOST_HELPER run
ExecStop=$HOST_HELPER stop
ExecStopPost=$HOST_HELPER cleanup
Restart=on-failure
RestartSec=2
KillMode=mixed
TimeoutStopSec=15

[Install]
WantedBy=multi-user.target
EOF
    if command -v systemctl >/dev/null 2>&1; then
        systemctl daemon-reload || true
    fi
}

do_install() {
    need_root
    check_deps
    install_awg_tools
    log "building RawVeil"
    make -C "$ROOT_DIR" -j"$(nproc 2>/dev/null || echo 2)"
    [ -x "$ROOT_DIR/build/rawveil" ] || die "build failed"

    install -Dm755 "$ROOT_DIR/build/rawveil" "$BIN_DIR/rawveil"
    install -Dm755 "$ROOT_DIR/scripts/rawveil-host.sh" "$HOST_HELPER"
    install -d "$CONF_DIR" "$STATE_DIR" "$BACKUP_DIR" "$SBIN_DIR"
    if [ ! -f "$ENV_FILE" ]; then
        install -Dm644 /dev/stdin "$ENV_FILE" <<'EOF'
# Optional rawveil-host overrides.
# RAWVEIL_CONFIG=/etc/rawveil/rawveil.dpi.conf
# RAWVEIL_QUIC_MODE=pass|block|fragment|fake
# RAWVEIL_DNS_MODE=off|system|dot|doh
# RAWVEIL_FWD_MODE=fwd|dupdrop
# RAWVEIL_IFACE=eth0
# RAWVEIL_LOG_LEVEL=info
# RAWVEIL_AWG_CONFIG=/etc/rawveil/awg/default_awg.conf
# RAWVEIL_AWG_MODE=auto|on|off
EOF
    fi
    if ! grep -q '^RAWVEIL_AWG_CONFIG=' "$ENV_FILE" 2>/dev/null; then
        printf '\n# AmneziaWG config; empty disables automatic AWG up/down.\nRAWVEIL_AWG_CONFIG=%s\n' \
            "$AWG_DEFAULT" >> "$ENV_FILE"
    fi

    # The shipped config drops privileges to "rawveil" after opening sockets.
    if ! getent passwd rawveil >/dev/null 2>&1 &&
       command -v useradd >/dev/null 2>&1; then
        useradd --system --no-create-home --shell /usr/sbin/nologin rawveil \
            2>/dev/null || true
    fi

    backup_config_once
    if [ -d "$ROOT_DIR/etc/lists" ]; then
        install -d "$CONF_DIR/lists"
        for list_file in "$ROOT_DIR"/etc/lists/*; do
            [ -f "$list_file" ] || continue
            dest="$CONF_DIR/lists/${list_file##*/}"
            [ -e "$dest" ] || install -Dm644 "$list_file" "$dest"
        done
    fi
    if [ -f "$ROOT_DIR/etc/rawveil.dpi.conf" ]; then
        install -Dm644 "$ROOT_DIR/etc/rawveil.dpi.conf" \
            "$CONF_DIR/rawveil.dpi.conf"
    fi
    install -d -m700 "$AWG_DIR"
    if [ -d "$ROOT_DIR/etc/awg" ]; then
        for awg_file in "$ROOT_DIR"/etc/awg/*.conf; do
            [ -f "$awg_file" ] || continue
            dest="$AWG_DIR/${awg_file##*/}"
            [ -e "$dest" ] || install -Dm600 "$awg_file" "$dest"
        done
    fi
    for list_name in warp_lists.txt warp_ips.txt; do
        src_list=$ROOT_DIR/etc/$list_name
        dst_list=$CONF_DIR/$list_name
        [ -f "$src_list" ] || continue
        if [ -e "$dst_list" ] && ! cmp -s "$src_list" "$dst_list"; then
            backup_list=$dst_list.rawveil-backup.$(date +%Y%m%d-%H%M%S)
            cp -a "$dst_list" "$backup_list"
            log "backed up changed $list_name to $backup_list"
        fi
        install -Dm644 "$src_list" "$dst_list"
    done
    install_unit

    log "installed: $BIN_DIR/rawveil"
    log "installed: $HOST_HELPER"
    log "config:    $CONF"
    log "service is NOT enabled at boot (safe default)"
    log "run:       sudo $HOST_HELPER run    # foreground"
    log "or:        sudo systemctl start rawveil-host"
    log "stop:      sudo $0 stop"
}

do_stop() {
    need_root
    if command -v systemctl >/dev/null 2>&1 &&
       systemctl list-unit-files rawveil-host.service >/dev/null 2>&1; then
        systemctl stop rawveil-host.service 2>/dev/null || true
    fi
    if [ -x "$HOST_HELPER" ]; then
        "$HOST_HELPER" stop || true
    else
        nft delete table netdev rawveil_host >/dev/null 2>&1 || true
        nft delete table inet rawveil_quic >/dev/null 2>&1 || true
        nft delete table inet rawveil_dns >/dev/null 2>&1 || true
        ip link del rvhost0 >/dev/null 2>&1 || true
    fi
    log "stopped; capture rules removed"
}

do_start() {
    need_root
    [ -x "$HOST_HELPER" ] || die "run '$0 install' first"
    if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
        systemctl start rawveil-host.service
        log "rawveil-host.service started"
    else
        exec "$HOST_HELPER" run
    fi
}

do_restart() {
    need_root
    do_stop
    do_start
}

do_status() {
    if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
        systemctl status rawveil-host.service --no-pager 2>/dev/null || true
    fi
    [ -x "$HOST_HELPER" ] && "$HOST_HELPER" status || true
}

do_reset() {
    need_root
    do_stop
    do_uninstall

    # The DoT drop-in was added manually during troubleshooting, not by
    # install.sh.  Remove it so DNS returns to the previous resolver setup.
    rm -f /etc/systemd/resolved.conf.d/rawveil-dot.conf
    if command -v resolvectl >/dev/null 2>&1; then
        resolvectl revert wlan0 >/dev/null 2>&1 || true
    fi
    if command -v systemctl >/dev/null 2>&1; then
        systemctl restart systemd-resolved >/dev/null 2>&1 || true
        systemctl daemon-reload >/dev/null 2>&1 || true
    fi

    nft delete table netdev rawveil_host >/dev/null 2>&1 || true
    nft delete table inet rawveil_quic >/dev/null 2>&1 || true
    nft delete table inet rawveil_dns >/dev/null 2>&1 || true
    ip link del rvhost0 >/dev/null 2>&1 || true
    rm -rf /run/rawveil-host /var/lib/rawveil

    log "reset complete"
    log "  nft/dummy: removed"
    log "  rawveil-host service/helper: removed"
    log "  rawveil config: restored or removed by uninstall"
    log "  DoT drop-in: removed"
    log "  DNS resolver: restored to system defaults"
}

do_uninstall() {
    need_root
    do_stop
    if command -v systemctl >/dev/null 2>&1; then
        systemctl disable rawveil-host.service >/dev/null 2>&1 || true
    fi
    rm -f "$UNIT" "$ENV_FILE" "$BIN_DIR/rawveil" "$HOST_HELPER"
    if command -v systemctl >/dev/null 2>&1; then
        systemctl daemon-reload || true
    fi

    if [ -f "$STATE_FILE" ]; then
        original=$(sed -n 's/^original=//p' "$STATE_FILE" | head -n1)
        if [ -n "$original" ] && [ -f "$original" ]; then
            install -Dm644 "$original" "$CONF"
            log "restored original config from $original"
        else
            rm -f "$CONF"
            log "removed generated config (no original existed)"
        fi
        rm -f "$STATE_FILE"
    fi
    log "uninstalled; backups remain in $BACKUP_DIR"
}

usage() {
    cat >&2 <<EOF
Usage: $0 {install|start|stop|restart|status|uninstall|reset|cleanup}

  install     build and install binary/helper/service; back up existing config
  start       start systemd service (or run in foreground without systemd)
  stop        stop RawVeil and remove temporary nft/dummy/AWG state
  restart     stop then start RawVeil
  status      show service/process/table/AWG state
  uninstall   stop, remove files, restore original config if one was backed up
  reset       full rollback including DoT drop-in and runtime state
  cleanup     remove stale nft/dummy/AWG state without starting RawVeil
EOF
}

case "${1:-install}" in
    install) do_install ;;
    start) do_start ;;
    stop) do_stop ;;
    restart) do_restart ;;
    status) do_status ;;
    uninstall) do_uninstall ;;
    reset) do_reset ;;
    cleanup)
        need_root
        if [ -x "$HOST_HELPER" ]; then "$HOST_HELPER" cleanup; else
            nft delete table netdev rawveil_host >/dev/null 2>&1 || true
            nft delete table inet rawveil_quic >/dev/null 2>&1 || true
            nft delete table inet rawveil_dns >/dev/null 2>&1 || true
            ip link del rvhost0 >/dev/null 2>&1 || true
        fi
        ;;
    -h|--help|help) usage ;;
    *) usage; exit 2 ;;
esac

