#!/bin/sh
# Isolated AWG route-mode test.
#
# It runs only inside a private user+network namespace. A dummy awg0
# interface is created so no host interface, route or nftables state is
# touched. The AWG .conf is synthetic; no real tunnel traffic is sent.
set -eu

if [ "${RV_TEST_NETNS:-0}" != "1" ]; then
    if unshare -Urn true >/dev/null 2>&1; then
        echo "entering private user+network namespace..."
        exec unshare -Urn env RV_TEST_NETNS=1 "$0"
    fi
    echo "SKIP: unprivileged user+network namespaces are unavailable."
    echo "Use a disposable VM or: sudo ip netns add rvtest;"
    echo "sudo ip netns exec rvtest env RV_TEST_NETNS=1 $0"
    exit 0
fi

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
BIN="$ROOT/build/rawveil"
TMP=$(mktemp -d "${TMPDIR:-/tmp}/rawveil-awg-netns.XXXXXX")
PID=""
cleanup() {
    if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
        kill -TERM "$PID" 2>/dev/null || true
        wait "$PID" 2>/dev/null || true
    fi
    rm -rf "$TMP"
    return 0
}
trap cleanup EXIT INT TERM

[ -x "$BIN" ] || {
    echo "FAIL: $BIN is missing; run 'make' first" >&2
    exit 1
}
command -v ip >/dev/null 2>&1 || {
    echo "FAIL: iproute2 is required" >&2
    exit 1
}

ip link set lo up
ip link add awg0 type dummy
ip link set awg0 up
ip addr add 172.16.0.2/32 dev awg0

cat > "$TMP/awg0.conf" <<EOF
[Interface]
Address = 172.16.0.2/32
MTU = 1280
Table = off
PrivateKey = synthetic-test-key

[Peer]
PublicKey = synthetic-test-peer
AllowedIPs = 0.0.0.0/0
EOF

printf '1.2.3.4\n10.0.0.0/8\n' > "$TMP/warp_ips.txt"

cat > "$TMP/rawveil.conf" <<EOF
[global]
interface = lo
send_interface = lo
threads = 1
buffer_size = 65535
pid_file = $TMP/rawveil.pid
stats_file = $TMP/rawveil.stats

[warp]
enabled = true
awg_config = $TMP/awg0.conf
interface = awg0
domain_list =
ip_list = $TMP/warp_ips.txt
manage_routing = true
routing_mode = route
mark = 0x1
bypass_strategies = true

[security]
drop_privileges_to =
EOF

"$BIN" on --foreground --config "$TMP/rawveil.conf" \
    --log-level debug >"$TMP/daemon.log" 2>&1 &
PID=$!

i=0
while [ "$i" -lt 50 ]; do
    grep -q 'routing: route mode' "$TMP/daemon.log" && break
    kill -0 "$PID" 2>/dev/null || break
    sleep 0.1
    i=$((i + 1))
done
if ! grep -q 'routing: route mode' "$TMP/daemon.log"; then
    cat "$TMP/daemon.log" >&2
    echo "FAIL: RawVeil did not install AWG routes" >&2
    exit 1
fi

if ! ip route show proto 247 | grep -q '1.2.3.4'; then
    ip route show table main >&2 || true
    echo "FAIL: 1.2.3.4 route was not installed" >&2
    exit 1
fi
if ! ip route get 1.2.3.4 | grep -q 'dev awg0'; then
    echo "FAIL: route lookup for 1.2.3.4 does not use awg0" >&2
    exit 1
fi

if ! "$BIN" off --pid-file "$TMP/rawveil.pid" \
        >"$TMP/off.log" 2>&1; then
    cat "$TMP/off.log" >&2
    echo "FAIL: rawveil off failed" >&2
    exit 1
fi
PID=""

if ip route show proto 247 | grep -q '1.2.3.4'; then
    echo "FAIL: AWG routes were not cleaned up" >&2
    exit 1
fi

echo "AWG route-mode netns test passed"
