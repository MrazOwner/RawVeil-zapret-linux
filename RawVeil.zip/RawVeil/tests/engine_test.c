#include "config.h"
#include "packet.h"
#include "strategies.h"

#include <stdio.h>
#include <string.h>

static int failures;

static void check(int condition, const char *name)
{
    if (condition) {
        printf("ok:   %s\n", name);
    } else {
        printf("FAIL: %s\n", name);
        failures++;
    }
}

static void put16(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v >> 8);
    p[1] = (uint8_t)(v & 0xffu);
}

static void put24(uint8_t *p, size_t v)
{
    p[0] = (uint8_t)((v >> 16) & 0xffu);
    p[1] = (uint8_t)((v >> 8) & 0xffu);
    p[2] = (uint8_t)(v & 0xffu);
}

static size_t build_client_hello(uint8_t *buf, size_t bufsz,
                                 const char *hostname)
{
    size_t p = 5;
    size_t hs_start = p;
    size_t body_start;
    size_t ext_total;
    size_t ext_data;
    size_t ext_len_pos;
    size_t host_len = strlen(hostname);

    if (bufsz < 128 + host_len) {
        return 0;
    }
    memset(buf, 0, bufsz);
    buf[0] = 0x16;
    buf[1] = 0x03;
    buf[2] = 0x01;
    p += 4;
    body_start = p;
    put16(buf + p, 0x0303);
    p += 2;
    for (int i = 0; i < 32; i++) {
        buf[p++] = (uint8_t)(i + 1);
    }
    buf[p++] = 0;
    put16(buf + p, 2);
    p += 2;
    put16(buf + p, 0x1301);
    p += 2;
    buf[p++] = 1;
    buf[p++] = 0;

    ext_total = p;
    p += 2;
    ext_data = p;
    put16(buf + p, 0x0000);
    p += 2;
    ext_len_pos = p;
    p += 2;
    put16(buf + p, (uint16_t)(1 + 2 + host_len));
    p += 2;
    buf[p++] = 0;
    put16(buf + p, (uint16_t)host_len);
    p += 2;
    memcpy(buf + p, hostname, host_len);
    p += host_len;
    put16(buf + ext_len_pos, (uint16_t)(p - (ext_len_pos + 2)));
    put16(buf + ext_total, (uint16_t)(p - ext_data));

    buf[hs_start] = 0x01;
    put24(buf + hs_start + 1, p - body_start);
    put16(buf + 3, (uint16_t)(p - 5));
    return p;
}

static size_t make_tcp_frame(uint8_t *frame, uint16_t dport,
                             const uint8_t *payload, size_t payload_len,
                             uint32_t seq, uint32_t ack)
{
    uint8_t *ip = frame + 14;
    uint8_t *tcp = ip + 20;

    memset(frame, 0, 768);
    put16(frame + 12, 0x0800);
    ip[0] = 0x45;
    put16(ip + 2, (uint16_t)(20 + 20 + payload_len));
    put16(ip + 4, 0x2222);
    ip[8] = 64;
    ip[9] = 6;
    ip[12] = 10;
    ip[15] = 1;
    ip[16] = 1;
    ip[19] = 2;
    put16(tcp, 44444);
    put16(tcp + 2, dport);
    tcp[4] = (uint8_t)(seq >> 24);
    tcp[5] = (uint8_t)(seq >> 16);
    tcp[6] = (uint8_t)(seq >> 8);
    tcp[7] = (uint8_t)seq;
    tcp[8] = (uint8_t)(ack >> 24);
    tcp[9] = (uint8_t)(ack >> 16);
    tcp[10] = (uint8_t)(ack >> 8);
    tcp[11] = (uint8_t)ack;
    tcp[12] = 5 << 4;
    tcp[13] = 0x18;
    put16(tcp + 14, 65535);
    memcpy(tcp + 20, payload, payload_len);
    return 14 + 20 + 20 + payload_len;
}

static size_t make_udp_frame(uint8_t *frame, uint16_t dport,
                             const uint8_t *payload, size_t payload_len)
{
    uint8_t *ip = frame + 14;
    uint8_t *udp = ip + 20;

    memset(frame, 0, 256);
    put16(frame + 12, 0x0800);
    ip[0] = 0x45;
    put16(ip + 2, (uint16_t)(20 + 8 + payload_len));
    put16(ip + 4, 0x3333);
    ip[8] = 64;
    ip[9] = 17;
    ip[12] = 10;
    ip[15] = 1;
    ip[16] = 1;
    ip[19] = 2;
    put16(udp, 5000);
    put16(udp + 2, dport);
    put16(udp + 4, (uint16_t)(8 + payload_len));
    memcpy(udp + 8, payload, payload_len);
    return 14 + 20 + 8 + payload_len;
}

int main(void)
{
    rv_config cfg;
    rv_engine *engine;
    rv_engine_stats before;
    rv_engine_stats after;
    rv_packet pkt;
    uint8_t hello[512];
    uint8_t frame[768];
    uint8_t stun[20];
    size_t hello_len;
    size_t frame_len;
    char err[256];
    int i;

    rv_config_defaults(&cfg);
    if (rv_config_load(&cfg, "tests/engine_test.conf", 1) < 0) {
        printf("FAIL: cannot load tests/engine_test.conf\n");
        rv_config_free(&cfg);
        return 1;
    }
    err[0] = '\0';
    engine = rv_engine_create_offline(&cfg, ".", err, sizeof(err));
    if (engine == NULL) {
        printf("FAIL: offline engine: %s\n", err);
        rv_config_free(&cfg);
        return 1;
    }

    hello_len = build_client_hello(hello, sizeof(hello), "engine.test");
    frame_len = make_tcp_frame(frame, 443, hello, hello_len, 1000, 2000);
    check(rv_packet_parse(&pkt, frame, frame_len) == 1,
          "parse TLS/TCP frame");

    rv_engine_get_stats(engine, &before);
    check(rv_engine_handle(engine, &pkt, frame, frame_len) == 1,
          "handle TLS ClientHello");
    rv_engine_get_stats(engine, &after);
    check(after.strategy_packets == before.strategy_packets + 1,
          "TCP strategy applied once");
    check(after.injected_frames >= before.injected_frames + 2,
          "multisplit emitted segments");
    check(rv_engine_tracker_count(engine) == 1, "TCP flow tracked");

    rv_engine_get_stats(engine, &before);
    check(rv_engine_handle(engine, &pkt, frame, frame_len) == 1,
          "handle retransmitted ClientHello");
    rv_engine_get_stats(engine, &after);
    check(after.strategy_packets == before.strategy_packets,
          "strategy not repeated for handled flow");
    check(after.injected_frames > before.injected_frames,
          "handled flow is re-emitted");

    memset(stun, 0, sizeof(stun));
    stun[1] = 0x01;
    stun[4] = 0x21;
    stun[5] = 0x12;
    stun[6] = 0xa4;
    stun[7] = 0x42;
    frame_len = make_udp_frame(frame, 50010, stun, sizeof(stun));
    check(rv_packet_parse(&pkt, frame, frame_len) == 1,
          "parse STUN/UDP frame");

    for (i = 0; i < 3; i++) {
        rv_engine_get_stats(engine, &before);
        check(rv_engine_handle(engine, &pkt, frame, frame_len) == 1,
              "handle STUN datagram");
        rv_engine_get_stats(engine, &after);
        if (i < 2) {
            check(after.strategy_packets == before.strategy_packets + 1,
                  "fake_session applied during freeze window");
            check(after.injected_frames == before.injected_frames + 3,
                  "fake_session emitted fakes + original");
        } else {
            check(after.strategy_packets == before.strategy_packets,
                  "fake_session frozen after threshold");
            check(after.injected_frames == before.injected_frames + 1,
                  "frozen flow only re-emits original");
        }
    }

    check(rv_engine_tracker_count(engine) == 2, "TCP and UDP flows tracked");
    rv_engine_get_stats(engine, &after);
    check(after.matched_packets == 5, "matched packet counter");
    check(after.send_errors == 0, "no offline send errors");

    rv_engine_destroy(engine);
    rv_config_free(&cfg);

    if (failures != 0) {
        printf("%d engine test(s) failed\n", failures);
        return 1;
    }
    printf("all engine tests passed\n");
    return 0;
}
