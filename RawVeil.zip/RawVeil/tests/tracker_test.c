#include "tracker.h"

#include <netinet/in.h>
#include <stdio.h>
#include <string.h>

static int failures;

static void key4(rv_flow_key *key, int proto, uint16_t sport, uint16_t dport)
{
    memset(key, 0, sizeof(*key));
    key->family = AF_INET;
    key->proto = proto;
    key->src[0] = 10;
    key->src[3] = 1;
    key->dst[0] = 1;
    key->dst[1] = 1;
    key->dst[2] = 1;
    key->dst[3] = 1;
    key->sport = sport;
    key->dport = dport;
}

static void check(int condition, const char *name)
{
    if (condition) {
        printf("ok:   %s\n", name);
    } else {
        printf("FAIL: %s\n", name);
        failures++;
    }
}

int main(void)
{
    rv_tracker *tracker = rv_tracker_create(8, 10, 5);
    rv_flow_key key;
    rv_tracker_view view;

    if (tracker == NULL) {
        printf("FAIL: tracker create\n");
        return 1;
    }
    key4(&key, 6, 12345, 443);
    check(rv_tracker_touch(tracker, &key, 1000, &view) == 1,
          "new flow");
    check(view.packets_seen == 1 && !view.handled && !view.frozen,
          "new flow state");
    check(rv_tracker_touch(tracker, &key, 1001, &view) == 0,
          "existing flow");
    check(view.packets_seen == 2, "packet counter");

    rv_tracker_set_flags(tracker, &key, 1, 0);
    check(rv_tracker_touch(tracker, &key, 1002, &view) == 0 &&
          view.handled && view.packets_seen == 3,
          "flags preserved");
    check(rv_tracker_count(tracker) == 1, "tracker count");

    rv_tracker_expire(tracker, 1012); /* tcp_timeout=10, last_seen=1002 */
    check(rv_tracker_count(tracker) == 1, "not expired at boundary");
    rv_tracker_expire(tracker, 1013);
    check(rv_tracker_count(tracker) == 0, "expired by timeout");

    key4(&key, 17, 5000, 50001);
    check(rv_tracker_touch(tracker, &key, 2000, &view) == 1,
          "new UDP flow");
    rv_tracker_set_flags(tracker, &key, 0, 1);
    check(rv_tracker_touch(tracker, &key, 2001, &view) == 0 && view.frozen,
          "frozen flag preserved");
    rv_tracker_expire(tracker, 2007); /* udp_timeout=5 */
    check(rv_tracker_count(tracker) == 0, "UDP timeout");

    {
        int i;
        for (i = 0; i < 40; i++) {
            key4(&key, 6, (uint16_t)(20000 + i), 443);
            (void)rv_tracker_touch(tracker, &key, 3000 + i, &view);
        }
        check(rv_tracker_count(tracker) <= 8, "max_entries enforced");
    }

    rv_tracker_clear(tracker);
    check(rv_tracker_count(tracker) == 0, "clear");
    rv_tracker_destroy(tracker);

    if (failures != 0) {
        printf("%d tracker test(s) failed\n", failures);
        return 1;
    }
    printf("all tracker tests passed\n");
    return 0;
}
