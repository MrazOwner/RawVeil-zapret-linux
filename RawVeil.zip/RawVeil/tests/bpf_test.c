/*
 * Userspace tests for the classic BPF egress filter.
 *
 * The kernel verifier and SO_ATTACH_FILTER are not available without
 * CAP_NET_RAW, so this test executes the generated program in a small cBPF
 * interpreter against synthetic Ethernet frames. It catches port/offset and
 * VLAN/IPv6 logic mistakes before the daemon ever touches a live interface.
 */
#include "bpf_filter.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>

static int g_interp_error;

static uint16_t get_u16(const uint8_t *p)
{
    return (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
}

static void set_u16(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v >> 8);
    p[1] = (uint8_t)(v & 0xffu);
}

static uint32_t read_abs(const uint8_t *pkt, size_t len, uint32_t off,
                         size_t size)
{
    if ((size_t)off + size > len) {
        g_interp_error = 0; /* kernel BPF semantics: short load -> reject */
        return 0;
    }
    if (size == 1) {
        return pkt[off];
    }
    if (size == 2) {
        return get_u16(pkt + off);
    }
    return ((uint32_t)pkt[off] << 24) |
           ((uint32_t)pkt[off + 1] << 16) |
           ((uint32_t)pkt[off + 2] << 8) |
           (uint32_t)pkt[off + 3];
}

static uint32_t run_filter(const struct sock_filter *insns, size_t count,
                           const uint8_t *pkt, size_t len)
{
    uint32_t a = 0;
    uint32_t x = 0;
    size_t pc = 0;
    size_t steps = 0;

    g_interp_error = 0;
    while (pc < count && steps++ < 4096) {
        const struct sock_filter *in = &insns[pc];
        uint16_t code = in->code;

        if (code == (BPF_LD | BPF_W | BPF_ABS) ||
            code == (BPF_LD | BPF_H | BPF_ABS) ||
            code == (BPF_LD | BPF_B | BPF_ABS)) {
            uint16_t sizebits = (uint16_t)(code & 0x18u);
            size_t size = sizebits == BPF_H ? 2u :
                          (sizebits == BPF_B ? 1u : 4u);
            if ((size_t)in->k + size > len) {
                return 0;
            }
            a = read_abs(pkt, len, in->k, size);
            pc++;
            continue;
        }
        if (code == (BPF_LD | BPF_W | BPF_IND) ||
            code == (BPF_LD | BPF_H | BPF_IND) ||
            code == (BPF_LD | BPF_B | BPF_IND)) {
            uint16_t sizebits = (uint16_t)(code & 0x18u);
            size_t size = sizebits == BPF_H ? 2u :
                          (sizebits == BPF_B ? 1u : 4u);
            uint32_t off = x + in->k;
            if ((size_t)off + size > len) {
                return 0;
            }
            a = read_abs(pkt, len, off, size);
            pc++;
            continue;
        }
        if (code == (BPF_LDX | BPF_B | BPF_MSH)) {
            if ((size_t)in->k >= len) {
                return 0;
            }
            x = (uint32_t)(pkt[in->k] & 0x0fu) * 4u;
            pc++;
            continue;
        }
        if (code == (BPF_JMP | BPF_JA)) {
            pc += 1u + in->k;
            continue;
        }
        if (code == (BPF_JMP | BPF_JEQ | BPF_K) ||
            code == (BPF_JMP | BPF_JSET | BPF_K) ||
            code == (BPF_JMP | BPF_JGE | BPF_K) ||
            code == (BPF_JMP | BPF_JGT | BPF_K)) {
            int taken = 0;
            if (code == (BPF_JMP | BPF_JEQ | BPF_K)) {
                taken = a == in->k;
            } else if (code == (BPF_JMP | BPF_JSET | BPF_K)) {
                taken = (a & in->k) != 0;
            } else if (code == (BPF_JMP | BPF_JGE | BPF_K)) {
                taken = a >= in->k;
            } else {
                taken = a > in->k;
            }
            pc += 1u + (taken ? in->jt : in->jf);
            continue;
        }
        if (code == (BPF_RET | BPF_K)) {
            return in->k;
        }
        g_interp_error = 1;
        return 0;
    }
    g_interp_error = 1;
    return 0;
}

static size_t build_ipv4(uint8_t *pkt, int vlan, int proto,
                         uint16_t sport, uint16_t dport, uint16_t frag)
{
    size_t l3 = 14;
    size_t l4_len = proto == 6 ? 20u : 8u;

    memset(pkt, 0, 256);
    if (vlan) {
        set_u16(pkt + 12, 0x8100);
        set_u16(pkt + 14, 0x0064); /* VLAN id 100 */
        set_u16(pkt + 16, 0x0800);
        l3 = 18;
    } else {
        set_u16(pkt + 12, 0x0800);
    }
    pkt[l3] = 0x45;
    set_u16(pkt + l3 + 2, (uint16_t)(20u + l4_len));
    pkt[l3 + 8] = 64;
    pkt[l3 + 9] = (uint8_t)proto;
    set_u16(pkt + l3 + 6, frag);
    pkt[l3 + 12] = 192;
    pkt[l3 + 13] = 0;
    pkt[l3 + 14] = 2;
    pkt[l3 + 15] = 1;
    pkt[l3 + 16] = 198;
    pkt[l3 + 17] = 51;
    pkt[l3 + 18] = 100;
    pkt[l3 + 19] = 7;
    set_u16(pkt + l3 + 20, sport);
    set_u16(pkt + l3 + 22, dport);
    return l3 + 20u + l4_len;
}

static size_t build_ipv6(uint8_t *pkt, int vlan, int proto,
                         uint16_t sport, uint16_t dport)
{
    size_t l3 = 14;
    size_t l4_len = proto == 6 ? 20u : 8u;

    memset(pkt, 0, 256);
    if (vlan) {
        set_u16(pkt + 12, 0x88a8);
        set_u16(pkt + 14, 0x0064);
        set_u16(pkt + 16, 0x86dd);
        l3 = 18;
    } else {
        set_u16(pkt + 12, 0x86dd);
    }
    pkt[l3] = 0x60;
    set_u16(pkt + l3 + 4, (uint16_t)l4_len);
    pkt[l3 + 6] = (uint8_t)proto;
    pkt[l3 + 7] = 64;
    pkt[l3 + 8] = 0x20;
    pkt[l3 + 9] = 0x01;
    pkt[l3 + 24] = 0x20;
    pkt[l3 + 25] = 0x01;
    pkt[l3 + 40] = (uint8_t)(sport >> 8);
    pkt[l3 + 41] = (uint8_t)(sport & 0xffu);
    pkt[l3 + 42] = (uint8_t)(dport >> 8);
    pkt[l3 + 43] = (uint8_t)(dport & 0xffu);
    return l3 + 40u + l4_len;
}

static int failures;

static void expect(int vlan, int ipv6, int proto,
                   uint16_t sport, uint16_t dport, uint16_t frag,
                   int expected, const char *name)
{
    static uint8_t pkt[256];
    size_t len;
    uint32_t ret;
    rv_bpf_program prog;

    if (rv_bpf_build_egress_filter(&prog) < 0) {
        printf("FAIL: cannot build BPF program\n");
        failures++;
        return;
    }
    if (ipv6) {
        len = build_ipv6(pkt, vlan, proto, sport, dport);
    } else {
        len = build_ipv4(pkt, vlan, proto, sport, dport, frag);
    }
    ret = run_filter(prog.insns, prog.count, pkt, len);
    if (g_interp_error) {
        printf("FAIL: %-42s interpreter error\n", name);
        failures++;
        return;
    }
    if ((ret != 0) != expected) {
        printf("FAIL: %-42s expected %s, got %s\n", name,
               expected ? "ACCEPT" : "REJECT",
               ret != 0 ? "ACCEPT" : "REJECT");
        failures++;
        return;
    }
    printf("ok:   %s\n", name);
}

int main(void)
{
    expect(0, 0, 6, 12345, 443, 0, 1, "IPv4 TCP dst 443");
    expect(0, 0, 6, 443, 12345, 0, 1, "IPv4 TCP src 443");
    expect(0, 0, 6, 12345, 80, 0, 0, "IPv4 TCP dst 80 rejected");
    expect(0, 0, 6, 12345, 2053, 0, 1, "IPv4 TCP dst 2053");
    expect(0, 0, 6, 12345, 8443, 0, 1, "IPv4 TCP dst 8443");
    expect(0, 0, 6, 12345, 2052, 0, 0, "IPv4 TCP dst 2052 rejected");
    expect(0, 1, 6, 12345, 2087, 0, 1, "IPv6 TCP dst 2087");
    expect(1, 1, 6, 12345, 2096, 0, 1, "VLAN IPv6 TCP dst 2096");
    expect(0, 0, 17, 12345, 443, 0, 1, "IPv4 UDP dst 443");
    expect(0, 0, 17, 50000, 12345, 0, 1, "IPv4 UDP src 50000");
    expect(0, 0, 17, 12345, 50099, 0, 1, "IPv4 UDP dst 50099");
    expect(0, 0, 17, 12345, 49999, 0, 0, "IPv4 UDP 49999 rejected");
    expect(0, 0, 17, 12345, 50100, 0, 0, "IPv4 UDP 50100 rejected");
    expect(0, 0, 6, 12345, 443, 1, 0, "IPv4 non-first fragment rejected");
    expect(1, 0, 6, 12345, 443, 0, 1, "VLAN IPv4 TCP dst 443");
    expect(1, 0, 17, 50050, 12345, 0, 1, "VLAN IPv4 UDP src 50050");
    expect(0, 1, 6, 12345, 443, 0, 1, "IPv6 TCP dst 443");
    expect(0, 1, 17, 12345, 50099, 0, 1, "IPv6 UDP dst 50099");
    expect(0, 1, 17, 12345, 50100, 0, 0, "IPv6 UDP 50100 rejected");
    expect(1, 1, 6, 443, 12345, 0, 1, "VLAN IPv6 TCP src 443");
    expect(1, 1, 17, 50000, 12345, 0, 1, "VLAN IPv6 UDP src 50000");
    expect(0, 0, 1, 0, 0, 0, 0, "ICMP rejected");

    {
        static uint8_t short_pkt[10] = {0};
        rv_bpf_program prog;
        uint32_t ret;
        if (rv_bpf_build_egress_filter(&prog) < 0) {
            printf("FAIL: cannot build BPF program\n");
            return 1;
        }
        ret = run_filter(prog.insns, prog.count, short_pkt,
                         sizeof(short_pkt));
        if (ret != 0 || g_interp_error) {
            printf("FAIL: short frame must be rejected\n");
            failures++;
        } else {
            printf("ok:   short frame rejected\n");
        }
    }

    if (failures != 0) {
        printf("%d BPF test(s) failed\n", failures);
        return 1;
    }
    printf("all BPF tests passed\n");
    return 0;
}
