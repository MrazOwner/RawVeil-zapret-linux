#include "awg.h"
#include "config.h"
#include "routing.h"
#include "warp.h"

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static int failures;

static void check(int condition, const char *name)
{
    if (condition) {
        printf("ok:   %s\n", name);
    } else {
        printf("FAIL: %s\n", name);
        failures++;
    }
}

static int write_file(const char *path, const char *text, mode_t mode)
{
    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, mode);
    size_t len = strlen(text);

    if (fd < 0) {
        return -1;
    }
    if (write(fd, text, len) != (ssize_t)len) {
        close(fd);
        return -1;
    }
    close(fd);
    return 0;
}

static int file_contains(const char *path, const char *needle)
{
    FILE *fp = fopen(path, "r");
    char line[2048];
    int found = 0;

    if (fp == NULL) {
        return 0;
    }
    while (fgets(line, sizeof(line), fp) != NULL) {
        if (strstr(line, needle) != NULL) {
            found = 1;
            break;
        }
    }
    fclose(fp);
    return found;
}

int main(void)
{
    char dir[] = "/tmp/rawveil-routing.XXXXXX";
    char ip_tool[512];
    char nft_tool[512];
    char ip_list[512];
    char ip_log[512];
    char nft_log[512];
    rv_config cfg;
    rv_awg_config awg;
    rv_warp *warp;
    rv_routing routing;
    char err[256];

    if (mkdtemp(dir) == NULL) {
        printf("FAIL: mkdtemp\n");
        return 1;
    }
    snprintf(ip_tool, sizeof(ip_tool), "%s/ip", dir);
    snprintf(nft_tool, sizeof(nft_tool), "%s/nft", dir);
    snprintf(ip_list, sizeof(ip_list), "%s/warp_ips.txt", dir);
    snprintf(ip_log, sizeof(ip_log), "%s/ip.log", dir);
    snprintf(nft_log, sizeof(nft_log), "%s/nft.log", dir);

    if (write_file(ip_tool,
                   "#!/bin/sh\n"
                   "printf '%s\\n' \"$*\" >> \"$RAWVEIL_FAKE_IP_LOG\"\n"
                   "exit 0\n", 0755) < 0 ||
        write_file(nft_tool,
                   "#!/bin/sh\n"
                   "printf 'ARGS:%s\\n' \"$*\" >> \"$RAWVEIL_FAKE_NFT_LOG\"\n"
                   "case \"$*\" in\n"
                   "  *\"-f -\"*) cat >> \"$RAWVEIL_FAKE_NFT_LOG\" ;;\n"
                   "esac\n"
                   "exit 0\n", 0755) < 0 ||
        write_file(ip_list, "1.2.3.4\n10.0.0.0/8\n0.0.0.0/0\n", 0644) < 0) {
        printf("FAIL: cannot create test fixtures\n");
        return 1;
    }
    setenv("RAWVEIL_IP_TOOL", ip_tool, 1);
    setenv("RAWVEIL_NFT_TOOL", nft_tool, 1);
    setenv("RAWVEIL_FAKE_IP_LOG", ip_log, 1);
    setenv("RAWVEIL_FAKE_NFT_LOG", nft_log, 1);

    rv_config_defaults(&cfg);
    rv_strlcpy(cfg.warp.interface, sizeof(cfg.warp.interface), "lo");
    cfg.warp.enabled = 1;
    cfg.warp.domain_list[0] = '\0';
    rv_strlcpy(cfg.warp.ip_list, sizeof(cfg.warp.ip_list), ip_list);
    rv_strlcpy(cfg.warp.awg_config, sizeof(cfg.warp.awg_config), "fake");
    cfg.warp.manage_routing = 1;
    cfg.warp.routing_mode = RV_ROUTING_ROUTE;
    cfg.warp.mark = 0x1;
    cfg.warp.routing_table = 51821;
    cfg.warp.routing_priority = 1000;

    memset(&awg, 0, sizeof(awg));
    rv_strlcpy(awg.interface, sizeof(awg.interface), "lo");
    awg.has_ipv4 = 1;
    awg.default_route_v4 = 1;

    warp = rv_warp_create(&cfg.warp, err, sizeof(err));
    if (warp == NULL) {
        printf("FAIL: warp create: %s\n", err);
        rv_config_free(&cfg);
        return 1;
    }
    memset(&routing, 0, sizeof(routing));

    err[0] = '\0';
    check(rv_routing_setup(&routing, &cfg.warp, &awg, warp,
                           err, sizeof(err)) == 0,
          "route-mode routing setup");
    check(routing.active && routing.mode == RV_ROUTING_ROUTE,
          "route-mode state");
    check(file_contains(ip_log, "route replace 1.2.3.4/32 dev lo proto 247"),
          "exact WARP route added");
    check(file_contains(ip_log, "route replace 10.0.0.0/8 dev lo proto 247"),
          "CIDR WARP route added");
    check(!file_contains(ip_log, "route replace 0.0.0.0/0"),
          "default route refused in split mode");
    rv_routing_cleanup(&routing);
    check(!routing.active, "route-mode cleanup");
    check(file_contains(ip_log, "route flush proto 247"),
          "route-mode stale cleanup");

    cfg.warp.routing_mode = RV_ROUTING_NFT;
    err[0] = '\0';
    check(rv_routing_setup(&routing, &cfg.warp, &awg, warp,
                           err, sizeof(err)) == 0,
          "nft-mode routing setup");
    check(file_contains(nft_log, "meta mark set 0x1"),
          "nft mark rule generated");
    check(file_contains(nft_log, "add element inet rawveil warp4"),
          "nft set elements generated");
    check(file_contains(ip_log, "rule add fwmark 0x1 table 51821"),
          "ip rule added");
    rv_routing_cleanup(&routing);
    check(file_contains(nft_log, "ARGS:delete table inet rawveil"),
          "nft cleanup");

    rv_warp_destroy(warp);
    rv_config_free(&cfg);

    unlink(ip_tool);
    unlink(nft_tool);
    unlink(ip_list);
    unlink(ip_log);
    unlink(nft_log);
    rmdir(dir);

    if (failures != 0) {
        printf("%d routing test(s) failed\n", failures);
        return 1;
    }
    printf("all routing tests passed\n");
    return 0;
}
