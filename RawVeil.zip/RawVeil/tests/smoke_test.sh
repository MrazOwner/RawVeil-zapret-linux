#!/bin/sh
# RawVeil smoke tests.
#
# Default: safe, unprivileged CLI/config tests only.
# If unprivileged user+network namespaces are available, the script re-execs
# itself inside `unshare -Urn` and additionally exercises AF_PACKET capture on
# a private loopback interface. It never touches the host network, nftables or
# any real interface.
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
BIN="$ROOT/build/rawveil"
BASIC_TMP=""
CAPTURE_TMP=""
DAEMON_PID=""

cleanup() {
    if [ -n "$DAEMON_PID" ] && kill -0 "$DAEMON_PID" 2>/dev/null; then
        kill -TERM "$DAEMON_PID" 2>/dev/null || true
        wait "$DAEMON_PID" 2>/dev/null || true
    fi
    if [ -n "$BASIC_TMP" ]; then
        rm -rf "$BASIC_TMP"
    fi
    if [ -n "$CAPTURE_TMP" ]; then
        rm -rf "$CAPTURE_TMP"
    fi
    return 0
}
trap cleanup EXIT INT TERM

fail() {
    echo "FAIL: $*" >&2
    if [ -n "${CAPTURE_TMP:-}" ] &&
       [ -f "$CAPTURE_TMP/daemon.log" ]; then
        echo "--- daemon.log (tail) ---" >&2
        tail -100 "$CAPTURE_TMP/daemon.log" >&2 || true
        echo "--- end daemon.log ---" >&2
    fi
    exit 1
}

if [ ! -x "$BIN" ]; then
    echo "FAIL: $BIN is missing; run 'make' first" >&2
    exit 1
fi

run_basic_tests() {
    BASIC_TMP=$(mktemp -d "${TMPDIR:-/tmp}/rawveil-basic.XXXXXX")

    "$BIN" --version | grep -q '^rawveil ' ||
        fail "--version output"
    "$BIN" --help | grep -q 'Usage:' ||
        fail "--help output"

    printf '[global]\nthreads = nope\n' > "$BASIC_TMP/bad.conf"
    if "$BIN" on --foreground --config "$BASIC_TMP/bad.conf" \
            >"$BASIC_TMP/bad.log" 2>&1; then
        fail "invalid config was accepted"
    fi

    printf '[doh]\nenabled = true\nmode = builtin\n' \
        > "$BASIC_TMP/doh.conf"
    if "$BIN" on --foreground --config "$BASIC_TMP/doh.conf" \
            >"$BASIC_TMP/doh.log" 2>&1; then
        fail "unimplemented doh mode was accepted"
    fi

    if "$BIN" on --foreground --config "$BASIC_TMP/bad.conf" \
            --profile broken >"$BASIC_TMP/profile.log" 2>&1; then
        fail "malformed --profile was accepted"
    fi

    cat > "$BASIC_TMP/badprofile.conf" <<EOF
[profile.bad]
enabled = true
filter_proto = tcp
filter_ports = 443
filter_l7 = tls
strategy = multisplit
split_pos = nope
EOF
    if "$BIN" on --foreground --config "$BASIC_TMP/badprofile.conf" \
            --pid-file "$BASIC_TMP/badprofile.pid" \
            >"$BASIC_TMP/badprofile.log" 2>&1; then
        fail "invalid strategy value was accepted"
    fi

    if "$BIN" status --pid-file "$BASIC_TMP/missing.pid" \
            >"$BASIC_TMP/status.log" 2>&1; then
        fail "status reported a missing daemon as running"
    fi
    grep -q 'not running' "$BASIC_TMP/status.log" ||
        fail "status message"

    echo "basic CLI/config tests passed"
}

run_capture_test() {
    command -v ip >/dev/null 2>&1 ||
        fail "the 'ip' utility is required for the namespace test"
    command -v python3 >/dev/null 2>&1 ||
        fail "python3 is required for the packet generator"

    ip link set lo up
    CAPTURE_TMP=$(mktemp -d "${TMPDIR:-/tmp}/rawveil-netns.XXXXXX")
    cat > "$CAPTURE_TMP/rawveil.conf" <<EOF
[global]
interface = lo
threads = 1
buffer_size = 65535
log_level = debug
pid_file = $CAPTURE_TMP/rawveil.pid
stats_file = $CAPTURE_TMP/rawveil.stats

[doh]
enabled = false

[warp]
enabled = true
interface = awg0
domain_list = $CAPTURE_TMP/warp_lists.txt
ip_list = $CAPTURE_TMP/warp_ips.txt
mark = 0x123
bypass_strategies = true

[profile.smoke_tls]
enabled = true
filter_proto = tcp
filter_ports = 443
filter_l7 = tls
strategy = multisplit
split_pos = 1
segments = 2
replace_original = true

[security]
drop_privileges_to =
EOF
    cat > "$CAPTURE_TMP/warp_lists.txt" <<EOF
# no WARP domains in this test; WARP is tested via 127.0.0.2 below
EOF
    cat > "$CAPTURE_TMP/warp_ips.txt" <<EOF
# 127.0.0.2 is used only for the WARP bypass check.
# 127.0.0.1 must stay outside WARP so TLS strategy is applied to it.
127.0.0.2
EOF

    "$BIN" on --foreground --config "$CAPTURE_TMP/rawveil.conf" \
        >"$CAPTURE_TMP/daemon.log" 2>&1 &
    DAEMON_PID=$!

    i=0
    while [ "$i" -lt 50 ]; do
        if grep -q 'started; SIGTERM=stop' "$CAPTURE_TMP/daemon.log"; then
            break
        fi
        kill -0 "$DAEMON_PID" 2>/dev/null ||
            fail "daemon exited during startup (see $CAPTURE_TMP/daemon.log)"
        sleep 0.1
        i=$((i + 1))
    done
    grep -q 'started; SIGTERM=stop' "$CAPTURE_TMP/daemon.log" ||
        fail "daemon did not reach the capture loop"

    "$BIN" status --pid-file "$CAPTURE_TMP/rawveil.pid" \
        --stats-file "$CAPTURE_TMP/rawveil.stats" \
        >"$CAPTURE_TMP/status.out" 2>&1 || true
    grep -q 'running' "$CAPTURE_TMP/status.out" ||
        fail "status did not find the running daemon"

    python3 - <<'PY'
import socket

for port in (443, 80):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.2)
    try:
        s.connect(("127.0.0.1", port))
    except OSError:
        pass
    s.close()

for port in (443, 50000, 50099, 49999, 50100):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.sendto(b"rawveil-smoke", ("127.0.0.1", port))
    s.close()

# WARP bypass check: 127.0.0.2 is in warp_ips.txt, 127.0.0.1 is not.
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.settimeout(0.2)
try:
    s.connect(("127.0.0.2", 443))
except OSError:
    pass
s.close()
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.sendto(b"rawveil-warp", ("127.0.0.2", 50001))
s.close()
PY

    # Generate a real TLS ClientHello on loopback so the multisplit profile
    # has something to split. The handshake is expected to fail; only the
    # outgoing ClientHello matters.
    python3 - <<'PY'
import socket
import ssl
import threading
import time

srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(("127.0.0.1", 443))
srv.listen(1)

def accept_one():
    try:
        conn, _ = srv.accept()
        time.sleep(0.8)
        conn.close()
    except OSError:
        pass

threading.Thread(target=accept_one, daemon=True).start()
ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
sock = socket.create_connection(("127.0.0.1", 443), timeout=1)
sock.settimeout(0.4)
try:
    tls = ctx.wrap_socket(sock, server_hostname="smoke.test",
                          do_handshake_on_connect=False)
    try:
        tls.do_handshake()
    except (OSError, ssl.SSLError):
        pass
    tls.close()
except (OSError, ssl.SSLError):
    sock.close()
srv.close()
PY

    sleep 0.7
    if ! "$BIN" off --pid-file "$CAPTURE_TMP/rawveil.pid" \
            >"$CAPTURE_TMP/off.out" 2>&1; then
        fail "rawveil off failed"
    fi
    DAEMON_PID=""

    LOG="$CAPTURE_TMP/daemon.log"
    grep -q -- '-> 127.0.0.1:443 proto=tcp' "$LOG" ||
        fail "TCP/443 packet was not captured"
    grep -q -- 'proto=udp' "$LOG" ||
        fail "UDP packets were not captured"
    if ! grep -q -- ':50000 .*proto=udp' "$LOG" &&
       ! grep -q -- ':50099 .*proto=udp' "$LOG"; then
        fail "UDP/Discord-range packet was not captured"
    fi
    grep -q 'warp match' "$LOG" ||
        fail "WARP match was not logged"
    grep -q 'strategy multisplit profile=smoke_tls' "$LOG" ||
        fail "TLS multisplit strategy was not applied"
    grep -q 'strategy_applied=[1-9]' "$CAPTURE_TMP/rawveil.stats" ||
        fail "statistics do not contain applied strategies"
    grep -q 'strategy_injected_frames=[1-9]' "$CAPTURE_TMP/rawveil.stats" ||
        fail "statistics do not contain injected frames"
    grep -q 'injected_ignored=[1-9]' "$CAPTURE_TMP/rawveil.stats" ||
        fail "loop-suppression marker was not observed"
    if grep -q -- '-> 127.0.0.1:80 proto=' "$LOG"; then
        fail "TCP/80 should have been filtered out by BPF"
    fi
    if grep -q -- ':49999 .*proto=' "$LOG" ||
       grep -q -- ':50100 .*proto=' "$LOG"; then
        fail "UDP outside 50000-50099 should have been filtered by BPF"
    fi
    grep -q 'warp_matches=[1-9]' "$CAPTURE_TMP/rawveil.stats" ||
        fail "statistics do not contain WARP matches"

    echo "namespace AF_PACKET capture test passed"
}

if [ "${RV_TEST_NETNS:-0}" != "1" ]; then
    run_basic_tests
    if unshare -Urn true >/dev/null 2>&1; then
        echo "entering private network namespace..."
        if [ -n "$BASIC_TMP" ]; then
            rm -rf "$BASIC_TMP"
            BASIC_TMP=""
        fi
        exec unshare -Urn env RV_TEST_NETNS=1 \
            "$ROOT/tests/smoke_test.sh"
    fi
    echo "SKIP: unprivileged network namespaces are unavailable."
    echo "      The capture test only runs inside a private netns, never on"
    echo "      the host interface. Run as root in a disposable VM/netns to"
    echo "      exercise AF_PACKET."
    exit 0
fi

run_capture_test
