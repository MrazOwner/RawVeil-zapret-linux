#include "quic.h"

#include <stdio.h>
#include <string.h>

static int failures;

static void check(int condition, const char *name)
{
    if (condition) {
        printf("ok:   %s\n", name);
    } else {
        printf("FAIL: %s\n", name);
        failures++;
    }
}

static size_t make_initial(uint8_t *buf, size_t size)
{
    size_t pos;

    if (size < 1200) {
        return 0;
    }
    memset(buf, 0, size);
    buf[0] = 0xc0; /* long header + fixed bit, Initial candidate */
    buf[1] = 0;
    buf[2] = 0;
    buf[3] = 0;
    buf[4] = 1; /* QUIC v1 */
    buf[5] = 8;
    for (size_t i = 0; i < 8; i++) {
        buf[6 + i] = (uint8_t)(i + 1);
    }
    buf[14] = 0; /* SCID len */
    buf[15] = 0; /* token length */
    /* 2-byte varint length: PN(1) + ciphertext = total - 18 */
    buf[16] = (uint8_t)(0x40u | (((size - 18u) >> 8) & 0x3fu));
    buf[17] = (uint8_t)((size - 18u) & 0xffu);
    buf[18] = 0x00; /* PN */
    pos = 19;
    while (pos < size) {
        buf[pos] = (uint8_t)(pos * 17u);
        pos++;
    }
    return size;
}

int main(void)
{
    uint8_t buf[1400];
    rv_quic_info info;
    size_t len;

    len = make_initial(buf, sizeof(buf));
    check(rv_quic_parse(buf, len, &info) == 1, "parse Initial");
    check(info.is_long && info.is_initial, "Initial flags");
    check(info.version == RV_QUIC_VERSION_1, "Initial version");
    check(info.dcid_len == 8, "Initial DCID length");
    check(info.packet_len == len, "Initial packet length");

    buf[4] = 0;
    check(rv_quic_parse(buf, len, &info) == 1 &&
          info.is_version_negotiation, "version negotiation");

    buf[4] = 1;
    buf[0] = 0x40; /* short header */
    check(rv_quic_parse(buf, 64, &info) == 1 && info.is_short,
          "short header");

    buf[0] = 0x00;
    check(rv_quic_parse(buf, 64, &info) == 0, "not QUIC");

    len = make_initial(buf, sizeof(buf));
    check(rv_quic_parse(buf, 5, &info) == 0, "truncated long header");

    if (failures != 0) {
        printf("%d quic test(s) failed\n", failures);
        return 1;
    }
    printf("all quic tests passed\n");
    return 0;
}
