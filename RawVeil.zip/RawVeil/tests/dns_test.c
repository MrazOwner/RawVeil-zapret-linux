#include "config.h"
#include "dns.h"

#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static int failures;

static void check(int condition, const char *name)
{
    if (condition) {
        printf("ok:   %s\n", name);
    } else {
        printf("FAIL: %s\n", name);
        failures++;
    }
}

static size_t make_query(uint8_t *buf)
{
    size_t p = 12;
    const char *name = "example.com";
    const char *dot;

    memset(buf, 0, 512);
    buf[0] = 0x12;
    buf[1] = 0x34;
    buf[2] = 0x01; /* RD */
    buf[5] = 1;    /* QDCOUNT */
    for (dot = name; *dot != '\0'; dot++) {
        const char *next = strchr(dot, '.');
        size_t len = next != NULL ? (size_t)(next - dot) : strlen(dot);
        buf[p++] = (uint8_t)len;
        memcpy(buf + p, dot, len);
        p += len;
        if (next == NULL) {
            break;
        }
        dot = next;
    }
    buf[p++] = 0;
    buf[p++] = 0;
    buf[p++] = 1; /* A */
    buf[p++] = 0;
    buf[p++] = 1; /* IN */
    return p;
}

int main(void)
{
    rv_config cfg;
    rv_dns *dns;
    uint8_t query[512];
    uint8_t response[512];
    size_t query_len;
    struct sockaddr_in addr;
    char err[256];
    int fd;
    ssize_t n;

    rv_config_defaults(&cfg);
    cfg.doh.enabled = 1;
    rv_strlcpy(cfg.doh.mode, sizeof(cfg.doh.mode), "dot");
    rv_strlcpy(cfg.doh.listen, sizeof(cfg.doh.listen), "127.0.0.1:15353");
    rv_strlcpy(cfg.doh.servers, sizeof(cfg.doh.servers),
               getenv("RV_DNS_LIVE") != NULL
                   ? "1.1.1.1#cloudflare-dns.com"
                   : "127.0.0.1#cloudflare-dns.com");
    cfg.doh.cache_ttl = 0;

    err[0] = '\0';
    dns = rv_dns_start(&cfg, err, sizeof(err));
    check(dns != NULL, "start DNS proxy");
    if (dns == NULL) {
        printf("error: %s\n", err);
        return 1;
    }

    query_len = make_query(query);
    fd = socket(AF_INET, SOCK_DGRAM, 0);
    check(fd >= 0, "create UDP client");
    if (fd >= 0) {
        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_port = htons(15353);
        inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);
        n = sendto(fd, query, query_len, 0,
                   (struct sockaddr *)&addr, sizeof(addr));
        check(n == (ssize_t)query_len, "send DNS query");
        n = recv(fd, response, sizeof(response), 0);
        check(n >= 12, "receive DNS response");
        if (n >= 12) {
            check(response[0] == 0x12 && response[1] == 0x34,
                  "response ID matches");
            if (getenv("RV_DNS_LIVE") != NULL) {
                check((response[2] & 0x80u) != 0 &&
                      (response[3] & 0x0fu) == 0u,
                      "live DoT returns NOERROR");
            } else {
                check((response[2] & 0x80u) != 0 &&
                      (response[3] & 0x0fu) == 2u,
                      "unreachable DoT returns SERVFAIL");
            }
        }
        close(fd);
    }

    rv_dns_stop(dns);
    rv_config_free(&cfg);
    if (failures != 0) {
        printf("%d dns test(s) failed\n", failures);
        return 1;
    }
    printf("all dns tests passed\n");
    return 0;
}
