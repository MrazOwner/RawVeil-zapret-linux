#include "netbuild.h"
#include "packet.h"

#include <stdio.h>
#include <string.h>

static void set16(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v >> 8);
    p[1] = (uint8_t)(v & 0xffu);
}

static uint16_t get16(const uint8_t *p)
{
    return (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
}

static uint32_t get32(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | p[3];
}

static void set32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)(v & 0xffu);
}

static uint32_t sum16(const uint8_t *p, size_t len, uint32_t sum)
{
    size_t i;

    for (i = 0; i + 1 < len; i += 2) {
        sum += ((uint32_t)p[i] << 8) | p[i + 1];
    }
    if ((len & 1u) != 0) {
        sum += (uint32_t)p[len - 1] << 8;
    }
    return sum;
}

static uint16_t fold(uint32_t sum)
{
    while ((sum >> 16) != 0) {
        sum = (sum & 0xffffu) + (sum >> 16);
    }
    return (uint16_t)(~sum & 0xffffu);
}

static int verify_ipv4_tcp(const uint8_t *frame, size_t len,
                           const uint8_t *payload, size_t payload_len)
{
    const uint8_t *ip = frame + 14;
    size_t ihl = (size_t)(ip[0] & 0x0fu) * 4u;
    size_t total = get16(ip + 2);
    const uint8_t *tcp = ip + ihl;
    size_t tcp_len = total - ihl;
    uint32_t sum;

    if (len != 14 + total) {
        return 0;
    }
    if (fold(sum16(ip, ihl, 0)) != 0) {
        return 0;
    }
    sum = sum16(ip + 12, 8, 0);
    sum += 6;
    sum += (uint32_t)tcp_len;
    sum = sum16(tcp, tcp_len, sum);
    if (fold(sum) != 0) {
        return 0;
    }
    return memcmp(tcp + 32, payload, payload_len) == 0;
}

static int verify_ipv6_udp(const uint8_t *frame, size_t len,
                           const uint8_t *payload, size_t payload_len)
{
    const uint8_t *ip = frame + 14;
    size_t udp_len = get16(ip + 4);
    const uint8_t *udp = ip + 40;
    uint32_t sum;

    if (len != 14 + 40 + udp_len) {
        return 0;
    }
    sum = sum16(ip + 8, 32, 0);
    sum += (uint32_t)(udp_len >> 16);
    sum += (uint32_t)(udp_len & 0xffffu);
    sum += 17;
    sum = sum16(udp, udp_len, sum);
    if (fold(sum) != 0) {
        return 0;
    }
    return memcmp(udp + 8, payload, payload_len) == 0;
}

static size_t build_ipv4_tcp(uint8_t *frame)
{
    const char *payload = "HELLO-WORLD!";
    size_t payload_len = strlen(payload);
    uint8_t *ip = frame + 14;
    uint8_t *tcp = ip + 20;

    memset(frame, 0, 256);
    set16(frame + 12, 0x0800);
    ip[0] = 0x45;
    set16(ip + 2, (uint16_t)(20 + 32 + payload_len));
    set16(ip + 4, 0x1111);
    ip[8] = 64;
    ip[9] = 6;
    ip[12] = 10;
    ip[13] = 0;
    ip[14] = 0;
    ip[15] = 1;
    ip[16] = 1;
    ip[17] = 2;
    ip[18] = 3;
    ip[19] = 4;
    set16(tcp, 12345);
    set16(tcp + 2, 443);
    set32(tcp + 4, 1000);
    set32(tcp + 8, 2000);
    tcp[12] = 8 << 4; /* 32-byte TCP header with 12 bytes of options */
    tcp[13] = 0x18;
    set16(tcp + 14, 65535);
    memcpy(tcp + 32, payload, payload_len);
    return 14 + 20 + 32 + payload_len;
}

static size_t build_ipv6_udp(uint8_t *frame)
{
    const char *payload = "TEST";
    size_t payload_len = strlen(payload);
    uint8_t *ip = frame + 14;
    uint8_t *udp = ip + 40;

    memset(frame, 0, 256);
    set16(frame + 12, 0x86dd);
    ip[0] = 0x60;
    set16(ip + 4, (uint16_t)(8 + payload_len));
    ip[6] = 17;
    ip[7] = 64;
    ip[8] = 0x20;
    ip[9] = 0x01;
    ip[24] = 0x20;
    ip[25] = 0x01;
    set16(udp, 5000);
    set16(udp + 2, 50000);
    set16(udp + 4, (uint16_t)(8 + payload_len));
    memcpy(udp + 8, payload, payload_len);
    return 14 + 40 + 8 + payload_len;
}

int main(void)
{
    uint8_t orig[256];
    uint8_t out[512];
    size_t orig_len;
    size_t out_len;
    rv_packet pkt;
    const uint8_t fake[] = "abcdef";
    const uint8_t fake6[] = "FAKE!";
    int failures = 0;

    orig_len = build_ipv4_tcp(orig);
    if (rv_packet_parse(&pkt, orig, orig_len) != 1) {
        printf("FAIL: parse IPv4/TCP\n");
        return 1;
    }
    if (pkt.payload_len != 12 || pkt.tcp_seq != 1000 ||
        pkt.tcp_ack != 2000 || pkt.tcp_flags != 0x18 ||
        pkt.l4_hdr_len != 32) {
        printf("FAIL: IPv4/TCP parsed fields\n");
        failures++;
    }
    if (rv_build_tcp_frame(orig, orig_len, &pkt, 2000, 3000, 0x10,
                           fake, sizeof(fake) - 1, 3,
                           out, sizeof(out), &out_len) < 0) {
        printf("FAIL: build IPv4/TCP\n");
        failures++;
    } else {
        const uint8_t *ip = out + 14;
        const uint8_t *tcp = ip + 20;

        if (get16(ip + 4) != RV_SENT_MARKER || ip[8] != 3 ||
            get16(ip + 2) != 20 + 32 + sizeof(fake) - 1) {
            printf("FAIL: IPv4 header rewrite\n");
            failures++;
        }
        if (get32(tcp + 4) != 2000 || get32(tcp + 8) != 3000 ||
            tcp[13] != 0x10) {
            printf("FAIL: TCP header rewrite\n");
            failures++;
        }
        if (!verify_ipv4_tcp(out, out_len, fake, sizeof(fake) - 1)) {
            printf("FAIL: IPv4/TCP checksums or payload\n");
            failures++;
        }
        if (rv_tcp_set_window(out, out_len, &pkt, 8) < 0 ||
            !verify_ipv4_tcp(out, out_len, fake, sizeof(fake) - 1) ||
            get16(out + 14 + 20 + 14) != 8) {
            printf("FAIL: TCP window rewrite\n");
            failures++;
        }
    }

    orig_len = build_ipv6_udp(orig);
    if (rv_packet_parse(&pkt, orig, orig_len) != 1) {
        printf("FAIL: parse IPv6/UDP\n");
        return 1;
    }
    if (pkt.payload_len != 4 || pkt.dport != 50000) {
        printf("FAIL: IPv6/UDP parsed fields\n");
        failures++;
    }
    if (rv_build_udp_frame(orig, orig_len, &pkt, fake6,
                           sizeof(fake6) - 1, 1,
                           out, sizeof(out), &out_len) < 0) {
        printf("FAIL: build IPv6/UDP\n");
        failures++;
    } else {
        const uint8_t *ip = out + 14;
        uint32_t first = get32(ip);

        if ((first & 0xFFFFFu) != RV_SENT_MARKER || ip[7] != 1 ||
            get16(ip + 4) != 8 + sizeof(fake6) - 1) {
            printf("FAIL: IPv6 header rewrite\n");
            failures++;
        }
        if (!verify_ipv6_udp(out, out_len, fake6, sizeof(fake6) - 1)) {
            printf("FAIL: IPv6/UDP checksum or payload\n");
            failures++;
        }
    }

    if (rv_build_udp_frame(orig, orig_len, &pkt, fake6,
                           sizeof(fake6) - 1, 0,
                           out, 10, &out_len) == 0) {
        printf("FAIL: undersized output buffer accepted\n");
        failures++;
    }

    /* IPv4 UDP fragmentation via the common IPv4 header. */
    orig_len = build_ipv4_tcp(orig);
    if (rv_packet_parse(&pkt, orig, orig_len) == 1) {
        uint8_t full[512];
        size_t full_len;
        uint8_t f1[256];
        uint8_t f2[256];
        size_t f1_len;
        size_t f2_len;
        const uint8_t *ip1 = f1 + 14;
        const uint8_t *ip2 = f2 + 14;

        /* Reuse the IPv4 header but make it UDP for the fragment check. */
        orig[14 + 9] = 17;
        if (rv_packet_parse(&pkt, orig, orig_len) == 1 &&
            rv_build_udp_frame(orig, orig_len, &pkt, fake, sizeof(fake) - 1,
                               0, full, sizeof(full), &full_len) == 0 &&
            rv_build_ip_fragment(full, full_len, &pkt, 0, 8, 1,
                                 RV_SENT_MARKER, f1, sizeof(f1),
                                 &f1_len) == 0 &&
            rv_build_ip_fragment(full, full_len, &pkt, 8,
                                 8 + sizeof(fake) - 1 - 8,
                                 0, RV_SENT_MARKER, f2, sizeof(f2),
                                 &f2_len) == 0) {
            if (get16(ip1 + 2) != 20 + 8 ||
                (get16(ip1 + 6) & 0x2000u) == 0 ||
                (get16(ip2 + 6) & 0x1fffu) != 1) {
                printf("FAIL: IPv4 fragment headers\n");
                failures++;
            }
            if (memcmp(f1 + 14 + 20, full + 14 + 20, 8) != 0 ||
                memcmp(f2 + 14 + 20, full + 14 + 20 + 8,
                       8 + sizeof(fake) - 1 - 8) != 0) {
                printf("FAIL: IPv4 fragment payload split\n");
                failures++;
            }
        } else {
            printf("FAIL: IPv4 fragment build\n");
            failures++;
        }
    }

    /* IPv6 UDP fragmentation inserts a Fragment extension header. */
    orig_len = build_ipv6_udp(orig);
    if (rv_packet_parse(&pkt, orig, orig_len) == 1) {
        uint8_t full[512];
        size_t full_len;
        uint8_t f1[256];
        uint8_t f2[256];
        size_t f1_len;
        size_t f2_len;
        const uint8_t *ip1 = f1 + 14;
        const uint8_t *fh1 = f1 + 14 + 40;

        if (rv_build_udp_frame(orig, orig_len, &pkt, fake6,
                               sizeof(fake6) - 1, 0, full, sizeof(full),
                               &full_len) == 0 &&
            rv_build_ip_fragment(full, full_len, &pkt, 0, 8, 1,
                                 0x52560001u, f1, sizeof(f1),
                                 &f1_len) == 0 &&
            rv_build_ip_fragment(full, full_len, &pkt, 8,
                                 8 + sizeof(fake6) - 1 - 8,
                                 0, 0x52560001u, f2, sizeof(f2),
                                 &f2_len) == 0) {
            if (ip1[6] != 44 || fh1[0] != 17 ||
                get16(ip1 + 4) != 8 + 8 ||
                (get16(fh1 + 2) & 0x0001u) == 0) {
                printf("FAIL: IPv6 fragment headers\n");
                failures++;
            }
        } else {
            printf("FAIL: IPv6 fragment build\n");
            failures++;
        }
    }

    if (failures != 0) {
        printf("%d netbuild test(s) failed\n", failures);
        return 1;
    }
    printf("all netbuild tests passed\n");
    return 0;
}
