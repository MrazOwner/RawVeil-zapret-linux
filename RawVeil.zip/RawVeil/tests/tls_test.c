#include "l7.h"
#include "tls_parser.h"

#include <stdio.h>
#include <string.h>

static void put16(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v >> 8);
    p[1] = (uint8_t)(v & 0xffu);
}

static void put24(uint8_t *p, size_t v)
{
    p[0] = (uint8_t)((v >> 16) & 0xffu);
    p[1] = (uint8_t)((v >> 8) & 0xffu);
    p[2] = (uint8_t)(v & 0xffu);
}

static size_t build_client_hello(uint8_t *buf, size_t bufsz,
                                 const char *hostname, int with_sni)
{
    size_t p = 5;
    size_t hs_start;
    size_t body_start;
    size_t end;

    if (bufsz < 128 + strlen(hostname)) {
        return 0;
    }
    memset(buf, 0, bufsz);
    buf[0] = 0x16;
    buf[1] = 0x03;
    buf[2] = 0x01;

    hs_start = p;
    p += 4;
    body_start = p;
    put16(buf + p, 0x0303);
    p += 2;
    for (int i = 0; i < 32; i++) {
        buf[p++] = (uint8_t)(i + 1);
    }
    buf[p++] = 0; /* session id length */
    put16(buf + p, 2);
    p += 2;
    put16(buf + p, 0x1301);
    p += 2;
    buf[p++] = 1;
    buf[p++] = 0;

    if (with_sni) {
        size_t ext_total;
        size_t ext_data;
        size_t host_len = strlen(hostname);
        size_t ext_len_pos;

        ext_total = p;
        p += 2;
        ext_data = p;
        put16(buf + p, 0x0000); /* server_name */
        p += 2;
        ext_len_pos = p;
        p += 2;
        put16(buf + p, (uint16_t)(1 + 2 + host_len));
        p += 2;
        buf[p++] = 0; /* host_name */
        put16(buf + p, (uint16_t)host_len);
        p += 2;
        memcpy(buf + p, hostname, host_len);
        p += host_len;
        put16(buf + ext_len_pos, (uint16_t)(p - (ext_len_pos + 2)));
        put16(buf + ext_total, (uint16_t)(p - ext_data));
    } else {
        put16(buf + p, 0);
        p += 2;
    }

    end = p;
    buf[hs_start] = 0x01;
    put24(buf + hs_start + 1, end - body_start);
    put16(buf + 3, (uint16_t)(end - 5));
    return end;
}

static int failures;

static void check(int condition, const char *name)
{
    if (condition) {
        printf("ok:   %s\n", name);
    } else {
        printf("FAIL: %s\n", name);
        failures++;
    }
}

int main(void)
{
    uint8_t hello[512];
    rv_tls_info info;
    size_t len;

    len = build_client_hello(hello, sizeof(hello), "www.youtube.com", 1);
    check(len > 0, "build ClientHello");
    check(rv_tls_parse_client_hello(hello, len, &info) == 1,
          "parse ClientHello");
    check(info.is_client_hello && info.has_sni, "ClientHello/SNI flags");
    check(strcmp(info.sni, "www.youtube.com") == 0, "SNI value");
    check(info.sni_len == strlen("www.youtube.com") &&
          info.sni_offset + info.sni_len <= len &&
          memcmp(hello + info.sni_offset, "www.youtube.com",
                 info.sni_len) == 0, "SNI offset/length");
    check(rv_l7_tls_clienthello_start(hello, len) == 1,
          "ClientHello start detection");

    {
        uint8_t fake[512];
        int new_len;

        new_len = rv_tls_replace_sni(hello, len, "example.com",
                                     fake, sizeof(fake));
        check(new_len > 0, "rebuild ClientHello with longer SNI");
        check(rv_tls_parse_client_hello(fake, (size_t)new_len, &info) == 1 &&
              info.has_sni && strcmp(info.sni, "example.com") == 0,
              "rebuilt ClientHello parses with new SNI");
        new_len = rv_tls_replace_sni(hello, len, "a.io",
                                     fake, sizeof(fake));
        check(new_len > 0, "rebuild ClientHello with shorter SNI");
        check(rv_tls_parse_client_hello(fake, (size_t)new_len, &info) == 1 &&
              info.has_sni && strcmp(info.sni, "a.io") == 0,
              "shorter SNI round-trip");
    }

    len = build_client_hello(hello, sizeof(hello), "", 0);
    check(rv_tls_parse_client_hello(hello, len, &info) == 1,
          "ClientHello without extensions");
    check(!info.has_sni, "no SNI");

    len = build_client_hello(hello, sizeof(hello), "grok.com", 1);
    check(rv_tls_parse_client_hello(hello, len - 1, &info) == 1 &&
          info.is_client_hello && info.has_sni &&
          info.sni_len == strlen("grok.com"),
          "split record still exposes SNI offset/length");

    hello[0] = 0x17;
    check(rv_tls_parse_client_hello(hello, len, &info) == 0,
          "application data is not ClientHello");

    hello[0] = 0x16;
    put16(hello + 3, (uint16_t)(len + 100));
    check(rv_tls_parse_client_hello(hello, len, &info) == 1 &&
          info.is_client_hello && info.has_sni,
          "oversized record exposes available SNI");

    check(rv_tls_parse_client_hello(hello, 4, &info) == 0,
          "short buffer rejected");

    if (failures != 0) {
        printf("%d TLS test(s) failed\n", failures);
        return 1;
    }
    printf("all TLS tests passed\n");
    return 0;
}
