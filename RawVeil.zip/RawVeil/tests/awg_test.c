#include "awg.h"

#include <stdio.h>
#include <string.h>

static int failures;

static void check(int condition, const char *name)
{
    if (condition) {
        printf("ok:   %s\n", name);
    } else {
        printf("FAIL: %s\n", name);
        failures++;
    }
}

int main(void)
{
    rv_awg_config cfg;
    char err[256];

    memset(&cfg, 0, sizeof(cfg));
    err[0] = '\0';
    if (rv_awg_load("tests/awg_test.conf", &cfg,
                    err, sizeof(err)) < 0) {
        printf("FAIL: load AWG config: %s\n", err);
        return 1;
    }
    check(strcmp(cfg.interface, "awg_test") == 0,
          "interface derived from filename");
    check(cfg.has_ipv4 && cfg.has_ipv6, "Address v4/v6 detected");
    check(cfg.default_route_v4 && cfg.default_route_v6,
          "AllowedIPs default routes detected");
    check(cfg.mtu == 1280, "MTU parsed");
    check(strcmp(cfg.table, "off") == 0, "Table parsed");
    check(cfg.fwmark == 0xca6c, "FwMark parsed");
    check(strstr(cfg.address, "172.16.0.2") != NULL &&
          strstr(cfg.address, "2606:") != NULL,
          "Address string retained");
    check(strstr(cfg.allowed_ips, "0.0.0.0/0") != NULL,
          "AllowedIPs string retained");

    err[0] = '\0';
    if (rv_awg_load("tests/does-not-exist.conf", &cfg,
                    err, sizeof(err)) == 0) {
        printf("FAIL: missing AWG config accepted\n");
        failures++;
    }

    if (failures != 0) {
        printf("%d AWG test(s) failed\n", failures);
        return 1;
    }
    printf("all AWG tests passed\n");
    return 0;
}
