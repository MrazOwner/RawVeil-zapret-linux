#!/usr/bin/env python3
"""Safe, unprivileged TLS segmentation probe.

This tool does not touch routes, nftables, DNS or RawVeil state.  It starts a
local TCP relay, lets openssl generate a real ClientHello, then forwards that
ClientHello to the target in several harmless segmentation patterns.  The
result tells us whether the endpoint accepts the stream, not whether a
particular ISP's DPI is bypassed.

Usage:
    python3 tools/strategy_probe.py soundcloud.com api-v2.soundcloud.com
    python3 tools/strategy_probe.py --json discord.com youtube.com
"""

from __future__ import annotations

import argparse
import json
import socket
import subprocess
import sys
import time
from typing import Optional

MODES = ("baseline", "tcp_chunks", "sni_start", "sni_middle",
         "sni_end", "record_split")


def resolve(host: str) -> Optional[str]:
    try:
        infos = socket.getaddrinfo(host, 443, socket.AF_INET,
                                   socket.SOCK_STREAM)
    except OSError:
        return None
    if not infos:
        return None
    return infos[0][4][0]


def recv_record(sock: socket.socket, timeout: float = 4.0) -> bytes:
    sock.settimeout(timeout)
    data = b""
    while len(data) < 5:
        chunk = sock.recv(5 - len(data))
        if not chunk:
            return b""
        data += chunk
    need = 5 + int.from_bytes(data[3:5], "big")
    while len(data) < need:
        chunk = sock.recv(need - len(data))
        if not chunk:
            return b""
        data += chunk
    return data


def send_mode(sock: socket.socket, hello: bytes, host: str,
              mode: str) -> None:
    if mode == "baseline":
        sock.sendall(hello)
        return
    if mode == "record_split":
        payload = hello[5:]
        cut = max(1, len(payload) // 2)
        first = b"\x16\x03\x01" + cut.to_bytes(2, "big") + payload[:cut]
        second = (b"\x16\x03\x01" + (len(payload) - cut).to_bytes(2, "big") +
                  payload[cut:])
        sock.sendall(first)
        time.sleep(0.02)
        sock.sendall(second)
        return
    if mode == "tcp_chunks":
        size = max(1, len(hello) // 3)
        for pos in range(0, len(hello), size):
            sock.sendall(hello[pos:pos + size])
            time.sleep(0.02)
        return
    if mode.startswith("sni_"):
        at = hello.find(host.encode())
        if at < 0:
            at = len(hello) // 2
        cut = at + {"sni_start": 0, "sni_middle": len(host) // 2,
                    "sni_end": len(host)}[mode]
        cut = max(1, min(len(hello) - 1, cut))
        sock.sendall(hello[:cut])
        time.sleep(0.02)
        sock.sendall(hello[cut:])
        return
    raise ValueError(mode)


def probe(host: str, ip: str, mode: str, openssl: str) -> dict:
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind(("127.0.0.1", 0))
    listener.listen(1)
    listener.settimeout(6)
    port = listener.getsockname()[1]

    proc = subprocess.Popen(
        [openssl, "s_client", "-connect", f"127.0.0.1:{port}",
         "-servername", host, "-brief", "-ign_eof"],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE)
    try:
        client, _ = listener.accept()
    except OSError as exc:
        proc.kill()
        proc.wait()
        listener.close()
        return {"mode": mode, "ok": False, "error": f"openssl: {exc}"}

    result = {"mode": mode, "ok": False}
    target = None
    try:
        hello = recv_record(client, 4.0)
        if not hello:
            result["error"] = "no ClientHello"
        else:
            target = socket.create_connection((ip, 443), timeout=4.0)
            target.settimeout(5.0)
            send_mode(target, hello, host, mode)
            reply = target.recv(4096)
            if reply:
                result["reply_bytes"] = len(reply)
                result["record_type"] = reply[0]
                result["ok"] = reply[0] in (0x14, 0x15, 0x16)
            else:
                result["error"] = "empty reply"
    except Exception as exc:  # noqa: BLE001 - diagnostic tool
        result["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        if target is not None:
            target.close()
        client.close()
        proc.kill()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            pass
        listener.close()
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("hosts", nargs="+")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--openssl", default="openssl")
    parser.add_argument("--modes", default=",".join(MODES),
                        help="comma-separated modes: " + ",".join(MODES))
    args = parser.parse_args()
    modes = [m.strip() for m in args.modes.split(",") if m.strip()]
    unknown = [m for m in modes if m not in MODES]
    if unknown:
        parser.error("unknown modes: " + ",".join(unknown))

    all_results = []
    for host in args.hosts:
        ip = resolve(host)
        if ip is None:
            item = {"host": host, "ip": None, "results": [
                {"mode": "dns", "ok": False, "error": "resolve failed"}]}
        else:
            item = {"host": host, "ip": ip,
                    "results": [probe(host, ip, mode, args.openssl)
                                for mode in modes]}
        all_results.append(item)

    if args.json:
        print(json.dumps(all_results, indent=2, ensure_ascii=False))
    else:
        for item in all_results:
            print(f"{item['host']} -> {item['ip']}")
            for row in item["results"]:
                status = "ok" if row.get("ok") else "FAIL"
                extra = row.get("error", "")
                if row.get("record_type") is not None:
                    extra = f"record={row['record_type']:#x} bytes={row['reply_bytes']}"
                print(f"  {row['mode']:<12} {status:<4} {extra}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
